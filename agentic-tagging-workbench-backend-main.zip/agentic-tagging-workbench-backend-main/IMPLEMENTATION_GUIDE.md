# Implementation Guide: Two-Step Tagging Workflow

## Executive Summary

The Agentic Tagging Workbench now features a **two-step tagging workflow** that separates analysis from implementation:

1. **Tagging Suggestion Agent** - Analyzes and recommends tagging
2. **Apply Tagging Agent** - Implements the recommended tagging

This separation allows for review and approval before code changes are made.

## System Components Created

### 1. Tagging Suggestion Agent (`core/suggestTaggingAgent.py`)

**Purpose**: Identify which pages and flows need tagging without modifying code

**Key Features**:
- Clones the repository from GitHub URL
- Parses Tech Spec to identify pages and flows
- Scans repository structure
- Matches pages/flows to actual files
- Generates detailed reports (JSON + Markdown)
- Creates `.last_repo_root` file for the apply agent

**Main Classes**:
- `PageFlowIdentifier` - Searches for pages and flows in repo
- `TechSpecAnalyzer` - Extracts tagging requirements from Excel
- `Spinner` - CLI progress indicators

**Usage**:
```bash
cd core
python suggestTaggingAgent.py
```

**Environment Variables**:
```env
TECHSPEC_PATH=/path/to/techspec.xlsx
REPO_URL=https://github.com/owner/repo
REPO_BRANCH=main (optional)
CLONE_BASE=/home/user/ATTagger/Test
OPENAI_API_KEY=sk-... (optional)
```

### 2. Apply Tagging Agent (`core/applyTaggingAgent.py`)

**Purpose**: Apply tagging to the repository based on suggestions

**Key Features**:
- Loads suggestions from the previous step
- Finds 'common' folder in the repository
- Copies Tagging folder to `common/Tagging`
- Injects `useTagging` hook imports and calls
- Creates `.backup` files for rollback
- Generates detailed apply log

**Main Classes**:
- `ApplyTaggingEngine` - Orchestrates tagging application
- Uses `RepoStructureAnalyzer`, `TaggingFolderManager`, `CodeInjector` from tools

**Usage**:
```bash
cd core
python applyTaggingAgent.py
```

**Prerequisites**:
- Must run suggestTaggingAgent.py first
- Requires `.last_repo_root` file

### 3. Repository Analysis Tools (`core/tools/repoStructureAnalyzer.py`)

**New utility module** providing:

**RepoStructureAnalyzer**:
- Finds 'common' folder in various locations
- Searches recursively if not found in standard paths
- Indexes all JS/JSX/TS/TSX files
- Finds pages by name or content

**TaggingFolderManager**:
- Copies Tagging folder to repository
- Handles existing folder conflicts
- Calculates relative import paths

**CodeInjector**:
- Injects import statements
- Initializes hooks in React components
- Creates backup files
- Removes hooks (for rollback)

**PageFileUpdater**:
- High-level wrapper for updating pages
- Integrates all above utilities

### 4. New API Endpoints

#### POST `/suggest-tagging-v2`
Trigger the suggestion workflow

**Request**:
```json
{
  "repo_url": "https://github.com/owner/repo",
  "branch": "main",
  "clone_base": "/home/user/ATTagger/Test"
}
```

**Response**:
```json
{
  "status": "success",
  "workflow_step": "suggest",
  "summary": {
    "total_pages": 5,
    "pages_with_matches": 4,
    "total_items": 23
  },
  "pages_identified": 5,
  "items_to_tag": 23,
  "files": {
    "suggestions_json": "...",
    "suggestions_markdown": "..."
  }
}
```

#### POST `/apply-tagging-v2`
Trigger the apply workflow

**Request**:
```json
{
  "force": false
}
```

**Response**:
```json
{
  "status": "success",
  "workflow_step": "apply",
  "summary": {
    "total_pages": 5,
    "pages_updated": 4,
    "pages_failed": 1,
    "files_updated": 4,
    "files_failed": 1
  },
  "pages_updated": ["CheckoutPage", "PaymentPage"],
  "files_updated": 4
}
```

#### GET `/suggestions-markdown` / GET `/suggestions-json`
Retrieve the generated suggestions

#### GET `/apply-log`
View the detailed apply log

## Workflow Execution

### Complete Workflow Example

```bash
# Step 1: Generate Tech Spec
curl -X POST http://localhost:8000/generate-techspec \
  -H "Content-Type: application/json" \
  -d '{
    "ac_text": "User should see checkout page...",
    "figma_file_url": "https://figma.com/..."
  }'

# Step 2: Generate Tagging Suggestions
curl -X POST http://localhost:8000/suggest-tagging-v2 \
  -H "Content-Type: application/json" \
  -d '{
    "repo_url": "https://github.com/owner/repo",
    "branch": "main"
  }'

# Step 3: Review Suggestions
curl http://localhost:8000/suggestions-markdown

# Step 4: Apply Tagging
curl -X POST http://localhost:8000/apply-tagging-v2 \
  -H "Content-Type: application/json" \
  -d '{"force": false}'

# Step 5: View Results
curl http://localhost:8000/apply-log
```

### Manual Workflow

```bash
# Inside core/ directory

# Step 1: Generate suggestions
export TECHSPEC_PATH=/path/to/techspec.xlsx
export REPO_URL=https://github.com/owner/repo
export CLONE_BASE=/home/user/ATTagger/Test
python suggestTaggingAgent.py

# Step 2: Review the generated files
cat outputs/tagging_suggestions.md

# Step 3: Apply tagging
python applyTaggingAgent.py

# Step 4: Check the log
cat outputs/apply_log.json
```

## Repository Structure Integration

### Finding the Common Folder

The system searches in this order:

1. **Standard locations**:
   - `common/`
   - `src/common/`
   - `components/common/`
   - `utils/common/`
   - `shared/common/`

2. **Recursive search** (if not found):
   - Recursively searches for any folder named `common`
   - Skips `node_modules` and build directories

### Tagging Folder Placement

```
cloned-repo/
├── src/
│   ├── common/
│   │   ├── Tagging/                    ← Copied here
│   │   │   ├── index.js                ← useTagging hook
│   │   │   ├── dlStructure.js
│   │   │   ├── _test/
│   │   │   └── ...
│   │   ├── Button.jsx
│   │   └── ...other components
│   ├── pages/
│   │   ├── CheckoutPage.jsx            ← Hook injected here
│   │   ├── PaymentPage.jsx             ← Hook injected here
│   │   └── ...
│   └── ...
```

## Code Injection Details

### Import Injection

```javascript
// Import added at top of file
import { useTagging } from '../../common/Tagging';
```

The system:
- Calculates correct relative path from each file to Tagging
- Avoids duplicate imports
- Places import with other imports

### Hook Initialization

```javascript
const CheckoutPage = () => {
  useTagging();
  // Tagging initialized for: CheckoutPage/checkout_flow/select_payment
  
  const [items, setItems] = useState([]);
  // ... rest of component
};
```

The system:
- Finds the component function declaration
- Adds hook call at the start
- Includes metadata as a comment

## Backup & Recovery

### Backup Files

Each modified file gets a backup:
```
src/pages/CheckoutPage.jsx       ← Modified
src/pages/CheckoutPage.jsx.backup ← Original backup
```

### Recovery Process

To revert changes:

```bash
# Manual recovery
cd /path/to/repo
for file in **/*.backup; do
  original="${file%.backup}"
  cp "$file" "$original"
done

# Or use the rollback script
cd core
python rollback_changes.py
```

## Output Files

### Suggestion Phase Outputs

**File**: `core/outputs/tagging_suggestions.json`
```json
{
  "run_id": "2025-12-11T10:30:45",
  "type": "suggestion",
  "summary": {
    "total_pages": 5,
    "pages_with_matches": 4,
    "total_flows": 3,
    "total_items": 23
  },
  "suggestions_by_page": [
    {
      "page": "CheckoutPage",
      "flow": "checkout_flow",
      "file_locations": ["src/pages/CheckoutPage.jsx"],
      "tagging_items": [...]
    }
  ]
}
```

**File**: `core/outputs/tagging_suggestions.md`
```markdown
# Tagging Suggestions Report

## Summary
- Total Pages: 5
- Pages with Matches: 4
- Total Items: 23

## Pages Analysis

### CheckoutPage ✓ FOUND
Matches (1):
- `src/pages/CheckoutPage.jsx`

...
```

### Apply Phase Outputs

**File**: `core/outputs/apply_log.json`
```json
{
  "run_id": "2025-12-11T10:35:12",
  "repo_path": "/home/user/ATTagger/Test/repo",
  "common_folder": "/home/user/ATTagger/Test/repo/src/common",
  "tagging_folder": "/home/user/ATTagger/Test/repo/src/common/Tagging",
  "pages_updated": ["CheckoutPage", "PaymentPage"],
  "pages_failed": [],
  "files_updated": [
    "src/pages/CheckoutPage.jsx",
    "src/pages/PaymentPage.jsx"
  ],
  "summary": {
    "total_pages": 2,
    "pages_updated": 2,
    "pages_failed": 0,
    "files_updated": 2,
    "files_failed": 0
  }
}
```

**File**: `core/outputs/.last_repo_root`
```
/home/user/ATTagger/Test/repo
```

## Error Handling

### Common Issues & Solutions

| Issue | Cause | Solution |
|-------|-------|----------|
| "Common folder not found" | Repo structure not supported | Ensure repo has a `common` directory |
| "Source Tagging folder not found" | Missing core/Tagging | Check `core/Tagging/` exists |
| "Suggestions report not found" | Skipped suggestion step | Run `/suggest-tagging-v2` first |
| "Clone failed" | Invalid repo URL | Verify GitHub URL is correct |
| "Import path calculation failed" | File structure issue | Check relative path logic |

### Logs & Debugging

**Enable detailed logging**:
```bash
# Set Python logging to DEBUG
export PYTHONUNBUFFERED=1
python suggestTaggingAgent.py 2>&1 | tee suggestion.log
```

**Check stderr output**:
```bash
# API returns stderr in response
curl http://localhost:8000/suggest-tagging-v2 | jq '.stderr'
```

## Performance Metrics

- **Suggestion phase**: 30-60 seconds (includes git clone)
- **Analysis**: 10-20 seconds (depends on repo size)
- **Apply phase**: 10-30 seconds (depends on file count)
- **Total**: ~1-2 minutes for typical mid-size repos

## Testing the Implementation

### Unit Tests

```bash
# Test repo structure analyzer
python -m pytest core/tools/test_repoStructureAnalyzer.py

# Test suggestion agent
python -m pytest core/test_suggestTaggingAgent.py

# Test apply agent
python -m pytest core/test_applyTaggingAgent.py
```

### Integration Tests

```bash
# Run full workflow with test repo
./test_full_workflow.sh

# Check generated files
cat core/outputs/tagging_suggestions.md
cat core/outputs/apply_log.json
```

## Configuration

### Environment Variables

```bash
# Required
CLONE_BASE=/home/user/ATTagger/Test
TECHSPEC_PATH=/path/to/techspec.xlsx
REPO_URL=https://github.com/owner/repo

# Optional
REPO_BRANCH=main
OPENAI_API_KEY=sk-...  # For LLM features
```

### Tech Spec Rules

Located in: `core/techSpecAgent/config/tagging_rules.json`

```json
{
  "naming": {
    "selection": "Select_{object}",
    "continue": "Continue_{object}"
  },
  "datalayer_mappings": {
    "page_display": "vzdl.page.name",
    "button_tap": "vzdl.event.value"
  }
}
```

## Best Practices

1. **Always review suggestions before applying**
   - Check `tagging_suggestions.md`
   - Verify page/flow matches are correct

2. **Use version control**
   - Commit before applying tagging
   - Tag the commit with tech spec version

3. **Keep backups**
   - Don't delete `.backup` files immediately
   - Allow time for testing

4. **Monitor large repos**
   - Large repos may take longer to clone/scan
   - Check logs for warnings about skipped files

5. **Incremental updates**
   - Don't re-run on same repo without cleanup
   - The second run might modify already-injected code

## Future Enhancements

1. **Smart conflict detection** - Warn if hook already injected
2. **Parallel processing** - Speed up large repos
3. **Custom hook patterns** - Support different hook signatures
4. **Flow detection** - Better flow-to-page matching
5. **Rollback API** - HTTP endpoint for rollback
6. **Dry-run mode** - Test without modifying files
7. **Incremental updates** - Only update changed pages

## Troubleshooting

### Clone fails with network error
```bash
# Check network connectivity
curl -I https://github.com

# Use SSH if HTTPS fails
export REPO_URL=git@github.com:owner/repo.git
```

### Tagging folder not found
```bash
# Verify structure
ls -la core/Tagging/
# Should show: index.js, dlStructure.js, ...
```

### Import path incorrect
```bash
# Check file location
find /path/to/repo -name "*.jsx" | head
# Check common folder location
find /path/to/repo -name "common" -type d
```

### Suggestions report is empty
```bash
# Verify TechSpec exists
ls -la core/techSpecAgent/TechSpecOutputs/techspec.xlsx

# Check Tech Spec parsing
python -c "from core.tools.excelReader import ExcelReaderTool; print(ExcelReaderTool()._run('path/to/techspec.xlsx'))"
```

---

For more information, see:
- [TAGGING_AGENTS_README.md](TAGGING_AGENTS_README.md) - Architecture details
- [core/suggestTaggingAgent.py](core/suggestTaggingAgent.py) - Source code
- [core/applyTaggingAgent.py](core/applyTaggingAgent.py) - Source code
- [core/tools/repoStructureAnalyzer.py](core/tools/repoStructureAnalyzer.py) - Utilities
