# BPK AI Tagging - Tech Spec Generation System

## Overview

This system automatically generates Adobe Analytics tagging specifications (Tech Specs) for the BPK (Verizon Business Portal) by analyzing:
1. **Figma Design Screenshots** - The actual UI/UX being built
2. **Acceptance Criteria** - The testable user actions and validations
3. **BPK Tech Spec CSV** - The reference document with all DataLayer properties
4. **Tagging Rules Configuration** - The rules for consistent naming and mapping

The system uses **GPT-4o vision + reasoning** to map each AC step to the appropriate Verizon DataLayer property and Adobe Analytics variable.

## Key Features

✅ **DataLayer-Centric Design** - Uses Verizon's DataLayer properties (`vzdl.*`) as the single source of truth  
✅ **BPK-Referenced Mapping** - Automatically maps DataLayer properties to Adobe eVars from the BPK Tech Spec CSV  
✅ **Context-Aware** - Understands business context to assign Mandatory vs Optional status  
✅ **Consistent Naming** - Uses configurable naming patterns and dictionaries for standardized Adobe Values  
✅ **CSV Export** - Generates timestamped CSV files suitable for analytics platform configuration  
✅ **Auditability** - Each KPI references the original AC for traceability  

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│  Inputs                                                 │
├─────────────────────────────────────────────────────────┤
│ 1. Figma Screenshot    → figma_screen.png               │
│ 2. Acceptance Criteria → acceptance_criteria.txt         │
│ 3. BPK Tech Spec CSV   → BPK - AI Tagging - Tech Spec   │
│ 4. Tagging Rules       → config/tagging_rules.json       │
└──────────┬──────────────────────────────────────────────┘
           │
           ▼
┌─────────────────────────────────────────────────────────┐
│  Processing                                             │
├─────────────────────────────────────────────────────────┤
│ 1. Load AC + Screenshot (base64 encoded)                │
│ 2. Load Rules (DataLayer mappings, eVar assignments)    │
│ 3. Call GPT-4o with System Prompt + Inputs              │
│ 4. Parse JSON response with tech spec rows              │
│ 5. Enhance with BPK reference data                      │
└──────────┬──────────────────────────────────────────────┘
           │
           ▼
┌─────────────────────────────────────────────────────────┐
│  Outputs                                                │
├─────────────────────────────────────────────────────────┤
│ CSV: BPK_AI_Tagging_TechSpec_YYYYMMDD_HHMMSS.csv        │
│ Columns:                                                │
│  • KPI Requirement                                      │
│  • DataLayer Property (e.g., vzdl.page.name)            │
│  • Adobe Variables (e.g., eVar70)                       │
│  • Adobe Values (e.g., Display_PayYourBill)             │
│  • Mandatory/Optional                                   │
│  • Business Context                                     │
│                                                         │
│ Stored in: TechSpecOutputs/                             │
└─────────────────────────────────────────────────────────┘
```

## Files and Components

### Core Files

| File | Purpose |
|------|---------|
| `techSpecGenerate.py` | Main orchestrator - coordinates AC loading, LLM mapping, and output generation |
| `llm_mapper.py` | Calls GPT-4o with vision to map AC → DataLayer → eVars |
| `spec_writer.py` | Writes CSV and Excel outputs with DataLayer columns |
| `ac_loader.py` | Loads AC from local file or Google Docs |
| `rules_loader.py` | Loads tagging rules configuration |

### Configuration Files

| File | Purpose |
|------|---------|
| `prompts/mapper_system.md` | **System Prompt** - Instructs GPT-4o on mapping strategy |
| `config/tagging_rules.json` | **Rules** - Naming patterns, dictionaries, DataLayer mappings, eVar assignments |

### Reference Files

| File | Location | Purpose |
|------|----------|---------|
| BPK Tech Spec CSV | `backend/v1/src/input/BPK - AI Tagging - Tech Spec (Tagging Properties).csv` | Source of truth for DataLayer properties and eVar assignments |
| Acceptance Criteria | `backend/v1/src/input/acceptance_criteria.txt` | User actions and validations to tag |

### Output Files

| File | Location | Purpose |
|------|----------|---------|
| Generated Tech Spec | `techSpecAgent/TechSpecOutputs/BPK_AI_Tagging_TechSpec_*.csv` | Final deliverable with all tagging specs |
| Example Output | `techSpecAgent/EXAMPLE_TECHSPEC_OUTPUT.csv` | Template showing expected output format |

### Documentation

| File | Purpose |
|------|---------|
| `TECH_SPEC_GENERATION_GUIDE.md` | Comprehensive guide to the system |
| `SYSTEM_PROMPT_DOCUMENTATION.md` | Detailed explanation of system prompt and LLM strategy |
| `README.md` | This file - quick start and overview |

## Quick Start

### 1. Setup Environment

```bash
# Copy .env.example to .env and configure
cp .env.example .env

# Edit .env with:
OPENAI_API_KEY=sk-...              # OpenAI API key
OPENAI_MODEL=gpt-4o-mini           # Model (or gpt-4o for better accuracy)
AC_LOCAL_FILE=./acceptance_criteria.txt
RULES_FILE=./config/tagging_rules.json
OUTPUT_DIR=./TechSpecOutputs
FIGMA_TOKEN=ftest_...              # If capturing from Figma
FIGMA_FILE_KEY=...                 # If capturing from Figma
```

### 2. Prepare Inputs

Ensure these files exist:
- `acceptance_criteria.txt` - AC steps
- `config/tagging_rules.json` - Tagging rules
- Figma screenshot (captured or provided)

### 3. Run Generation

```bash
# From the core directory
python techSpecGenerate.py

# OR use the standalone generator
python standalone_techspec_generator.py [screenshot_path] [output_dir]
```

### 4. Check Output

```bash
# Generated file in TechSpecOutputs/
ls -la TechSpecOutputs/BPK_AI_Tagging_TechSpec_*.csv
```

## Understanding the Output

### CSV Columns

**KPI Requirement** (String)
- The actual AC step that should be tagged
- Example: "Verify that the 'Pay your bill' button is tagged when tapped."

**DataLayer Property** (String)
- Verizon's DataLayer property that captures this interaction
- Example: `vzdl.event.value`, `vzdl.page.name`, `vzdl.txn.paymentType`
- Can be null if not applicable

**Adobe Variables** (String)
- The eVar where this will be sent
- Example: `eVar16` (for `vzdl.event.value`)
- Always populated, uses default if no specific mapping

**Adobe Values** (String)
- The actual string value to send with the eVar
- Example: `Tap_PayYourBill`, `Display_HowCanWeHelpYouToday`
- Uses naming patterns and dictionary from rules

**Mandatory/Optional** (Enum: Mandatory | Optional)
- **Mandatory**: Core payment flow, critical user actions, business requirements
- **Optional**: Secondary UI, confirmations, enhancements

**Business Context** (String)
- Why this metric matters for the business
- Example: "Track user engagement with primary payment flow initiation"

### Example Row

```csv
"Verify that the 'Pay your bill' button is tagged when tapped.",\
"vzdl.event.value",\
"eVar16",\
"Tap_PayYourBill",\
"Mandatory",\
"Track user engagement with primary customer action to initiate bill payment"
```

## How the System Works

### Step 1: Load Inputs
```python
screenshot = load_figma_screenshot()           # or provided path
ac_text = load_acceptance_criteria()           # from local file
rules = load_rules()                           # from config/tagging_rules.json
```

### Step 2: Call LLM
```python
system_prompt = read("prompts/mapper_system.md")
response = gpt4o_vision({
    "system": system_prompt,
    "input": {
        "acceptance_criteria": ac_text,
        "screenshot_base64": screenshot,
        "rules_json": rules
    }
})
```

The LLM:
1. Extracts each AC step as a KPI
2. Analyzes the screenshot for context
3. Uses `rules.datalayer_mappings` to select DataLayer property
4. Uses `rules.bpk_evar_mappings` to select eVar
5. Constructs Adobe Value using naming patterns and dictionary
6. Determines Mandatory/Optional based on business context

### Step 3: Write Output
```python
tech_spec_csv = write_csv(lm_response)  # Each row → CSV row
```

## Customizing the System

### Adding a New UI Element

1. **Add to dictionary** in `config/tagging_rules.json`:
   ```json
   "dictionary": {
     "new button name": "NewButtonName",
     ...
   }
   ```

2. **System automatically uses it** in naming patterns:
   - "Tap_NewButtonName"
   - "Select_NewButtonName"
   - etc.

### Adding a New DataLayer Property

1. **Find the property** in BPK Tech Spec CSV
   - Example: `eVar52, vzdl.new.property, Definition, Values, Dynamic, Mandatory`

2. **Add to tagging rules**:
   ```json
   "datalayer_mappings": {
     "new_context": "vzdl.new.property",
     ...
   },
   "bpk_evar_mappings": {
     "vzdl.new.property": "eVar52",
     ...
   }
   ```

3. **Update system prompt** if needed (usually not required - LLM can infer)

### Adjusting Mandatory/Optional Classification

The system prompt contains logic for determining M/O:

```markdown
4. Determine Mandatory/Optional status:
   - Critical user interactions = Mandatory
   - Business context data = Mandatory
   - Optional confirmations or secondary flows = Optional
```

To change this:
1. Edit `prompts/mapper_system.md`
2. Adjust the classification logic
3. Re-run generation

## Validation & QA

### Checklist Before Running

- [ ] `acceptance_criteria.txt` loaded correctly
- [ ] Figma screenshot exists and is readable
- [ ] `config/tagging_rules.json` has all required elements
- [ ] Dictionary contains all UI elements from AC
- [ ] DataLayer mappings cover the interaction types
- [ ] eVar assignments match BPK Tech Spec CSV
- [ ] OPENAI_API_KEY is valid and has quota

### Checklist After Generation

- [ ] CSV file created in `TechSpecOutputs/`
- [ ] All AC steps are represented as KPIs
- [ ] No "LLM_PARSE_ERROR" in output
- [ ] DataLayer properties match BPK Tech Spec
- [ ] eVars match expected assignments
- [ ] Adobe Values follow naming conventions
- [ ] Business Context provides meaningful information
- [ ] Mandatory/Optional status is reasonable

### Example Validation

```python
# Check CSV was created
assert os.path.exists("TechSpecOutputs/BPK_AI_Tagging_TechSpec_*.csv")

# Load and validate
import csv
with open(csv_path) as f:
    reader = csv.DictReader(f)
    for row in reader:
        # Each row should have all required columns
        assert row['KPI Requirement']
        assert row['Adobe Variables']
        assert row['Adobe Values']
        # DataLayer and Business Context can be empty
        assert row['Mandatory/Optional'] in ['Mandatory', 'Optional']
```

## Troubleshooting

### Issue: "OPENAI_API_KEY is missing in .env"
- [ ] Check `.env` file exists
- [ ] Verify OPENAI_API_KEY is set
- [ ] Ensure key is valid (test with `curl https://api.openai.com/v1/models`)

### Issue: "LLM_PARSE_ERROR" in all rows
- [ ] Check system prompt is properly formatted (in `prompts/mapper_system.md`)
- [ ] Verify OPENAI_API_KEY is valid
- [ ] Try with `gpt-4o` instead of `gpt-4o-mini`
- [ ] Check that input rules are valid JSON

### Issue: Wrong DataLayer properties assigned
- [ ] Verify property exists in `datalayer_mappings`
- [ ] Check spelling matches exactly (case-sensitive)
- [ ] Compare with BPK Tech Spec CSV

### Issue: Wrong eVars assigned
- [ ] Verify mapping exists in `bpk_evar_mappings`
- [ ] Check that DataLayer property is correct first
- [ ] Validate against BPK Tech Spec CSV

### Issue: Adobe Values don't match expectations
- [ ] Check dictionary contains the element name
- [ ] Verify spelling in dictionary (must be exact match)
- [ ] Check naming templates in `naming` section
- [ ] Verify `action_aliases` map user actions correctly

## Next Steps After Generation

1. **Review the CSV** for accuracy and completeness
2. **Validate with stakeholders** (product, analytics, engineering)
3. **Cross-reference** with BPK Tech Spec CSV definitions
4. **Import into Adobe Analytics** configuration
5. **Document in your analytics platform** (QA form, Adobe Launch, etc.)
6. **Test with real implementation** before go-live

## Files Modified/Created

### New Files
- ✅ `TECH_SPEC_GENERATION_GUIDE.md` - Comprehensive guide
- ✅ `SYSTEM_PROMPT_DOCUMENTATION.md` - LLM strategy documentation
- ✅ `EXAMPLE_TECHSPEC_OUTPUT.csv` - Template output
- ✅ `standalone_techspec_generator.py` - Standalone generator script
- ✅ `README.md` (this file) - Quick reference

### Modified Files
- ✅ `prompts/mapper_system.md` - Enhanced with DataLayer intelligence
- ✅ `config/tagging_rules.json` - Added DataLayer mappings and eVar assignments
- ✅ `llm_mapper.py` - Updated to handle DataLayer fields
- ✅ `spec_writer.py` - Added CSV and Excel with DataLayer output
- ✅ `techSpecGenerate.py` - Updated to use new output functions

## Related Documentation

- **BPK Tech Spec**: See the CSV at `backend/v1/src/input/BPK - AI Tagging - Tech Spec (Tagging Properties).csv`
- **Acceptance Criteria**: See `backend/v1/src/input/acceptance_criteria.txt`
- **Adobe Analytics**: https://experienceleague.adobe.com/docs/analytics/implementation/vars/overview.html
- **Verizon DataLayer**: Contact your analytics team for internal documentation

## Support & Questions

For questions about:
- **System prompt**: See `SYSTEM_PROMPT_DOCUMENTATION.md`
- **Configuration**: See `TECH_SPEC_GENERATION_GUIDE.md`
- **Implementation**: See individual Python files for inline comments
- **DataLayer properties**: Refer to BPK Tech Spec CSV

---

**Version**: 1.0  
**Last Updated**: November 2025  
**Status**: Production Ready
