# Technical Specification Generation Improvements

## 1. Fixing Limited Specification Output

**Issue:** Technical specification (spec) is too short or "limited row".

**Action: Increase the Output Token Limit**
- Find the `max_tokens` (or equivalent) parameter in your LLM API call
- Set this value higher (e.g., from $1024$ to $8000$ tokens) to allow the model to generate the complete document



## 2. Refining Prompt Design

**Issue:** "Output extracted from figma not Prioritized".
**Action: Prioritizing Dictionary Generation from Figma**
- In final prompt increase figam ouput priority as critrical step and avoid the false tech spec generation if the figma output is not valid or empty



## 3. Made improvement in the final output parsing
using clean_llm_output.py file