import os
import sys
import traceback
from figma_capture import capture_sync, capture_multiple_sync

def test_single_capture():
    print("Testing single Figma screenshot capture...")
    try:
        out_path = capture_sync()
        assert os.path.exists(out_path), f"Screenshot not found: {out_path}"
        assert os.path.getsize(out_path) > 10_000, "Screenshot file is too small."
        print(f"Single screenshot test passed: {out_path}")
    except Exception as e:
        print(f"Single screenshot test failed: {e}")
        traceback.print_exc()
        sys.exit(1)

def test_multiple_capture():
    print("Testing multiple Figma screenshot capture...")
    try:
        capture_multiple_sync()
        # Check for at least one screenshot
        found = False
        for fname in os.listdir(os.getenv("OUTPUT_DIR", "TechSpecOutputs")):
            if fname.startswith("figma_screen_") and fname.endswith(".png"):
                fpath = os.path.join(os.getenv("OUTPUT_DIR", "TechSpecOutputs"), fname)
                if os.path.getsize(fpath) > 10_000:
                    found = True
                    print(f"Found screenshot: {fpath}")
        assert found, "No valid screenshots found."
        print("Multiple screenshot test passed.")
    except Exception as e:
        print(f"Multiple screenshot test failed: {e}")
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    test_single_capture()
    test_multiple_capture()
