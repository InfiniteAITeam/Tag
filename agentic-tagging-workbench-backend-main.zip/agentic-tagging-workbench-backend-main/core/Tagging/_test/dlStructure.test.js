import basicDlObject from '../dlStructure';

describe('basicDlObject', () => {
  it('should be a non-null object', () => {
    expect(typeof basicDlObject).toBe('object');
    expect(basicDlObject).not.toBeNull();
  });

  it('should have all expected top-level keys', () => {
    const expectedKeys = ['page', 'user', 'target', 'txn', 'event', 'env', 'utils', 'search', 'support', 'cmp'];
    expect(Object.keys(basicDlObject).sort()).toEqual(expectedKeys.sort());
  });

  describe('page', () => {
    it('should have correct structure', () => {
      expect(basicDlObject.page).toMatchObject({
        name: expect.any(String),
        channel: 'bpk',
        channelSession: expect.any(String),
        displayChannel: 'Retail',
        sourceChannel: 'POS',
      });
    });
  });

  describe('user, event, env, utils, search, support, cmp', () => {
    it('should have correct structure for user', () => {
      expect(basicDlObject.user).toEqual({
        account: '',
        accountLast2: '',
        accountType: '',
        acctId_unhashed: '',
        authStatus: '',
        authType: '',
        customerRole: '',
        customerType: '',
        id: '',
        session: '',
        zip: '',
        tenure: '',
        planType: '',
        custId_unhashed: '',
      });
    });
  });

  const emptyKeys = ['utils', 'search', 'support', 'cmp'];
  emptyKeys.forEach((key) => {
    it(`should have empty object for ${key}`, () => {
      expect(basicDlObject[key]).toEqual({});
    });
  });

  describe('target', () => {
    it('should have correct structure', () => {
      expect(basicDlObject.target).toEqual({
        engagement: { intent: 'BILLPAYMENT EXPERIENCE' },
      });
    });
  });

  describe('txn', () => {
    it('should have correct structure', () => {
      expect(basicDlObject.txn).toEqual({
        agent: '',
        agentRole: '',
        id: '',
        outletId: '',
        paymentAmt: '',
        paymentType: '',
        product: {},
        taxAmt: '',
        total: '',
        autoPay: '',
      });
    });
  });
});
