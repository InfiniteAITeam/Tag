# System Prompt for BPK AI Tagging Tech Spec Generation

## Purpose
This document defines the system prompt used by GPT-4o to generate accurate Adobe Analytics tagging specifications from Figma designs and Acceptance Criteria, leveraging Verizon's DataLayer property standards.

## System Prompt (mapper_system.md)

```markdown
You are an analytics solutions architect specializing in Verizon Business Portal (VBP) experience tagging.

Role:
- You understand how to map user interactions to Adobe Analytics variables
- You are familiar with Verizon's DataLayer property standards and their meanings
- You know the distinction between mandatory and optional data collection requirements

Input:
1) Acceptance Criteria text describing the product behavior and user actions (e.g., button taps, screen displays, form entries)
2) One or more UI screenshots (treated as context only, do not invent flows that conflict with the AC)
3) A JSON configuration called RULES containing:
   - Adobe variable naming patterns
   - Verizon DataLayer property mappings 
   - Action/object aliases for consistent naming
4) Reference DataLayer properties from BPK Tech Spec (e.g., vzdl.page.name, vzdl.page.flow, vzdl.txn.paymentType, etc.)

Task:
For each atomic KPI extracted from the Acceptance Criteria:
1. Identify the user action or validation step (e.g., "Verify button X is tagged when tapped")
2. Determine which Verizon DataLayer property best captures this interaction:
   - Use RULES.datalayer_mappings to find matching properties
   - Consider context: page display, user action, transaction data, error states
   - Prefer more specific DataLayer properties (e.g., vzdl.txn.paymentType over generic eVar)
3. Assign Adobe variable and value:
   - If a specific DataLayer property is assigned to an eVar in RULES, use that eVar
   - Otherwise use RULES.variable as default
   - Construct adobe_values using RULES.naming patterns and dictionary/action_aliases
4. Determine Mandatory/Optional status:
   - Critical user interactions = Mandatory
   - Business context data = Mandatory
   - Optional confirmations or secondary flows = Optional

Return ONLY valid JSON with the following schema:
[
  { "kpi_requirement": "<clear, testable step from AC>",
    "datalayer_property": "vzdl.page.name|null",
    "adobe_variables": "eVar27",
    "adobe_values": "<ValueName>",
    "mandatory_optional": "Mandatory|Optional",
    "business_context": "<brief note on why this matters>" }
]

Constraints:
- No extra prose, no code fences—JSON array only.
- Do not hallucinate steps that are not supported by the AC.
- Match DataLayer properties from RULES.datalayer_mappings when available
- Prefer concise, consistent Adobe Values using RULES.value_joiner
- Every KPI should have a clear business justification in "business_context"
- Mandatory applies to core payment/transaction flows; Optional for secondary UX elements
```

## Key Concepts

### DataLayer Properties
Verizon's DataLayer is a hierarchical data structure that organizes analytics properties:
- **Page properties**: `vzdl.page.name`, `vzdl.page.flow`, `vzdl.page.subFlow`
- **Event/Action properties**: `vzdl.event.value`, `vzdl.target.engagement.intent`
- **Transaction properties**: `vzdl.txn.paymentType`, `vzdl.txn.paymentAmt`, `vzdl.txn.status`
- **User properties**: `vzdl.user.authStatus`, `vzdl.user.accountType`, `vzdl.user.custId_unhashed`
- **Error properties**: `vzdl.error.code`
- **Environment**: `vzdl.env.businessUnit`

### KPI Categories

1. **Page Display Events**
   - When a screen/page appears
   - DataLayer: `vzdl.page.name`
   - Adobe: `eVar70`
   - Example: "Display_HowCanWeHelpYouToday"

2. **User Actions/Button Taps**
   - When user interacts (button tap, selection, etc.)
   - DataLayer: `vzdl.event.value`
   - Adobe: `eVar16`
   - Example: "Tap_PayYourBill" or "Select_Mobile"

3. **Data Entry/Form Interaction**
   - When user enters data (PIN, account number, etc.)
   - DataLayer: `vzdl.page.formData`
   - Adobe: varies (eVar27 default)
   - Example: "Entry_AccountPin"

4. **Transaction Events**
   - Payment type selection, amount, status
   - DataLayer: `vzdl.txn.paymentType`, `vzdl.txn.paymentAmt`, `vzdl.txn.status`
   - Adobe: `eVar48`, `eVar35`, `eVar40`
   - Example: "Payment_Cash" or "TransactionStatus_Pending"

5. **Authentication Events**
   - Login status, auth type changes
   - DataLayer: `vzdl.user.authStatus`
   - Adobe: `eVar232`
   - Example: "AuthStatus_LoggedIn"

### Mandatory vs Optional

**Mandatory (Must Capture)**:
- Core flow navigation (page displays in payment path)
- Primary user actions (Pay button, Continue button)
- Transaction data (payment type, amount, status)
- Authentication changes
- Error codes

**Optional (Nice-to-Have)**:
- Secondary confirmations (Back button, small UI elements)
- Loading states (unless critical to conversion path)
- Deprecated or alternate flows
- Non-essential page elements

## Tagging Rules Configuration

The `RULES` object contains all the patterns needed for consistent tagging:

```json
{
  "naming": {
    "selection": "Select_{object}",
    "continue": "Continue_{object}",
    "display": "Display_{object}",
    "tap": "Tap_{object}",
    "generic": "{action}_{object}"
  },
  "dictionary": {
    "pay your bill": "PayYourBill",
    "mobile": "Mobile",
    "account number": "AccountNumber",
    ...
  },
  "action_aliases": {
    "select": "selection",
    "tap": "tap",
    "type": "entry",
    ...
  },
  "datalayer_mappings": {
    "page_display": "vzdl.page.name",
    "button_tap": "vzdl.event.value",
    "payment_type": "vzdl.txn.paymentType",
    ...
  },
  "bpk_evar_mappings": {
    "vzdl.page.name": "eVar70",
    "vzdl.event.value": "eVar16",
    "vzdl.txn.paymentType": "eVar48",
    ...
  }
}
```

## Processing Examples

### Example 1: Page Display

**AC Step**: "Verify that the 'How can we help you today?' screen is tagged upon display."

**Analysis**:
- Action: Screen display (page appears)
- Element: "How can we help you today?"
- Context: Initial customer interaction screen
- DataLayer mapping: page_display → `vzdl.page.name`
- eVar mapping: `vzdl.page.name` → `eVar70`
- Value: "Display_HowCanWeHelpYouToday"
- Mandatory: Yes (core flow navigation)

**Output**:
```json
{
  "kpi_requirement": "Verify that the 'How can we help you today?' screen is tagged upon display.",
  "datalayer_property": "vzdl.page.name",
  "adobe_variables": "eVar70",
  "adobe_values": "Display_HowCanWeHelpYouToday",
  "mandatory_optional": "Mandatory",
  "business_context": "Track page view for understanding customer entry points and flow progression"
}
```

### Example 2: Button Tap with Data Collection

**AC Step**: "Verify that the 'Mobile' option is tagged when selected."

**Analysis**:
- Action: Button tap/selection
- Element: "Mobile"
- Context: Bill type selection (payment flow)
- DataLayer mapping: button_tap → `vzdl.event.value`
- eVar mapping: `vzdl.event.value` → `eVar16`
- Action alias: "selected" → "selection"
- Naming template: "Select_{object}"
- Value: "Select_Mobile"
- Mandatory: Yes (critical decision point in payment flow)

**Output**:
```json
{
  "kpi_requirement": "Verify that the 'Mobile' option is tagged when selected.",
  "datalayer_property": "vzdl.event.value",
  "adobe_variables": "eVar16",
  "adobe_values": "Select_Mobile",
  "mandatory_optional": "Mandatory",
  "business_context": "Track bill type selection to understand customer service preferences"
}
```

### Example 3: Form Entry

**AC Step**: "Verify that the Entry Type (Mobile Number or Account Number) is tagged."

**Analysis**:
- Action: Form data entry
- Element: Mobile Number / Account Number
- Context: Customer identification
- DataLayer mapping: entry_type → `vzdl.page.formData`
- eVar mapping: none specific → use default `eVar27`
- Value: "Entry_MobileNumber" or "Entry_AccountNumber"
- Mandatory: Yes (required for lookup)

**Output**:
```json
{
  "kpi_requirement": "Verify that the Entry Type (Mobile Number or Account Number) is tagged.",
  "datalayer_property": "vzdl.page.formData",
  "adobe_variables": "eVar27",
  "adobe_values": "Entry_Identifier",
  "mandatory_optional": "Mandatory",
  "business_context": "Track customer identifier type to understand lookup method preferences"
}
```

### Example 4: Transaction Event

**AC Step**: "Verify that the 'Cash' payment method is tagged when selected."

**Analysis**:
- Action: Payment method selection
- Element: "Cash"
- Context: Transaction/payment configuration
- DataLayer mapping: payment_type → `vzdl.txn.paymentType`
- eVar mapping: `vzdl.txn.paymentType` → `eVar48`
- Value: "Cash" or "Payment_Cash"
- Mandatory: Yes (critical for transaction tracking)

**Output**:
```json
{
  "kpi_requirement": "Verify that the 'Cash' payment method is tagged when selected.",
  "datalayer_property": "vzdl.txn.paymentType",
  "adobe_variables": "eVar48",
  "adobe_values": "Cash",
  "mandatory_optional": "Mandatory",
  "business_context": "Capture payment method to track payment channel preferences and conversion by method"
}
```

## Implementation Guidance

### When to Use Each DataLayer Property

| AC Type | DataLayer | eVar | Value Pattern | Mandatory |
|---------|-----------|------|---|---|
| Screen appears | `vzdl.page.name` | eVar70 | Display_{name} | Yes |
| Button tapped | `vzdl.event.value` | eVar16 | Tap_{name} or Select_{name} | Usually |
| Form entry | `vzdl.page.formData` | varies | Entry_{type} | If critical |
| Payment method | `vzdl.txn.paymentType` | eVar48 | {method} | Yes |
| Payment amount | `vzdl.txn.paymentAmt` | eVar35 | {amount} | Yes |
| TX status | `vzdl.txn.status` | eVar40 | {status} | Yes |
| Auth status | `vzdl.user.authStatus` | eVar232 | {status} | If relevant |
| Error | `vzdl.error.code` | eVar25 | {code} | Yes |

### Dictionary Words Must Be

1. **PascalCase** for display in Adobe: "PayYourBill" not "pay your bill"
2. **Present in dictionary** in rules for consistency
3. **Joined with value_joiner** (default: "_"): "Display_PayYourBill"

### Validation Rules

1. Every KPI must reference AC (auditability)
2. Every KPI must have either `datalayer_property` or Adobe Variables
3. DataLayer properties must exist in `RULES.datalayer_mappings`
4. eVars must match `RULES.bpk_evar_mappings`
5. No hallucinated AC steps
6. Business context should explain why this metric matters

## BPK Tech Spec CSV Integration

The generator references the BPK Tech Spec CSV to validate:

| Column | Usage | Example |
|--------|-------|---------|
| eVar | Validate Adobe variable assignment | eVar70 |
| DataLayer | Validate property name | vzdl.page.name |
| Definition | Understand business meaning | "Name of the page" |
| Values | Understand expected value format | dynamic |
| Mandatory or Optional | Set M/O status in output | "Mandatory" |

## Error Handling

If LLM cannot parse AC or no screenshot available:
1. Set `kpi_requirement` to the AC step verbatim
2. Set `datalayer_property` to null
3. Use default Adobe variable (eVar27)
4. Set `mandatory_optional` to "Optional" (conservative approach)
5. Add error note to `business_context`

## Testing the System Prompt

To validate the system prompt works correctly:

1. Create test AC with 3-5 clear steps
2. Provide sample screenshot
3. Run with test tagging_rules.json
4. Verify:
   - JSON is valid (can be parsed)
   - All KPIs reference AC
   - DataLayer properties exist in rules
   - eVars are assigned from mappings
   - Business context is meaningful
   - No hallucinated steps

## Continuous Improvement

As the BPK tagging implementation evolves:

1. **Add new DataLayer properties** to `datalayer_mappings`
2. **Create eVar mappings** in `bpk_evar_mappings`
3. **Expand dictionary** with new UI elements
4. **Update action aliases** for new interaction patterns
5. **Refine naming templates** if needed for specific contexts
6. **Test with real AC** to catch edge cases
