import os, pandas as pd, csv, json
from dotenv import load_dotenv
from datetime import datetime

load_dotenv()
OUTPUT_DIR = os.getenv("OUTPUT_DIR", "./TechSpecOutputs")

def _clean_json_string(s):
    """Helper to strip markdown code block markers (```json, ```) before parsing JSON."""
    if not isinstance(s, str):
        return s
    s = s.strip()
    if s.startswith('```json'):
        s = s[7:]
    if s.startswith('```'):
        s = s[3:]
    if s.endswith('```'):
        s = s[:-3]
    return s.strip()

def write_excel(rows:list)->str:
    """Write tech spec to Excel format (legacy format) with updated keys."""
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    flat_rows = []
    for row in rows:
        if row.get("eVar") == "LLM_PARSE_ERROR":
            try:
                possible_json = _clean_json_string(row.get("AdobeValues", ""))
                parsed = json.loads(possible_json)
                if isinstance(parsed, list):
                    for item in parsed:
                        item.setdefault("eVar", row.get("eVar", ""))
                        item.setdefault("DataLayer", row.get("DataLayer", ""))
                        item.setdefault("FieldType", row.get("FieldType", "Optional"))
                        item.setdefault("Definition", row.get("Definition", ""))
                        item.setdefault("AcceptanceCriteria", row.get("AcceptanceCriteria", ""))
                        flat_rows.append(item)
                    continue
            except Exception:
                pass
        flat_rows.append(row)
    df = pd.DataFrame([
        {"eVar": r.get("eVar", ""),
         "DataLayer": r.get("DataLayer", ""),
         "AdobeValues": r.get("AdobeValues", ""),
         "Definition": r.get("Definition", ""),
         "FieldType": r.get("FieldType", "Optional"),
         "AcceptanceCriteria": r.get("AcceptanceCriteria", "")}
        for r in flat_rows
    ])
    xlsx_files = [f for f in os.listdir(OUTPUT_DIR) if f.endswith('.xlsx')]
    if not xlsx_files:
        raise FileNotFoundError('No .xlsx files found in output directory.')
    xlsx_files.sort(key=lambda f: os.path.getmtime(os.path.join(OUTPUT_DIR, f)), reverse=True)
    out_path = os.path.join(OUTPUT_DIR, xlsx_files[0])
    with pd.ExcelWriter(out_path, engine="openpyxl") as w:
        df.to_excel(w, index=False, sheet_name="Reporting Requirement")
    return out_path

def write_csv(rows:list)->str:
    """Write tech spec to CSV format with updated keys."""
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_path = os.path.join(OUTPUT_DIR, f"BPK_AI_Tagging_TechSpec_{timestamp}.csv")
    flat_rows = []
    for row in rows:
        if row.get("eVar") == "LLM_PARSE_ERROR":
            try:
                possible_json = _clean_json_string(row.get("AdobeValues", ""))
                parsed = json.loads(possible_json)
                if isinstance(parsed, list):
                    for item in parsed:
                        item.setdefault("eVar", row.get("eVar", ""))
                        item.setdefault("DataLayer", row.get("DataLayer", ""))
                        item.setdefault("FieldType", row.get("FieldType", "Optional"))
                        item.setdefault("Definition", row.get("Definition", ""))
                        item.setdefault("AcceptanceCriteria", row.get("AcceptanceCriteria", ""))
                        item.setdefault("Values", row.get("Values", ""))
                        flat_rows.append(item)
                    continue
            except Exception:
                pass
        flat_rows.append(row)
    with open(out_path, 'w', newline='', encoding='utf-8') as csvfile:
        fieldnames = [
            'eVar',
            'DataLayer',
            'AdobeValues',
            'Definition',
            'FieldType',
            'AcceptanceCriteria',
            "Values"
        ]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for row in flat_rows:
            writer.writerow({
                'eVar': row.get('eVar', ''),
                'DataLayer': row.get('DataLayer', ''),
                'AdobeValues': row.get('AdobeValues', ''),
                'Definition': row.get('Definition', ''),
                'FieldType': row.get('FieldType', 'Optional'),
                'AcceptanceCriteria': row.get('AcceptanceCriteria', ''),
                'Values': row.get('Values', ''),
            })
    return out_path

def write_excel_with_datalayer(rows:list)->str:
    """Write tech spec to Excel format with DataLayer column and updated keys."""
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    flat_rows = []
    for row in rows:
        if row.get("eVar") == "LLM_PARSE_ERROR":
            try:
                possible_json = _clean_json_string(row.get("AdobeValues", ""))
                parsed = json.loads(possible_json)
                if isinstance(parsed, list):
                    for item in parsed:
                        item.setdefault("eVar", row.get("eVar", ""))
                        item.setdefault("DataLayer", row.get("DataLayer", ""))
                        item.setdefault("FieldType", row.get("FieldType", "Optional"))
                        item.setdefault("Definition", row.get("Definition", ""))
                        item.setdefault("AcceptanceCriteria", row.get("AcceptanceCriteria", ""))
                        item.setdefault("Values", row.get("Values", ""))
                        flat_rows.append(item)
                    continue
            except Exception:
                pass
        flat_rows.append(row)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    df = pd.DataFrame([
        {
            "eVar": r.get("eVar", ""),
            "DataLayer": r.get("DataLayer", ""),
            "AdobeValues": r.get("AdobeValues", ""),
            # "constant_datalayer": r.get("constant_datalayer", ""),
            # "bpk_evar_mappings": r.get("bpk_evar_mappings", ""),
            "Definition": r.get("Definition", ""),
            "FieldType": r.get("FieldType", "Optional"),
            "AcceptanceCriteria": r.get("AcceptanceCriteria", ""),
            "Values": r.get("Values", "")
        }
        for r in flat_rows
    ])
    out_path = os.path.join(OUTPUT_DIR, f"BPK_AI_Tagging_TechSpec_{timestamp}.xlsx")
    out_path = os.path.join(OUTPUT_DIR, "techspec.xlsx")
    with pd.ExcelWriter(out_path, engine="openpyxl") as w:
        df.to_excel(w, index=False, sheet_name="Reporting Requirement")
    return out_path
