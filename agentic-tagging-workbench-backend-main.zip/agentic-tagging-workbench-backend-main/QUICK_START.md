# Quick Start Guide: Two-Step Tagging Workflow

## 5-Minute Setup

### Prerequisites
- Python 3.8+
- Git installed
- Repository access
- Tech Spec file (.xlsx)

### Step 1: Configure Environment

Create/update `.env` file in project root:

```bash
# Required
CLONE_BASE=/home/user/ATTagger/Test
TECHSPEC_PATH=/path/to/your/techspec.xlsx
REPO_URL=https://github.com/your-org/your-repo

# Optional
REPO_BRANCH=main
OPENAI_API_KEY=sk-... # for LLM features
```

### Step 2: Generate Suggestions

```bash
cd core
python suggestTaggingAgent.py
```

**Output**: 
- `outputs/tagging_suggestions.json` - Machine-readable suggestions
- `outputs/tagging_suggestions.md` - Human-readable report
- Review the markdown file to verify suggestions

### Step 3: Apply Tagging

```bash
python applyTaggingAgent.py
```

**Output**:
- `outputs/apply_log.json` - Detailed log of changes
- Modified files in cloned repository
- `.backup` files created for each modified file

## Via API

### Start API Server

```bash
# From project root
python api_server.py
```

### Step 1: Generate Tech Spec

```bash
curl -X POST http://localhost:8000/generate-techspec \
  -H "Content-Type: application/json" \
  -d '{
    "ac_text": "Your acceptance criteria here...",
    "figma_file_url": "https://figma.com/..."
  }'
```

### Step 2: Generate Suggestions

```bash
curl -X POST http://localhost:8000/suggest-tagging-v2 \
  -H "Content-Type: application/json" \
  -d '{
    "repo_url": "https://github.com/your-org/your-repo",
    "branch": "main"
  }'
```

### Step 3: Review Suggestions

```bash
curl http://localhost:8000/suggestions-markdown | head -100
```

### Step 4: Apply Tagging

```bash
curl -X POST http://localhost:8000/apply-tagging-v2 \
  -H "Content-Type: application/json" \
  -d '{"force": false}'
```

### Step 5: Check Results

```bash
curl http://localhost:8000/apply-log | jq .summary
```

## Understanding the Workflow

### Phase 1: Suggestion (No Code Changes)
- Clones your repository
- Reads Tech Spec requirements
- Identifies pages and flows that need tagging
- **No modifications to your code**
- Generates reports for review

### Phase 2: Apply (Code Changes)
- Reads suggestion reports
- Finds 'common' folder in repository
- Copies Tagging folder to common/Tagging
- Injects useTagging hook into identified pages
- Creates backups for rollback
- Generates apply log

## Checking Results

### After Suggestion Phase
```bash
# View human-readable suggestions
cat core/outputs/tagging_suggestions.md

# View detailed JSON
cat core/outputs/tagging_suggestions.json | jq .
```

### After Apply Phase
```bash
# View apply log
cat core/outputs/apply_log.json | jq .summary

# Check modified files
cd /path/to/cloned/repo
git status

# View specific changes
git diff src/pages/CheckoutPage.jsx
```

## Common Commands

```bash
# View available API endpoints
curl http://localhost:8000 | jq .

# Check if API is running
curl http://localhost:8000/health

# Get full suggestions report
curl http://localhost:8000/suggestions-json | jq .

# Get apply details
curl http://localhost:8000/apply-log | jq '.pages_updated'
```

## Troubleshooting Quick Fixes

| Problem | Solution |
|---------|----------|
| "TechSpec not found" | Set `TECHSPEC_PATH` in .env |
| "Clone failed" | Check `REPO_URL` is correct |
| "Common folder not found" | Ensure repo has `src/common` or `common` folder |
| "Suggestions report not found" | Run suggestion step first |
| "No pages updated" | Check suggestion report for matches |

## Next Steps

1. **Review the comprehensive guides**:
   - `IMPLEMENTATION_GUIDE.md` - Complete implementation details
   - `TAGGING_AGENTS_README.md` - Architecture overview

2. **Test with a sample repository**:
   - Use a test branch first
   - Review before merging

3. **Integrate into CI/CD**:
   - Add API calls to your pipeline
   - Commit and push results

4. **Customize as needed**:
   - Adjust tagging rules if needed
   - Extend for custom requirements

## File Structure

```
project/
├── core/
│   ├── suggestTaggingAgent.py      ← Step 1 Agent
│   ├── applyTaggingAgent.py        ← Step 2 Agent
│   ├── tools/
│   │   └── repoStructureAnalyzer.py ← Utilities
│   ├── Tagging/
│   │   ├── index.js                ← Hook definition
│   │   └── dlStructure.js
│   └── outputs/
│       ├── tagging_suggestions.json  ← Output 1
│       ├── tagging_suggestions.md    ← Output 1
│       ├── apply_log.json            ← Output 2
│       └── .last_repo_root           ← Metadata
├── api_server.py                   ← API Server
├── IMPLEMENTATION_GUIDE.md         ← Full guide
├── TAGGING_AGENTS_README.md        ← Architecture
└── .env                            ← Configuration
```

## Key Outputs Explained

### tagging_suggestions.json
```json
{
  "summary": {
    "total_pages": 5,
    "pages_with_matches": 4,
    "total_items": 23
  },
  "suggestions_by_page": [
    {
      "page": "CheckoutPage",
      "file_locations": ["src/pages/CheckoutPage.jsx"],
      "tagging_items": [...]
    }
  ]
}
```

### apply_log.json
```json
{
  "summary": {
    "total_pages": 4,
    "pages_updated": 4,
    "files_updated": 4
  },
  "pages_updated": ["CheckoutPage", "PaymentPage"],
  "tagging_folder": "src/common/Tagging"
}
```

## Success Criteria

✅ Suggestion phase completes without errors
✅ Reports generated with pages identified
✅ Apply phase completes without errors
✅ `.backup` files created for modified files
✅ `src/pages/CheckoutPage.jsx` has new import: `import { useTagging }`
✅ Components have `useTagging()` hook call
✅ Apply log shows all pages updated

## Getting Help

1. Check `IMPLEMENTATION_GUIDE.md` section "Troubleshooting"
2. Review error messages in apply log
3. Check Python error output
4. Verify all prerequisites are installed
5. Check environment variables are set correctly

## Related Commands

```bash
# Install dependencies (if needed)
pip install -r requirements.txt

# Run tests
pytest core/tests/

# Check code quality
pylint core/suggestTaggingAgent.py

# View help
python core/suggestTaggingAgent.py --help
```

---

**You're ready to go!** Start with Step 1 (Suggestions) and review before applying.
