# Two-Step Tagging Workflow - Complete Implementation

## 🎯 What This Is

A complete **two-step tagging workflow** system for the Agentic Tagging Workbench that:

1. **Suggests** which pages need tagging (without code changes)
2. **Applies** tagging hooks to identified pages

This separation allows for review and approval between steps.

## 🚀 Quick Start (5 Minutes)

### 1. Configure
```bash
# Edit .env
CLONE_BASE=/home/user/ATTagger/Test
REPO_URL=https://github.com/your-org/your-repo
TECHSPEC_PATH=/path/to/techspec.xlsx
```

### 2. Suggest
```bash
cd core
python suggestTaggingAgent.py
```

### 3. Review
```bash
cat outputs/tagging_suggestions.md
```

### 4. Apply
```bash
python applyTaggingAgent.py
```

## 📚 Documentation

| Document | Purpose |
|----------|---------|
| [QUICK_START.md](QUICK_START.md) | 5-minute setup and usage |
| [IMPLEMENTATION_GUIDE.md](IMPLEMENTATION_GUIDE.md) | Complete guide with examples |
| [TAGGING_AGENTS_README.md](TAGGING_AGENTS_README.md) | Architecture and design |
| [IMPLEMENTATION_SUMMARY.md](IMPLEMENTATION_SUMMARY.md) | What was built and why |
| [FILE_INVENTORY.md](FILE_INVENTORY.md) | Complete file listing |

## 🏗️ Architecture

### Two Agents

```
┌─────────────────────────┐
│ Tech Spec + Repo URL    │
└────────────┬────────────┘
             │
             ▼
┌──────────────────────────────────────┐
│  Suggestion Agent                    │
│  suggestTaggingAgent.py              │
│                                      │
│  • Clone repository                  │
│  • Parse Tech Spec                   │
│  • Find pages and flows              │
│  • Generate report                   │
│  → NO CODE CHANGES                   │
└────────────┬─────────────────────────┘
             │
             ▼
        ┌─────────────────────┐
        │ Review Suggestions  │ ◄─── USER REVIEW
        └────────────┬────────┘
                     │
                     ▼
┌──────────────────────────────────────┐
│  Apply Agent                         │
│  applyTaggingAgent.py                │
│                                      │
│  • Find common folder                │
│  • Copy Tagging folder               │
│  • Inject useTagging hooks           │
│  • Create backups                    │
│  → MODIFIES CODE                     │
└────────────┬─────────────────────────┘
             │
             ▼
      ┌──────────────────┐
      │ Repository with  │
      │ Tagging Applied  │
      └──────────────────┘
```

## 📁 Files Created

### Agents
- `core/suggestTaggingAgent.py` - Suggestion agent (410 lines)
- `core/applyTaggingAgent.py` - Apply agent (rewritten, 300+ lines)

### Utilities
- `core/tools/repoStructureAnalyzer.py` - Analysis and injection (450+ lines)

### Documentation
- `QUICK_START.md` - 5-minute setup
- `IMPLEMENTATION_GUIDE.md` - Complete guide
- `TAGGING_AGENTS_README.md` - Architecture
- `IMPLEMENTATION_SUMMARY.md` - Summary
- `FILE_INVENTORY.md` - File listing

### API Endpoints
- `POST /suggest-tagging-v2` - Generate suggestions
- `POST /apply-tagging-v2` - Apply tagging
- `GET /suggestions-markdown` - View markdown
- `GET /suggestions-json` - View JSON
- `GET /apply-log` - View log

## 🎯 Key Features

✅ **Two-Step Workflow** - Separate analysis from implementation
✅ **Review Before Apply** - Check suggestions before code changes
✅ **Auto Backup** - Creates .backup files for rollback
✅ **Progress Tracking** - CLI spinners and progress indicators
✅ **Detailed Logging** - JSON logs of all operations
✅ **Smart Search** - Finds pages in various repo structures
✅ **Code Injection** - Adds imports and hooks to React components
✅ **Error Handling** - Comprehensive error messages
✅ **API & CLI** - Both interfaces supported
✅ **Documentation** - 1300+ lines of comprehensive docs

## 🔄 Workflow Example

### Via CLI
```bash
# Step 1: Generate suggestions (no code changes)
python suggestTaggingAgent.py
# Output: tagging_suggestions.json, tagging_suggestions.md

# Step 2: Review suggestions
cat outputs/tagging_suggestions.md

# Step 3: Apply tagging to identified pages
python applyTaggingAgent.py
# Output: apply_log.json, modified files with .backup

# Step 4: Check results
cat outputs/apply_log.json
```

### Via API
```bash
# Step 1: Generate suggestions
curl -X POST http://localhost:8000/suggest-tagging-v2 \
  -d '{"repo_url": "https://github.com/owner/repo"}'

# Step 2: Get suggestions
curl http://localhost:8000/suggestions-markdown

# Step 3: Apply tagging
curl -X POST http://localhost:8000/apply-tagging-v2

# Step 4: Check results
curl http://localhost:8000/apply-log
```

## 📊 What Gets Modified

### Files Touched
- `core/suggestTaggingAgent.py` - New file (410 lines)
- `core/applyTaggingAgent.py` - Modified (rewritten)
- `core/tools/repoStructureAnalyzer.py` - New file (450+ lines)
- `api_server.py` - Modified (added 6 endpoints, ~150 lines)

### Code Injection
```javascript
// BEFORE
const CheckoutPage = () => {
  const [items, setItems] = useState([]);
  return <div>...</div>;
};

// AFTER
import { useTagging } from '../../common/Tagging';

const CheckoutPage = () => {
  useTagging();
  // Tagging initialized for: CheckoutPage/checkout_flow/select_payment
  
  const [items, setItems] = useState([]);
  return <div>...</div>;
};
```

## 🛠️ How It Works

### Suggestion Phase
1. Clone repository
2. Parse Tech Spec to extract pages/flows
3. Scan repo structure to find matching files
4. Generate detailed reports

### Apply Phase
1. Load suggestions from Step 1
2. Find 'common' folder in repo
3. Copy Tagging folder to common/Tagging
4. Inject hooks into identified pages
5. Create backups for rollback

## 📋 Prerequisites

- Python 3.8+
- Git installed
- Tech Spec file (.xlsx)
- Repository URL (GitHub)
- 1-2 minutes per workflow execution

## 🔧 Configuration

```env
# Required
CLONE_BASE=/home/user/ATTagger/Test
TECHSPEC_PATH=/path/to/techspec.xlsx
REPO_URL=https://github.com/owner/repo

# Optional
REPO_BRANCH=main
OPENAI_API_KEY=sk-...
```

## 📈 Output Examples

### tagging_suggestions.json
```json
{
  "summary": {
    "total_pages": 5,
    "pages_with_matches": 4,
    "total_items": 23
  },
  "suggestions_by_page": [
    {
      "page": "CheckoutPage",
      "file_locations": ["src/pages/CheckoutPage.jsx"],
      "tagging_items": [...]
    }
  ]
}
```

### apply_log.json
```json
{
  "summary": {
    "total_pages": 4,
    "pages_updated": 4,
    "files_updated": 4
  },
  "pages_updated": ["CheckoutPage", "PaymentPage"],
  "tagging_folder": "src/common/Tagging"
}
```

## ✨ Key Components

### PageFlowIdentifier
Searches for pages and flows in repository structure

### RepoStructureAnalyzer
Finds 'common' folder and indexes files

### TaggingFolderManager
Copies Tagging folder and manages integration

### CodeInjector
Injects imports and hooks into React components

### ApplyTaggingEngine
Orchestrates the apply tagging process

## 🧪 Testing

### Manual Test
```bash
# Run suggestion
python suggestTaggingAgent.py

# Verify outputs
ls -la outputs/tagging_suggestions*
cat outputs/tagging_suggestions.md

# Run apply
python applyTaggingAgent.py

# Check modified files
ls -la /path/to/cloned/repo/src/pages/*.backup
```

### API Test
```bash
# Check endpoints
curl http://localhost:8000

# Run workflow
curl -X POST http://localhost:8000/suggest-tagging-v2 -d ...
curl http://localhost:8000/suggestions-markdown
curl -X POST http://localhost:8000/apply-tagging-v2
curl http://localhost:8000/apply-log
```

## 🚨 Error Handling

Both agents include:
- Input validation
- File existence checks
- Exception handling with logging
- Detailed error messages
- Non-zero exit codes on failure

## 🔄 Rollback

### Automatic Backup
Each modified file gets a `.backup` file:
```
src/pages/CheckoutPage.jsx.backup ← Original
src/pages/CheckoutPage.jsx        ← Modified
```

### Manual Recovery
```bash
# Restore from backup
cp src/pages/CheckoutPage.jsx.backup src/pages/CheckoutPage.jsx
```

## 📖 Learning Path

1. **Start Here**: Read [QUICK_START.md](QUICK_START.md)
2. **Then Learn**: Read [IMPLEMENTATION_GUIDE.md](IMPLEMENTATION_GUIDE.md)
3. **Deep Dive**: Read [TAGGING_AGENTS_README.md](TAGGING_AGENTS_README.md)
4. **Reference**: See [FILE_INVENTORY.md](FILE_INVENTORY.md)

## 🎓 Understanding the Code

### Key Files to Read
1. `core/suggestTaggingAgent.py` - Suggestion workflow
2. `core/applyTaggingAgent.py` - Apply workflow
3. `core/tools/repoStructureAnalyzer.py` - Utilities and helpers
4. `api_server.py` - API endpoints (new routes)

### Key Classes
- `PageFlowIdentifier` - Page/flow detection
- `TechSpecAnalyzer` - Spec parsing
- `RepoStructureAnalyzer` - Repo analysis
- `TaggingFolderManager` - Folder management
- `CodeInjector` - Code injection
- `ApplyTaggingEngine` - Apply orchestration

## 🌟 Highlights

✨ **Complete Solution** - Everything needed for two-step tagging
✨ **Well Documented** - 1300+ lines of documentation
✨ **Production Ready** - Error handling, logging, backups
✨ **Flexible** - CLI and API interfaces
✨ **Safe** - Automatic backups before modifications
✨ **Transparent** - Detailed logs of all operations
✨ **Extensible** - Easy to customize and extend

## 🤔 FAQ

**Q: Why two steps?**
A: Allows review before making code changes. More control and safety.

**Q: Is it safe?**
A: Yes! Automatic backups, no modifications until you approve.

**Q: Can I rollback?**
A: Yes! `.backup` files are created for each modified file.

**Q: Does it support TypeScript?**
A: Currently JavaScript. TypeScript support can be added.

**Q: Can I use the API?**
A: Yes! Full REST API with async/await support.

**Q: What if my repo structure is different?**
A: The system searches for 'common' folder automatically and can be extended.

## 📞 Support

### If Something Goes Wrong
1. Check [IMPLEMENTATION_GUIDE.md](IMPLEMENTATION_GUIDE.md) "Troubleshooting"
2. Review the error message in logs
3. Check environment variables are set
4. Verify prerequisites are installed

### Common Issues
- "Common folder not found" → Ensure repo has `common` or `src/common`
- "TechSpec not found" → Set `TECHSPEC_PATH` in .env
- "Clone failed" → Check `REPO_URL` is correct

## 📊 Stats

- **New Python Code**: 860 lines
- **Modified Python Code**: 300+ lines
- **Documentation**: 1350+ lines
- **API Endpoints**: 6 new
- **Classes**: 7 major
- **Functions**: 20+ major

## 🎉 Summary

A complete, production-ready **two-step tagging workflow** that:
- Separates analysis from implementation
- Allows review before code changes
- Provides automatic backups
- Includes comprehensive documentation
- Supports both CLI and API interfaces
- Handles errors gracefully
- Ready for deployment

## 🚀 Get Started

1. Read [QUICK_START.md](QUICK_START.md) (5 minutes)
2. Configure `.env` file
3. Run suggestion agent
4. Review suggestions
5. Run apply agent
6. Check results

---

**Questions?** See the documentation files listed above or review the inline code comments.

**Ready to go!** Start with [QUICK_START.md](QUICK_START.md) 🎯
