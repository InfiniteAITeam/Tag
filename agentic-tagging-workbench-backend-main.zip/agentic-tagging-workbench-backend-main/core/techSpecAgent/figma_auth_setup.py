import os
from playwright.sync_api import sync_playwright
import os
from dotenv import load_dotenv
load_dotenv()
FIGMA_LOGIN_URL = "https://www.figma.com/login"
AUTH_STATE_PATH = "figma_auth_state.json"

# Optionally, you can set these as environment variables for convenience
FIGMA_EMAIL = os.getenv("FIGMA_EMAIL")
FIGMA_PASSWORD = os.getenv("FIGMA_PASSWORD")


if not FIGMA_EMAIL or not FIGMA_PASSWORD:
    print(FIGMA_PASSWORD,"*"*10)
    raise ValueError("FIGMA_EMAIL and FIGMA_PASSWORD environment variables must be set.")


def run_auth_setup():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        context = browser.new_context()
        page = context.new_page()
        page.goto(FIGMA_LOGIN_URL)
        page.fill('input[name="email"]', FIGMA_EMAIL)
        page.fill('input[name="password"]', FIGMA_PASSWORD)
        page.click('button[type="submit"]')
        print("Please complete any SSO or 2FA steps in the browser window if prompted.")
        # Wait for any /files/ page, not just /files/recent
        page.wait_for_url("**/files/**", timeout=120000)
        print("Login successful! Saving authentication state...")
        context.storage_state(path=AUTH_STATE_PATH)
        print(f"Authentication state saved to {AUTH_STATE_PATH}")
        browser.close()

if __name__ == "__main__":
    run_auth_setup()
