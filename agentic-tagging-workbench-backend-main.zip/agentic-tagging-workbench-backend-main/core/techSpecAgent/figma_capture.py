import os
import asyncio
import json
import subprocess
import sys
import requests
from datetime import datetime
from dotenv import load_dotenv
from playwright.async_api import async_playwright
from .figma_auth_setup import run_auth_setup
from PIL import Image

load_dotenv()

AUTH_STATE_PATH = os.getenv("FIGMA_AUTH_STATE_PATH", "figma_auth_state.json")

def ensure_auth_state():
    if not os.path.exists(AUTH_STATE_PATH):
        print(f"{AUTH_STATE_PATH} not found. Running figma_auth_setup.py to generate it...")
        run_auth_setup()
    else:
        print(f"Using existing auth state: {AUTH_STATE_PATH}")

# Call this at the top of your capture script before using Playwright
ensure_auth_state()
FIGMA_FILE_URL = os.getenv("FIGMA_FILE_URL")
WAIT_SELECTOR = os.getenv("FIGMA_WAIT_SELECTOR", "[data-testid='canvas_zoom_controls']")
VIEW_W = int(os.getenv("FIGMA_VIEWPORT_WIDTH", "1600"))
VIEW_H = int(os.getenv("FIGMA_VIEWPORT_HEIGHT", "1000"))
OUTPUT_DIR = os.getenv("OUTPUT_DIR", "TechSpecOutputs")

UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/120.0.0.0 Safari/537.36"
)

LAUNCH_ARGS = [
    "--no-sandbox",
    "--disable-dev-shm-usage",
    "--enable-webgl",
    "--ignore-gpu-blocklist",
    "--use-gl=swiftshader",
    "--disable-blink-features=AutomationControlled",
]

FIGMA_TOKEN = os.getenv("FIGMA_TOKEN")
FILE_KEY = os.getenv("FIGMA_FILE_KEY")

def _normalize_figma_url(u: str) -> str:
    if not u:
        return u
    u = u.strip()
    if "figma.com/design/" in u:
        u = u.replace("figma.com/design/", "figma.com/file/")
    if "figma.com/proto/" in u:
        u = u.replace("figma.com/proto/", "figma.com/file/")
    return u

# Helper to get all frame node-ids from Figma API
def get_figma_frame_node_ids():
    if not FIGMA_TOKEN or not FILE_KEY:
        raise RuntimeError("FIGMA_TOKEN and FIGMA_FILE_KEY must be set in .env")
    headers = {"X-Figma-Token": FIGMA_TOKEN}
    url = f"https://api.figma.com/v1/files/{FILE_KEY}"
    resp = requests.get(url, headers=headers)
    resp.raise_for_status()
    data = resp.json()
    node_ids = []
    # Traverse document tree to find frames
    def traverse(node):
        if node.get("type") == "FRAME":
            node_ids.append(node["id"])
        for child in node.get("children", []):
            traverse(child)
    traverse(data["document"])
    return node_ids

async def capture_figma_screenshot() -> str:
    if not FIGMA_FILE_URL:
        raise RuntimeError("FIGMA_FILE_URL is required in .env")

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    out_path = os.path.join(OUTPUT_DIR, "figma_screen.png")
    crop_image(out_path, crop_percent=0.2)

    async with async_playwright() as p:
        # Use saved authentication state if available
        context_args = {
            "viewport": {"width": VIEW_W, "height": VIEW_H},
            "device_scale_factor": 2,
            "user_agent": UA,
            "locale": "en-US",
            "timezone_id": "America/Chicago",
            "extra_http_headers": {
                "Accept-Language": "en-US,en;q=0.9",
                "Referer": "https://www.figma.com/",
            },
        }
        if os.path.exists(AUTH_STATE_PATH):
            context_args["storage_state"] = AUTH_STATE_PATH
        ctx = await p.chromium.launch(headless=True, args=LAUNCH_ARGS)
        browser = ctx
        try:
            if os.path.exists(AUTH_STATE_PATH):
                context = await browser.new_context(**context_args)
            else:
                context = await browser.new_context(**context_args)
            # Hide webdriver fingerprint
            await context.add_init_script(
                "Object.defineProperty(navigator, 'webdriver', {get: () => undefined});"
            )
            page = await context.new_page()

            # Normalize URL to /file/ form (more scrape-friendly)
            url = _normalize_figma_url(FIGMA_FILE_URL)
            resp = await page.goto(url, wait_until="domcontentloaded")

            # If blocked, save HTML for inspection
            if resp and resp.status >= 400:
                dbg = os.path.join(OUTPUT_DIR, "figma_error.html")
                try:
                    html = await resp.text()
                except Exception:
                    html = await page.content()
                with open(dbg, "w", encoding="utf-8") as f:
                    f.write(html)
                raise RuntimeError(f"HTTP {resp.status} from Figma. Saved {dbg}")

            # Robust paint waits
            try:
                await page.wait_for_load_state("networkidle", timeout=30_000)
            except Exception:
                pass

            # Wait for a real canvas; fallback to toolbar selector
            try:
                await page.locator("canvas").first.wait_for(
                    state="visible", timeout=30_000
                )
            except Exception:
                try:
                    await page.wait_for_selector(WAIT_SELECTOR, timeout=15_000)
                except Exception:
                    pass

            # Screenshot the canvas container (avoid full_page on infinite-canvas apps)
            container = page.locator("div:has(canvas)").first
            if await container.count() > 0:
                await container.screenshot(path=out_path)
            else:
                await page.screenshot(path=out_path)

            # Sanity check: ensure it isn't tiny/blank
            if not (os.path.exists(out_path) and os.path.getsize(out_path) > 10_000):
                dbg2 = os.path.join(OUTPUT_DIR, "figma_403_or_blank.html")
                try:
                    html = await page.content()
                except Exception:
                    html = "<no page content available>"
                with open(dbg2, "w", encoding="utf-8") as f:
                    f.write(html)
                raise RuntimeError(f"Screenshot empty/blocked. Saved {dbg2}")

            return out_path
        finally:
            await browser.close()

def capture_sync() -> str:
    return asyncio.run(capture_figma_screenshot())

MULTI_SCREEN_URLS = [
    # Add your Figma URLs here (with different node-ids or pages)
    # Example:
    # "https://www.figma.com/file/bYvHlqTQN966zEF7s9hlXm/BPK-Design?node-id=9300-62164",
    # "https://www.figma.com/file/bYvHlqTQN966zEF7s9hlXm/BPK-Design?node-id=1234-5678",
]

async def capture_multiple_figma_screenshots():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    async with async_playwright() as p:
        context_args = {
            "viewport": {"width": VIEW_W, "height": VIEW_H},
            "device_scale_factor": 2,
            "user_agent": UA,
            "locale": "en-US",
            "timezone_id": "America/Chicago",
            "extra_http_headers": {
                "Accept-Language": "en-US,en;q=0.9",
                "Referer": "https://www.figma.com/",
            },
        }
        if os.path.exists(AUTH_STATE_PATH):
            context_args["storage_state"] = AUTH_STATE_PATH
        browser = await p.chromium.launch(headless=True, args=LAUNCH_ARGS)
        try:
            context = await browser.new_context(**context_args)
            await context.add_init_script(
                "Object.defineProperty(navigator, 'webdriver', {get: () => undefined});"
            )
            page = await context.new_page()
            for idx, url in enumerate(MULTI_SCREEN_URLS, 1):
                norm_url = _normalize_figma_url(url)
                resp = await page.goto(norm_url, wait_until="domcontentloaded")
                try:
                    await page.wait_for_load_state("networkidle", timeout=30_000)
                except Exception:
                    pass
                try:
                    await page.locator("canvas").first.wait_for(
                        state="visible", timeout=30_000
                    )
                except Exception:
                    try:
                        await page.wait_for_selector(WAIT_SELECTOR, timeout=15_000)
                    except Exception:
                        pass
                container = page.locator("div:has(canvas)").first
                out_path = os.path.join(OUTPUT_DIR, f"figma_screen_{idx}.png")
                if await container.count() > 0:
                    await container.screenshot(path=out_path)
                else:
                    await page.screenshot(path=out_path)
                # Crop the image after saving
                crop_image(out_path, crop_percent=0.2)
                print(f"Saved and cropped screenshot: {out_path}")
        finally:
            await browser.close()

def capture_multiple_sync():
    asyncio.run(capture_multiple_figma_screenshots())

async def capture_all_figma_frames():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    node_ids = get_figma_frame_node_ids()
    async with async_playwright() as p:
        context_args = {
            "viewport": {"width": VIEW_W, "height": VIEW_H},
            "device_scale_factor": 2,
            "user_agent": UA,
            "locale": "en-US",
            "timezone_id": "America/Chicago",
            "extra_http_headers": {
                "Accept-Language": "en-US,en;q=0.9",
                "Referer": "https://www.figma.com/",
            },
        }
        if os.path.exists(AUTH_STATE_PATH):
            context_args["storage_state"] = AUTH_STATE_PATH
        browser = await p.chromium.launch(headless=True, args=LAUNCH_ARGS)
        try:
            context = await browser.new_context(**context_args)
            await context.add_init_script(
                "Object.defineProperty(navigator, 'webdriver', {get: () => undefined});"
            )
            page = await context.new_page()
            for idx, node_id in enumerate(node_ids, 1):
                # Build Figma URL for each frame
                url = f"https://www.figma.com/file/{FILE_KEY}?node-id={node_id}"
                resp = await page.goto(url, wait_until="domcontentloaded")
                try:
                    await page.wait_for_load_state("networkidle", timeout=30_000)
                except Exception:
                    pass
                try:
                    await page.locator("canvas").first.wait_for(
                        state="visible", timeout=30_000
                    )
                except Exception:
                    try:
                        await page.wait_for_selector(WAIT_SELECTOR, timeout=15_000)
                    except Exception:
                        pass
                container = page.locator("div:has(canvas)").first
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                out_path = os.path.join(OUTPUT_DIR, f"figma_frame_{idx}_{node_id}_{timestamp}.png")
                if await container.count() > 0:
                    await container.screenshot(path=out_path)
                else:
                    await page.screenshot(path=out_path)
                # Crop the image after saving (example: top-left 992x620 from 3200x2000)
                crop_image(out_path, crop_percent=0.2)
                print(f"Saved and cropped screenshot: {out_path}")
        finally:
            await browser.close()

def capture_all_frames_sync():
    asyncio.run(capture_all_figma_frames())

# crop_box = (0, 0, 992, 620)  # (left, upper, right, lower) - adjust as needed
# crop_image(out_path, crop_box)
def crop_image(image_path, crop_percent=0.2, output_path=None):
    """
    Crop the image at image_path by removing crop_percent (e.g., 0.2 for 20%) from each side.
    If output_path is None, overwrite the original image.
    """
    with Image.open(image_path) as img:
        w, h = img.size
        left = int(w * crop_percent)
        upper = int(h * crop_percent)
        right = int(w * (1 - crop_percent))
        lower = int(h * (1 - crop_percent))
        cropped = img.crop((left, upper, right, lower))
        if output_path is None:
            cropped.save(image_path)
        else:
            cropped.save(output_path)




