#!/usr/bin/env python3
"""Test script to verify the new hook generation pattern."""

import json
import sys
from pathlib import Path

# Add core to path
sys.path.insert(0, str(Path(__file__).parent / "core"))

from tools.repoStructureAnalyzer import CodeInjector


def test_hook_generation():
    """Test the hook generation with the new pattern."""
    print("=" * 60)
    print("Testing Hook Generation Pattern")
    print("=" * 60)
    print()
    
    # Create a code injector
    injector = CodeInjector("../common/Tagging")
    
    # Sample hook config
    hook_config = {
        'page': 'pymt with chq',
        'flow': 'chq',
        'event': 'event117',
        'isFlowNameUpdate': True,
    }
    
    # Sample component content
    sample_component = """import React from 'react';
import { useState } from 'react';

function PaymentPage() {
  const [amount, setAmount] = useState(0);
  
  return (
    <div className="payment-container">
      <h1>Make Payment</h1>
      <input type="number" value={amount} onChange={e => setAmount(e.target.value)} />
      <button onClick={() => processPayment(amount)}>Pay</button>
    </div>
  );
}

export default PaymentPage;"""
    
    print("Original Component:")
    print("-" * 60)
    print(sample_component)
    print()
    print()
    
    # Inject imports
    print("Step 1: Injecting Imports")
    print("-" * 60)
    modified = injector._inject_import(sample_component, "import { useTagging } from '../common/Tagging';")
    print(modified)
    print()
    print()
    
    # Inject hook call
    print("Step 2: Injecting Hook Call")
    print("-" * 60)
    modified = injector._inject_hook_call(modified, hook_config)
    print(modified)
    print()
    print()
    
    # Verify the pattern
    print("Step 3: Pattern Verification")
    print("-" * 60)
    expected_patterns = [
        "const { trackPageLoad } = useTagging();",
        "useEffect(() => {",
        "trackPageLoad({",
        f"pageName: '{hook_config['page']}'",
        f"flow: '{hook_config['flow']}'",
        f"event: '{hook_config['event']}'",
        "isFlowNameUpdate: true,",
    ]
    
    all_found = True
    for pattern in expected_patterns:
        if pattern in modified:
            print(f"✓ Found: {pattern}")
        else:
            print(f"✗ Missing: {pattern}")
            all_found = False
    
    print()
    if all_found:
        print("✓ All patterns found! Hook generation is working correctly.")
    else:
        print("✗ Some patterns are missing. Check the implementation.")
    
    return all_found


if __name__ == "__main__":
    success = test_hook_generation()
    sys.exit(0 if success else 1)
