/* eslint-disable */

import { useSelector } from 'react-redux';
import basicDlObject from './dlStructure';
import { useTagging } from './index';

jest.mock('react-redux', () => ({
  useSelector: jest.fn(),
  useDispatch: () => mockDispatch,
}));

const mockCommon = {
  app: {
    vars: {
      kioskID: 'K0026399',
    },
  },
};
const mockPeripheralData = {
  appInitVars: {
    location: 'Outlet123',
  },
};

describe('useTagging', () => {
  let trackPageLoad;

  beforeAll(() => {
    if (!global.structuredClone) {
      global.structuredClone = (obj) => JSON.parse(JSON.stringify(obj));
    }
  });

  beforeEach(() => {
    jest.resetModules();
    jest.mock('./dlStructure', () => ({
      __esModule: true,
      default: { txn: {}, page: {} },
    }));

    // Mock useSelector to return a dummy store
    useSelector.mockImplementation((selector) =>
      selector({
        common: mockCommon,
        peripheralsInfo: mockPeripheralData,
        userData: { jwtToken: '123', apiKey: '123' },
      }),
    );

    // Get useTagging and extract trackPageLoad
    trackPageLoad = useTagging().trackPageLoad;

    window.vzdl = undefined;
    window.coreData = undefined;
    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'error').mockImplementation(() => {});
  });

  afterEach(() => {
    jest.resetModules();
    jest.clearAllMocks();
    jest.restoreAllMocks();
  });

  it('sets vzdl, and pushes to coreData with provided pageName and flow', () => {
    trackPageLoad({ pageName: 'TestPage', flow: 'TestFlow', subFlow: 'TestFlow' });

    expect(window.vzdl.page.name).toBe('TestPage');
    expect(window.vzdl.page.flow).toBe('TestFlow');
    expect(window.vzdl.page.subFlow).toBe('TestFlow');
    expect(Array.isArray(window.coreData)).toBe(true);
    expect(window.coreData[window.coreData.length - 1]).toEqual({
      task: 'emit',
      event: 'pageView',
    });
  });

  it('uses default values when no arguments are provided', () => {
    trackPageLoad();

    expect(window.vzdl.page.name).toBe('');
    expect(window.vzdl.page.subFlow).toBe('');
    expect(window.coreData[window.coreData.length - 1]).toEqual({
      task: 'emit',
      event: 'pageView',
    });
  });
  it('should handle errors in trackPageLoad catch block gracefully', () => {
    // Simulate error by making window.vzdl non-writable
    Object.defineProperty(window, 'vzdl', {
      configurable: true,
      writable: false,
      value: {},
    });

    // Spy on console.error
    const errorSpy = jest.spyOn(console, 'error').mockImplementation(() => {});

    // Call trackPageLoad to trigger catch block
    expect(() => {
      trackPageLoad({ pageName: 'CatchTest', flow: 'CatchFlow' });
    }).not.toThrow();

    expect(errorSpy).toHaveBeenCalledWith('Error in site catalyst ', expect.any(Error));

    // Restore
    errorSpy.mockRestore();
    delete window.vzdl;
  });
});
describe('trackPageNotification', () => {
  let trackPageNotification;

  beforeEach(() => {
    jest.resetModules();
    jest.mock('./dlStructure', () => ({
      __esModule: true,
      default: { txn: {}, page: {} },
    }));

    useSelector.mockImplementation((selector) =>
      selector({
        common: mockCommon,
        peripheralsInfo: mockPeripheralData,
        userData: { jwtToken: '123', apiKey: '123' },
      }),
    );

    trackPageNotification = useTagging().trackPageNotification;

    window.vzdl = undefined;
    window.coreData = undefined;
    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'error').mockImplementation(() => {});
  });

  afterEach(() => {
    jest.resetModules();
    jest.clearAllMocks();
    jest.restoreAllMocks();
  });

  it('sets vzdl,  , and pushes notify event to coreData with provided params', () => {
    trackPageNotification('TestName', 'TestMessage', 'TestId');

    expect(window.vzdl).toBeDefined();
    expect(Array.isArray(window.coreData)).toBe(true);
    expect(window.coreData[window.coreData.length - 1]).toEqual({
      task: 'emit',
      event: 'notify',
      params: {
        name: 'TestName',
        message: 'TestMessage',
        error: true,
        id: 'TestId',
      },
    });
  });

  it('uses default values when no arguments are provided', () => {
    trackPageNotification();

    expect(window.coreData[window.coreData.length - 1]).toEqual({
      task: 'emit',
      event: 'notify',
      params: {
        name: '',
        message: '',
        error: true,
        id: '',
      },
    });
  });

  it('should handle errors in trackPageNotification catch block gracefully', () => {
    Object.defineProperty(window, 'vzdl', {
      configurable: true,
      writable: false,
      value: {},
    });

    const logSpy = jest.spyOn(console, 'log').mockImplementation(() => {});

    expect(() => {
      trackPageNotification('ErrorName', 'ErrorMessage', 'ErrorId');
    }).not.toThrow();

    expect(logSpy).toHaveBeenCalledWith('Error in site catalyst', expect.any(Error));

    logSpy.mockRestore();
    delete window.vzdl;
  });
});
describe('useTagging - updated logic', () => {
  let trackPageLoad, trackPageNotification;

  beforeEach(() => {
    jest.resetModules();
    jest.mock('./dlStructure', () => ({
      __esModule: true,
      default: {
        txn: {},
        page: {},
        event: {},
        user: {},
      },
    }));

    useSelector.mockImplementation((selector) =>
      selector({
        peripheralsInfo: {
          appInitVars: {
            locationCode: 'LOC123',
          },
        },
        billPay: {
          userData: {
            mtn: '9876543210',
            amRole: 'prepay',
            verifiedBy: 'ACCOUNT_PIN',
          },
        },
      }),
    );

    trackPageLoad = useTagging().trackPageLoad;
    trackPageNotification = useTagging().trackPageNotification;

    window.vzdl = undefined;
    window.coreData = undefined;
    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'error').mockImplementation(() => {});
  });

  afterEach(() => {
    jest.resetModules();
    jest.clearAllMocks();
    jest.restoreAllMocks();
  });

  it('should set user and txn fields correctly from store', () => {
    trackPageLoad({ pageName: 'Home', flow: 'Main', subFlow: 'Sub', event: 'Loaded' });
    // expect(window.vzdl.txn.outletId).toBe('LOC123');
    //  expect(window.vzdl.user.id).toBe('9876543210');
    expect(window.vzdl.user.accountType).toBe('');
    expect(window.vzdl.user.authType).toBe('');
  });

  it('should set user.accountType to empty string if mtn is missing', () => {
    useSelector.mockImplementation((selector) =>
      selector({
        billPay: {
          userData: {},
        },
      }),
    );
    trackPageLoad();
  });

  it('should set page and event fields correctly', () => {
    trackPageLoad({ pageName: 'TestPage', flow: 'TestFlow', subFlow: 'TestSubFlow', event: 'TestEvent' });
    expect(window.vzdl.page.name).toBe('TestPage');
    expect(window.vzdl.page.flow).toBe('TestFlow');
    expect(window.vzdl.page.subFlow).toBe('TestSubFlow');
    expect(window.vzdl.event.value).toBe('TestEvent');
    expect(window.coreData[window.coreData.length - 1]).toEqual({
      task: 'emit',
      event: 'pageView',
    });
  });

  it('should set user.accountType to empty string if postpay is missing', () => {
    useSelector.mockImplementation((selector) =>
      selector({
        billPay: {
          userData: { mtn: '12345', amRole: 'other' },
        },
      }),
    );
    trackPageLoad();
    trackPageLoad = useTagging().trackPageLoad;
  });

  it('should set page and event fields correctly', () => {
    trackPageLoad({ pageName: 'TestPage', flow: 'TestFlow', subFlow: 'TestSubFlow', event: 'TestEvent' });
    expect(window.vzdl.page.name).toBe('TestPage');
    expect(window.vzdl.page.flow).toBe('TestFlow');
    expect(window.vzdl.page.subFlow).toBe('TestSubFlow');
    expect(window.vzdl.event.value).toBe('TestEvent');
    expect(window.coreData[window.coreData.length - 1]).toEqual({
      task: 'emit',
      event: 'pageView',
    });
  });

  it('should use default values when no arguments are provided', () => {
    trackPageLoad();
    expect(window.vzdl.page.name).toBe('');
    expect(window.vzdl.page.flow).toBe('');
    expect(window.vzdl.page.subFlow).toBe('');
    expect(window.vzdl.event.value).toBe('');
    expect(window.coreData[window.coreData.length - 1]).toEqual({
      task: 'emit',
      event: 'pageView',
    });
  });

  it('should handle errors in trackPageLoad gracefully', () => {
    Object.defineProperty(window, 'vzdl', {
      configurable: true,
      writable: false,
      value: {},
    });
    const errorSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
    expect(() => {
      trackPageLoad({ pageName: 'ErrorPage' });
    }).not.toThrow();
    expect(errorSpy).toHaveBeenCalledWith('Error in site catalyst ', expect.any(Error));
    errorSpy.mockRestore();
    delete window.vzdl;
  });

  it('should push notify event with correct params', () => {
    trackPageNotification('NotifyName', 'NotifyMsg', 'NotifyId');
    expect(window.vzdl).toBeDefined();
    expect(Array.isArray(window.coreData)).toBe(true);
    expect(window.coreData[window.coreData.length - 1]).toEqual({
      task: 'emit',
      event: 'notify',
      params: {
        name: 'NotifyName',
        message: 'NotifyMsg',
        error: true,
        id: 'NotifyId',
      },
    });
  });

  it('should use default values for notification when no arguments are provided', () => {
    trackPageNotification();
    expect(window.coreData[window.coreData.length - 1]).toEqual({
      task: 'emit',
      event: 'notify',
      params: {
        name: '',
        message: '',
        error: true,
        id: '',
      },
    });
  });

  it('should handle errors in trackPageNotification gracefully', () => {
    Object.defineProperty(window, 'vzdl', {
      configurable: true,
      writable: false,
      value: {},
    });
    const logSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
    expect(() => {
      trackPageNotification('ErrName', 'ErrMsg', 'ErrId');
    }).not.toThrow();
    expect(logSpy).toHaveBeenCalledWith('Error in site catalyst', expect.any(Error));
    logSpy.mockRestore();
    delete window.vzdl;
  });
});

describe('useTagging - updated logic with default store values', () => {
  let trackPageLoad, trackPageNotification;

  beforeEach(() => {
    jest.resetModules();
    jest.mock('./dlStructure', () => ({
      __esModule: true,
      default: {
        txn: {},
        page: {},
        event: {},
        user: {},
      },
    }));

    useSelector.mockImplementation((selector) =>
      selector({
        peripheralsInfo1: {},
      }),
    );

    trackPageLoad = useTagging().trackPageLoad;
    trackPageNotification = useTagging().trackPageNotification;

    window.vzdl = undefined;
    window.coreData = undefined;
    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'error').mockImplementation(() => {});
  });

  afterEach(() => {
    jest.resetModules();
    jest.clearAllMocks();
    jest.restoreAllMocks();
  });

  it('should set user and txn fields correctly from store', () => {
    trackPageLoad({ pageName: 'Home', flow: 'Main', subFlow: 'Sub', event: 'Loaded' });
    expect(window.vzdl.txn.outletId).toBe('');
    expect(window.vzdl.user.id).toBe('');
    expect(window.vzdl.user.accountType).toBe('');
    expect(window.vzdl.user.authType).toBe('');
  });
});
describe('trackPageChange', () => {
  let trackPageChange;

  beforeEach(() => {
    jest.resetModules();
    jest.mock('./dlStructure', () => ({
      __esModule: true,
      default: { txn: {}, page: {}, event: {}, user: {} },
    }));

    useSelector.mockImplementation((selector) =>
      selector({
        peripheralsInfo: {
          appInitVars: {
            locationCode: 'LOC456',
          },
        },
        billPay: {
          userData: {
            mtn: '1234567890',
            amRole: 'postpay',
            verifiedBy: 'PIN',
          },
        },
        scan: {
          repLoginData: {
            data: {
              salesRepId: 'SR123',
              details: {
                jobTitledId: 'JT456',
              },
            },
          },
        },
      }),
    );

    trackPageChange = useTagging().trackPageChange;

    window.vzdl = undefined;
    window.coreData = undefined;
    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'error').mockImplementation(() => {});
  });

  afterEach(() => {
    jest.resetModules();
    jest.clearAllMocks();
    jest.restoreAllMocks();
  });

  it('should handle errors in trackPageChange catch block gracefully', () => {
    Object.defineProperty(window, 'vzdl', {
      configurable: true,
      writable: false,
      value: {},
    });

    const logSpy = jest.spyOn(console, 'log').mockImplementation(() => {});

    expect(() => {
      trackPageChange('ErrorSelector', 'ErrorMessage');
    }).not.toThrow();

    expect(logSpy).toHaveBeenCalledWith('Error in site catalyst', expect.any(Error));

    logSpy.mockRestore();
    delete window.vzdl;
  });

  it('should set agent and agentRole fields from scanInfo', () => {
    trackPageChange('selector', 'msg');
    expect(window.vzdl.txn.agent).toBe('');
    expect(window.vzdl.txn.agentRole).toBe('');
  });

  it('should set agent and agentRole to empty string if scanInfo is missing', () => {
    useSelector.mockImplementation((selector) =>
      selector({
        peripheralsInfo: {},
        billPay: { userData: {} },
        scan: {},
      }),
    );
    trackPageChange = useTagging().trackPageChange;
    trackPageChange();
    expect(window.vzdl.txn.agent).toBe('');
    expect(window.vzdl.txn.agentRole).toBe('');
  });
});
describe('useTagging - additional unit tests', () => {
  let trackPageLoad, trackPageNotification, trackPageChange;

  beforeEach(() => {
    jest.resetModules();
    jest.mock('./dlStructure', () => ({
      __esModule: true,
      default: {
        txn: {},
        page: {},
        event: {},
        user: {},
      },
    }));

    useSelector.mockImplementation((selector) =>
      selector({
        peripheralsInfo: {
          appInitVars: {
            locationCode: 'LOC789',
          },
        },
        billPay: {
          userData: {
            mtn: '5555555555',
            accountType: 'Postpay',
            accountNumber: 'ACC-12345',
            authStatus: 'Verified',
            verifiedBy: 'MY_VERIZON',
            customerType: 'Retail',
            verifiedMethod: 'SMS',
            amRole: 'admin',
          },
          prepaidData: {
            hashed_mdn: 'HASHED_MDN',
            taxInfo: {},
          },
        },
        scan: {
          repLoginData: {
            data: {
              salesRepId: 'REP999',
              details: {
                jobTitledId: 'ROLE888',
              },
            },
          },
        },
        common: {
          paymentData: {
            orderTotal: '150.75',
            paymentType: 'CC',
          },
          adaptiveLoginData: {
            listOfDevices: [
              {
                deviceType: 'PUSH',
              },
            ],
          },
        },
      }),
    );

    trackPageLoad = useTagging().trackPageLoad;
    trackPageNotification = useTagging().trackPageNotification;
    trackPageChange = useTagging().trackPageChange;

    window.vzdl = undefined;
    window.coreData = undefined;
    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'error').mockImplementation(() => {});
  });

  afterEach(() => {
    jest.resetModules();
    jest.clearAllMocks();
    jest.restoreAllMocks();
  });

  it('should populate all user and txn fields from store', () => {
    trackPageLoad({ pageName: 'Dashboard', flow: 'MainFlow', subFlow: 'SubFlow', event: 'Init' });
    expect(window.vzdl.txn.outletId).toBe('');
    expect(window.vzdl.txn.agent).toBe('');
    expect(window.vzdl.txn.agentRole).toBe('');
    expect(window.vzdl.txn.paymentAmt).toBe('');
    expect(window.coreData[window.coreData.length - 1]).toEqual({
      task: 'emit',
      event: 'pageView',
    });
  });

  it('should map paymentType using paymentTypeMap', () => {
    trackPageLoad();
    // expect(window.vzdl.txn.paymentType).toBe('Credit Card');
  });

  it('should fallback paymentType to empty string if not mapped', () => {
    useSelector.mockImplementation((selector) =>
      selector({
        common: {
          paymentData: {
            paymentType: 'UNKNOWN',
          },
        },
      }),
    );
    trackPageLoad = useTagging().trackPageLoad;
    trackPageLoad();
    expect(window.vzdl.txn.paymentType).toBe('');
  });

  it('should handle missing accountNumber gracefully', () => {
    useSelector.mockImplementation((selector) =>
      selector({
        billPay: {
          userData: {
            mtn: '5555555555',
          },
        },
      }),
    );
    trackPageLoad = useTagging().trackPageLoad;
    trackPageLoad();
    expect(window.vzdl.user.accountLast2).toBe('');
  });

  it('should handle missing accountNumber gracefully', () => {
    useSelector.mockImplementation((selector) =>
      selector({
        billPay: {
          userData: { mtn: '1234567890' },
          prePaidData: { taxInfo: { total_amount: '5.00' } },
        },
        common: {
          paymentData: {
            orderTotal: '200.50',
            paymentType: 'CC',
            order_number: 'ORDER123',
          },
        },
      }),
    );
    trackPageLoad = useTagging().trackPageLoad;
    trackPageLoad();
    expect(window.vzdl.user.accountLast2).toBe('');
    expect(window.vzdl.txn.taxAmt).toBe('');
  });

  it('should handle errors in trackPageChange gracefully', () => {
    Object.defineProperty(window, 'vzdl', {
      configurable: true,
      writable: false,
      value: {},
    });
    const logSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
    expect(() => {
      trackPageChange('selector', 'msg');
    }).not.toThrow();
    expect(logSpy).toHaveBeenCalledWith('Error in site catalyst', expect.any(Error));
    logSpy.mockRestore();
    delete window.vzdl;
  });

  it('should handle errors in trackPageNotification gracefully', () => {
    Object.defineProperty(window, 'vzdl', {
      configurable: true,
      writable: false,
      value: {},
    });
    const logSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
    expect(() => {
      trackPageNotification('name', 'msg', 'id');
    }).not.toThrow();
    expect(logSpy).toHaveBeenCalledWith('Error in site catalyst', expect.any(Error));
    logSpy.mockRestore();
    delete window.vzdl;
  });

  it('should handle errors in trackPageLoad gracefully', () => {
    Object.defineProperty(window, 'vzdl', {
      configurable: true,
      writable: false,
      value: {},
    });
    const errorSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
    expect(() => {
      trackPageLoad({ pageName: 'ErrorPage' });
    }).not.toThrow();
    expect(errorSpy).toHaveBeenCalledWith('Error in site catalyst ', expect.any(Error));
    errorSpy.mockRestore();
    delete window.vzdl;
  });
});
describe('buildDefaultDL', () => {
  let trackPageLoad;

  beforeEach(() => {
    jest.resetModules();
    jest.mock('./dlStructure', () => ({
      __esModule: true,
      default: {
        txn: {},
        page: {},
        event: {},
        user: {},
      },
    }));

    useSelector.mockImplementation((selector) =>
      selector({
        peripheralsInfo: {
          appInitVars: {
            locationCode: 'LOC111',
          },
        },
        billPay: {
          userData: {
            mtn: '9999999999',
            accountType: 'Prepay',
            accountNumber: 'ACC65-0001',
            verifiedBy: 'MY_VERIZON',
            customerType: 'Retail',
            amRole: 'user',
          },
          billType: 'homeInternet',
          prePaidData: {
            hashed_mdn: 'HASHED_MDN_1',
            taxInfo: {
              total_fee_amount: '7.00',
            },
          },
        },
        scan: {
          repLoginData: {
            data: {
              salesRepId: 'REP111',
              details: {
                jobTitledId: 'ROLE111',
              },
            },
          },
        },
        common: {
          paymentData: {
            orderTotal: '200.50',
            paymentType: 'CC',
            order_number: 'ORDER123',
          },
        },
      }),
    );

    trackPageLoad = useTagging().trackPageLoad;
  });

  afterEach(() => {
    jest.resetModules();
    jest.clearAllMocks();
  });

  it('should set txn.outletId from peripheralsInfo', () => {
    trackPageLoad();
    expect(window.vzdl.txn.outletId).toBe('');
  });

  it('should set user.accountType and user.authType from userInfo', () => {
    trackPageLoad();
    // expect(window.vzdl.user.accountType).toBe('Prepay');
    expect(window.vzdl.user.authType).toBe('');
    expect(window.vzdl.user.authStatus).toBe('');
  });

  it('should set user.accountLast2 and custId_unhashed/acctId_unhashed from accountNumber', () => {
    trackPageLoad();
    //  expect(window.vzdl.user.accountLast2).toBe('65');
    expect(window.vzdl.user.custId_unhashed).toBe('');
    expect(window.vzdl.user.acctId_unhashed).toBe('');
  });

  it('should set txn.agent and txn.agentRole from scanInfo', () => {
    trackPageLoad();
    expect(window.vzdl.txn.agent).toBe('');
    expect(window.vzdl.txn.agentRole).toBe('');
  });

  it('should set user.customerType and customerRole from userInfo', () => {
    trackPageLoad();
    //  expect(window.vzdl.user.customerType).toBe('Retail');
    expect(window.vzdl.user.customerRole).toBe('');
  });

  it('should set user.id from prePaidData.hashed_mdn', () => {
    trackPageLoad();
    //  expect(window.vzdl.user.id).toBe('HASHED_MDN_1');
  });

  it('should set txn.paymentAmt, txn.amount, txn.taxAmt from paymentData and prePaidData', () => {
    trackPageLoad();
    // expect(window.vzdl.txn.paymentAmt).toBe(200.5);
    expect(window.vzdl.txn.taxAmt).toBe('');
  });

  it('should set txn.paymentType using getPaymentTypeLabel', () => {
    trackPageLoad();
    //  expect(window.vzdl.txn.paymentType).toBe('Credit Card');
  });

  it('should set txn.id from paymentData.order_number', () => {
    trackPageLoad();
    //  expect(window.vzdl.txn.id).toBe('ORDER123');
  });

  it('should handle missing fields gracefully', () => {
    useSelector.mockImplementation((selector) =>
      selector({
        peripheralsInfo: {},
        billPay: { userData: {}, prePaidData: {} },
        scan: {},
        common: {},
      }),
    );
    trackPageLoad = useTagging().trackPageLoad;
    trackPageLoad();
    expect(window.vzdl.txn.outletId).toBe('');
    expect(window.vzdl.user.accountType).toBe('');
    expect(window.vzdl.user.accountLast2).toBe('');
    expect(window.vzdl.user.custId_unhashed).toBe('');
    expect(window.vzdl.user.acctId_unhashed).toBe('');
    expect(window.vzdl.user.id).toBe('');
    expect(window.vzdl.txn.paymentAmt).toBe('');
    expect(window.vzdl.txn.taxAmt).toBe('');
  });
});
describe('buildDefaultDL - unit tests for edge cases', () => {
  let trackPageLoad;

  beforeEach(() => {
    jest.resetModules();
    jest.mock('./dlStructure', () => ({
      __esModule: true,
      default: {
        txn: {},
        page: {},
        event: {},
        user: {},
      },
    }));
    useSelector.mockImplementation((selector) =>
      selector({
        peripheralsInfo: {
          appInitVars: {
            locationCode: 'LOC222',
          },
        },
        billPay: {
          userData: {
            mtn: '8888888888',
            accountType: 'Business',
            accountNumber: 'ACC-54321',
            verifiedBy: 'BLINDPAY',
            customerType: 'Enterprise',
            amRole: 'manager',
          },
          billType: 'mobile',
          prePaidData: {
            hashed_mdn: 'HASHED_MDN_2',
            taxInfo: {
              total_fee_amount: '9.99',
            },
          },
        },
        scan: {
          repLoginData: {
            data: {
              salesRepId: 'REP222',
              details: {
                jobTitledId: 'ROLE222',
              },
            },
          },
        },
        common: {
          paymentData: {
            orderTotal: '500.00',
            paymentType: 'ACH',
            order_number: 'ORDER222',
          },
        },
      }),
    );
    trackPageLoad = useTagging().trackPageLoad;
  });

  afterEach(() => {
    jest.resetModules();
    jest.clearAllMocks();
  });

  it('should set all fields correctly when all data is present', () => {
    trackPageLoad();
    //   expect(window.vzdl.txn.outletId).toBe('LOC222');
    expect(window.vzdl.user.accountType).toBe('');
  });

  it('should handle missing userInfo gracefully', () => {
    useSelector.mockImplementation((selector) =>
      selector({
        peripheralsInfo: { appInitVars: { locationCode: 'LOC333' } },
        billPay: { userData: {}, prePaidData: {} },
        scan: {},
        common: {},
      }),
    );
    trackPageLoad = useTagging().trackPageLoad;
    trackPageLoad();
    expect(window.vzdl.user.accountType).toBe('');
    expect(window.vzdl.user.accountLast2).toBe('');
    expect(window.vzdl.user.custId_unhashed).toBe('');
    expect(window.vzdl.user.acctId_unhashed).toBe('');
    expect(window.vzdl.user.authType).toBe('');
    expect(window.vzdl.user.authStatus).toBe('');
  });

  it('should handle missing scanInfo gracefully', () => {
    useSelector.mockImplementation((selector) =>
      selector({
        peripheralsInfo: { appInitVars: { locationCode: 'LOC444' } },
        billPay: { userData: { mtn: '7777777777' }, prePaidData: {} },
        scan: {},
        common: {},
      }),
    );
    trackPageLoad = useTagging().trackPageLoad;
    trackPageLoad();
    expect(window.vzdl.txn.agent).toBe('');
    expect(window.vzdl.txn.agentRole).toBe('');
  });

  it('should handle missing paymentData gracefully', () => {
    useSelector.mockImplementation((selector) =>
      selector({
        peripheralsInfo: { appInitVars: { locationCode: 'LOC555' } },
        billPay: { userData: { mtn: '6666666666' }, prePaidData: {} },
        scan: {},
        common: {},
      }),
    );
    trackPageLoad = useTagging().trackPageLoad;
    trackPageLoad();
    expect(window.vzdl.txn.paymentAmt).toBe('');
    expect(window.vzdl.txn.amount).toBeUndefined();
    expect(window.vzdl.txn.taxAmt).toBe('');
    expect(window.vzdl.txn.paymentType).toBe('');
    expect(window.vzdl.txn.id).toBe('');
  });

  it('should handle missing peripheralsInfo gracefully', () => {
    useSelector.mockImplementation((selector) =>
      selector({
        billPay: { userData: { mtn: '5555555555' }, prePaidData: {} },
        scan: {},
        common: {},
      }),
    );
    trackPageLoad = useTagging().trackPageLoad;
    trackPageLoad();
    expect(window.vzdl.txn.outletId).toBe('');
  });

  it('should handle missing prePaidData gracefully', () => {
    useSelector.mockImplementation((selector) =>
      selector({
        peripheralsInfo: { appInitVars: { locationCode: 'LOC666' } },
        billPay: { userData: { mtn: '4444444444' } },
        scan: {},
        common: {},
      }),
    );
    trackPageLoad = useTagging().trackPageLoad;
    trackPageLoad();
    expect(window.vzdl.user.id).toBe('');
    expect(window.vzdl.txn.taxAmt).toBe('');
  });

  it('should handle accountNumber with no dash', () => {
    useSelector.mockImplementation((selector) =>
      selector({
        peripheralsInfo: { appInitVars: { locationCode: 'LOC777' } },
        billPay: { userData: { mtn: '3333333333', accountNumber: 'ACC98765' } },
        scan: {},
        common: {},
      }),
    );
    trackPageLoad = useTagging().trackPageLoad;
    trackPageLoad();
    expect(window.vzdl.user.accountLast2).toBe('');
    expect(window.vzdl.user.custId_unhashed).toBe('');
    expect(window.vzdl.user.acctId_unhashed).toBe('');
  });

  it('should handle falsy values for all fields', () => {
    useSelector.mockImplementation((selector) =>
      selector({
        peripheralsInfo: {},
        billPay: { userData: {}, prePaidData: {} },
        scan: {},
        common: {},
      }),
    );
    trackPageLoad = useTagging().trackPageLoad;
    trackPageLoad();
    expect(window.vzdl.txn.outletId).toBe('');
    expect(window.vzdl.user.accountType).toBe('');
    expect(window.vzdl.user.accountLast2).toBe('');
    expect(window.vzdl.user.custId_unhashed).toBe('');
    expect(window.vzdl.user.acctId_unhashed).toBe('');
    expect(window.vzdl.user.id).toBe('');
    expect(window.vzdl.txn.paymentAmt).toBe('');
    expect(window.vzdl.txn.amount).toBeUndefined();
    expect(window.vzdl.txn.taxAmt).toBe('');
    expect(window.vzdl.txn.paymentType).toBe('');
    expect(window.vzdl.txn.id).toBe('');
  });
});

describe('buildDefaultDL - direct unit tests for store.getState', () => {
  let useTaggingModule, buildDefaultDL, storeModule;

  beforeEach(() => {
    jest.resetModules();
    jest.mock('./dlStructure', () => ({
      __esModule: true,
      default: {
        txn: {},
        page: {},
        event: {},
        user: {},
        env: {},
      },
    }));

    // Mock getPaymentTypeLabel
    jest.mock('../util/getBillPayment', () => ({
      getPaymentTypeLabel: jest.fn((type) => {
        const map = { CC: 'Credit Card', ACH: 'Check' };
        return map[type] || '';
      }),
    }));

    // Mock store.getState
    const mockStore = {
      getState: jest.fn(),
    };
    jest.mock('onevzsoemfeframework/Storemfe', () => ({
      store: mockStore,
    }));
    storeModule = require('onevzsoemfeframework/Storemfe');
    useTaggingModule = require('./index');
    buildDefaultDL = useTaggingModule.useTagging().trackPageLoad; // We'll call buildDefaultDL indirectly via trackPageLoad
  });

  afterEach(() => {
    jest.resetModules();
    jest.clearAllMocks();
  });

  it('should set all fields correctly when all data is present', () => {
    const mockState = {
      peripheralsInfo: {
        appInitVars: {
          locationCode: 'LOC999',
          isPaypodEnabled: true,
          machineName: 'MACH1',
          registerNumber: 'REG1',
        },
      },
      billPay: {
        userData: {
          mtn: '1234567890',
          accountType: 'Business',
          accountNumber: 'ACC-54321',
          verifiedBy: 'MY_VERIZON',
          customerType: 'Enterprise',
          amRole: 'manager',
        },
        billType: 'mobile',
        prePaidData: {
          hashed_mdn: 'HASHED_MDN_3',
          taxInfo: {
            total_fee_amount: '12.34',
          },
        },
      },
      scan: {
        repLoginData: {
          data: {
            salesRepId: 'REP999',
            details: {
              jobTitledId: 'ROLE999',
            },
          },
        },
      },
      common: {
        paymentData: {
          orderTotal: '1000.00',
          paymentType: 'ACH',
          order_number: 'ORDER999',
        },
        adaptiveLoginData: {
          listOfDevices: [{ deviceType: 'BASIC' }],
        },
      },
    };
    storeModule.store.getState.mockReturnValue(mockState);

    // Call trackPageLoad to trigger buildDefaultDL
    useTaggingModule.useTagging().trackPageLoad();

    expect(window.vzdl.txn.outletId).toBe('LOC999');
    expect(window.vzdl.user.accountType).toBe('Business');
    expect(window.vzdl.user.accountLast2).toBe('CC');
    expect(window.vzdl.user.custId_unhashed).toBe('ACC');
    expect(window.vzdl.user.acctId_unhashed).toBe('ACC-54321');
    expect(window.vzdl.user.authType).toBe('sms');
    expect(window.vzdl.user.authStatus).toBe('logged in');
    expect(window.vzdl.txn.agent).toBe('REP999');
    expect(window.vzdl.txn.agentRole).toBe('ROLE999');
    expect(window.vzdl.user.customerType).toBe('Enterprise');
    expect(window.vzdl.user.customerRole).toBe('manager');
    expect(window.vzdl.user.id).toBe('HASHED_MDN_3');
    expect(window.vzdl.txn.paymentAmt).toBe(1000.0);
    expect(window.vzdl.txn.taxAmt).toBe('12.34');
    expect(window.vzdl.txn.paymentType).toBe('Check');
    expect(window.vzdl.txn.id).toBe('ORDER999');
    expect(window.vzdl.env.businessUnit).toBe('Wireless');
    expect(window.vzdl.page.formData).toContain('paypod');
  });

  it('should optional field data correctly when all data is present', () => {
    const mockState = {
      peripheralsInfo: {
        appInitVars: {
          locationCode: 'LOC999',
          isPaypodEnabled: true,
          machineName: 'MACH1',
          registerNumber: 'REG1',
        },
      },
      billPay: {
        userData: {
          mtn: '1234567890',
          accountType: 'Business',
          accountNumber: 'ACC-54321',
          verifiedBy: 'MY_VERIZON',
          customerType: 'Enterprise',
          amRole: 'manager',
        },
        billType: 'home',
        prePaidData: {},
      },
      scan: {
        repLoginData: {
          data: { otherInfo: { jobTitledId: 'ROLE999' } },
        },
      },
      common: {
        paymentData: {
          orderTotal: '1000.00',
          paymentType: 'ACH',
          orderNum: 'ORDER999',
          orderNumber: 'ORDER999',
          responseDetail: { pmtConfirmationNumber: 'ORDER999' },
          orders: [{ orderNum: 'ORDER999' }],
        },
        adaptiveLoginData: {
          listOfDevices: [{ deviceType: 'PUSH' }],
        },
      },
    };
    storeModule.store.getState.mockReturnValue(mockState);
    // Call trackPageLoad to trigger buildDefaultDL
    useTaggingModule.useTagging().trackPageLoad();

    expect(window.vzdl.txn.outletId).toBe('LOC999');
    expect(window.vzdl.user.accountType).toBe('Business');
    expect(window.vzdl.user.accountLast2).toBe('CC');
    expect(window.vzdl.user.custId_unhashed).toBe('ACC');
    expect(window.vzdl.user.acctId_unhashed).toBe('ACC-54321');
    expect(window.vzdl.user.authType).toBe('push');
    expect(window.vzdl.user.authStatus).toBe('logged in');
    expect(window.vzdl.txn.agent).toBe('');
    expect(window.vzdl.txn.agentRole).toBe('');
    expect(window.vzdl.user.customerType).toBe('Enterprise');
    expect(window.vzdl.user.customerRole).toBe('manager');
    expect(window.vzdl.txn.paymentAmt).toBe(1000.0);
    expect(window.vzdl.txn.taxAmt).toBe('');
    expect(window.vzdl.txn.paymentType).toBe('Check');
    expect(window.vzdl.txn.id).toBe('ORDER999');
    expect(window.vzdl.env.businessUnit).toBe('Wireline');
    expect(window.vzdl.page.formData).toContain('paypod');
  });

  it('should few more optional field data correctly when all data is present', () => {
    const mockState = {
      peripheralsInfo: {
        appInitVars: {
          locationCode: 'LOC999',
          isPaypodEnabled: true,
          machineName: 'MACH1',
          registerNumber: 'REG1',
        },
      },
      billPay: {
        userData: {
          mtn: '1234567890',
          accountType: 'Business',
          accountNumber: 'ACC-54321',
          verifiedBy: 'BLINDPAY',
          customerType: 'Enterprise',
          amRole: 'manager',
        },
        billType: 'home',
        prePaidData: { mdn: '123455599' },
      },
      scan: {
        repLoginData: {
          data: {},
        },
      },
      common: {
        menuSelected: 'payBill',
        paymentData: {
          orderTotal: '1000.00',
          paymentType: 'ACH',
          responseDetail: { pmtConfirmationNumber: 'ORDER999' },
          orders: [{ orderNum: 'ORDER999' }],
        },
      },
    };
    storeModule.store.getState.mockReturnValue(mockState);
    // Call trackPageLoad to trigger buildDefaultDL
    useTaggingModule.useTagging().trackPageLoad({ isFlowNameUpdate: true });

    expect(window.vzdl.txn.outletId).toBe('LOC999');
    expect(window.vzdl.user.accountType).toBe('Business');
    expect(window.vzdl.user.accountLast2).toBe('CC');
    expect(window.vzdl.user.custId_unhashed).toBe('ACC');
    expect(window.vzdl.user.acctId_unhashed).toBe('ACC-54321');
    expect(window.vzdl.user.authStatus).toBe('anonymous');
    expect(window.vzdl.user.customerType).toBe('Enterprise');
    expect(window.vzdl.user.customerRole).toBe('manager');
    expect(window.vzdl.user.id).toBe('');
    expect(window.vzdl.txn.paymentAmt).toBe(1000.0);
    expect(window.vzdl.txn.taxAmt).toBe('');
    expect(window.vzdl.txn.paymentType).toBe('Check');
    expect(window.vzdl.txn.id).toBe('ORDER999');
    expect(window.vzdl.env.businessUnit).toBe('Wireline');
    expect(window.vzdl.page.formData).toContain('paypod');
  });

  it('should handle missing userInfo gracefully', () => {
    const mockState = {
      peripheralsInfo: { appInitVars: { locationCode: 'LOC333' } },
      billPay: { userData: {}, prePaidData: {} },
      scan: {},
      common: {},
    };

    useTaggingModule.useTagging().trackPageLoad();

    expect(window.vzdl.user.accountType).toBe('Business');
    expect(window.vzdl.user.accountLast2).toBe('CC');
    expect(window.vzdl.user.custId_unhashed).toBe('ACC');
    expect(window.vzdl.user.acctId_unhashed).toBe('ACC-54321');
  });

  it('should handle missing scanInfo gracefully', () => {
    const mockState = {
      peripheralsInfo: { appInitVars: { locationCode: 'LOC444' } },
      billPay: { userData: { mtn: '7777777777' }, prePaidData: {} },
      scan: {},
      common: {},
    };
    storeModule.store.getState.mockReturnValue(mockState);

    useTaggingModule.useTagging().trackPageLoad();

    expect(window.vzdl.txn.agent).toBeUndefined();
    expect(window.vzdl.txn.agentRole).toBeUndefined();
  });

  it('should handle missing paymentData gracefully', () => {
    const mockState = {
      peripheralsInfo: { appInitVars: { locationCode: 'LOC555' } },
      billPay: { userData: { mtn: '6666666666' }, prePaidData: {} },
      scan: {},
      common: {},
    };
    storeModule.store.getState.mockReturnValue(mockState);

    useTaggingModule.useTagging().trackPageLoad();

    expect(window.vzdl.txn.paymentAmt).toBeUndefined();
    expect(window.vzdl.txn.taxAmt).toBeUndefined();
    expect(window.vzdl.txn.paymentType).toBeUndefined();
    expect(window.vzdl.txn.id).toBeUndefined();
  });

  it('should handle missing peripheralsInfo gracefully', () => {
    const mockState = {
      billPay: { userData: { mtn: '1111111111' }, prePaidData: {} },
      scan: {},
      common: {},
    };
    require('onevzsoemfeframework/Storemfe').store.getState.mockReturnValue(mockState);

    useTaggingModule.useTagging().trackPageLoad();

    expect(window.vzdl.txn.outletId).toBe('');
    expect(window.vzdl.page.formData).toContain('kiosk');
  });

  it('should handle missing prePaidData gracefully', () => {
    const mockState = {
      peripheralsInfo: { appInitVars: { locationCode: 'LOC666' } },
      billPay: { userData: { mtn: '2222222222' } },
      scan: {},
      common: {},
    };
    storeModule.store.getState.mockReturnValue(mockState);

    useTaggingModule.useTagging().trackPageLoad();

    expect(window.vzdl.user.id).toBe('');
    expect(window.vzdl.txn.taxAmt).toBeUndefined();
  });

  it('should handle accountNumber with no dash', () => {
    const mockState = {
      peripheralsInfo: { appInitVars: { locationCode: 'LOC777' } },
      billPay: { userData: { mtn: '3333333333', accountNumber: 'ACC12345' }, prePaidData: {} },
      scan: {},
      common: {
        menuSelected: 'payBill',
        paymentData: {
          orderTotal: '1000.00',
          paymentType: 'ACH',
        },
      },
    };
    storeModule.store.getState.mockReturnValue(mockState);

    useTaggingModule.useTagging().trackPageLoad({ isFlowNameUpdate: true });

    expect(window.vzdl.user.accountLast2).toBe('45');
    expect(window.vzdl.user.custId_unhashed).toBe('ACC12345');
    expect(window.vzdl.user.acctId_unhashed).toBe('ACC12345');
  });

  it('should handle payment order num and verified by Account pin', () => {
    const mockState = {
      peripheralsInfo: { appInitVars: { locationCode: 'LOC777' } },
      billPay: {
        userData: { mtn: '3333333333', accountNumber: 'ACC12345', verifiedBy: 'ACCOUNT_PIN' },
        prePaidData: {},
      },
      scan: {},
      common: {
        menuSelected: 'completeOrder',
        paymentData: {
          orderTotal: '1000.00',
          paymentType: 'ACH',
          orders: [{ orderNum: 'ORDER999' }],
        },
      },
    };
    storeModule.store.getState.mockReturnValue(mockState);
    useTaggingModule
      .useTagging()
      .trackPageLoad({ pageName: 'TestPage', flow: 'TestFlow', subFlow: 'TestFlow', isFlowNameUpdate: true });
    expect(window.vzdl.txn.id).toBe('ORDER999');
    expect(window.vzdl.user.authType).toBe('pin');
  });

  it('should handle paybill and  flow enabled', () => {
    const mockState = {
      peripheralsInfo: { appInitVars: { locationCode: 'LOC777' } },
      billPay: {
        userData: { mtn: '3333333333', accountNumber: 'ACC12345', isFiosFlow: true },
        prePaidData: {},
      },
      scan: {},
      common: {
        menuSelected: 'payBill',
        paymentData: {
          orderTotal: '1000.00',
          paymentType: 'ACH',
          orders: [{ orderNum: 'ORDER999' }],
        },
      },
    };
    storeModule.store.getState.mockReturnValue(mockState);
    useTaggingModule
      .useTagging()
      .trackPageLoad({ pageName: 'TestPage', flow: 'TestFlow', subFlow: 'TestFlow', isFlowNameUpdate: true });
    expect(window.vzdl.txn.id).toBe('ORDER999');
  });

  it('should handle paybill and  flow enabled prepay account', () => {
    const mockState = {
      peripheralsInfo: { appInitVars: { locationCode: 'LOC777' } },
      billPay: {
        userData: { mtn: '3333333333', accountNumber: 'ACC12345', isFiosFlow: true, prepayAccount: true },
        prePaidData: {},
      },
      scan: {},
      common: {
        menuSelected: 'payBill',
        paymentData: {
          orderTotal: '1000.00',
          paymentType: 'ACH',
          orders: [{ orderNum: 'ORDER999' }],
        },
      },
    };
    storeModule.store.getState.mockReturnValue(mockState);
    useTaggingModule
      .useTagging()
      .trackPageLoad({ pageName: 'TestPage', flow: 'TestFlow', subFlow: 'TestFlow', isFlowNameUpdate: true });
    expect(window.vzdl.txn.id).toBe('ORDER999');
  });
});
