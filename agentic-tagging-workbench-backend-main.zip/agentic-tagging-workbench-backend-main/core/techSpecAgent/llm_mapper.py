import os, base64, json
from dotenv import load_dotenv
from .rules_loader import load_rules
from tools.vegas_llm_utils import VegasLLMWrapper
from pydantic import BaseModel
from typing import List
from techSpecAgent.clean_llm_ouput import clean_and_format_json

load_dotenv()

DEFAULT_VAR = os.getenv("DEFAULT_ADOBE_VARIABLE", "eVar27")


def encode_image(path:str)->str:
    with open(path, "rb") as f:
        import base64
        return base64.b64encode(f.read()).decode("utf-8")

class TechSpecRow(BaseModel):
    eVar: str
    DataLayer: str = None
    AdobeValues: str
    Definition: str
    FieldType: str = "Optional"
    AcceptanceCriteria: str = ""


def map_to_spec(screenshot_path:str, acceptance_text:str, use_csv_output:bool=True):
    """
    Map acceptance criteria and screenshots to tech spec using Vegas LLM.
    """
    system = open("techSpecAgent/prompts/mapper_system.md","r",encoding="utf-8").read()
    rules = load_rules()
    figma_dict  = rules.get("dictionary", {})
    rules.pop("dictionary", None)
    # Ensure variable default from env if not provided in rules
    rules.setdefault("variable", DEFAULT_VAR)

    # img_b64 = encode_image(screenshot_path)
    llm = VegasLLMWrapper()
    user_prompt = (
        f"🔑 CRITICAL: The FIGMA DICTIONARY is the ONLY valid source for component mapping extracted from figma ui.\n"
        f"If a component/element is NOT in this dictionary, it should NOT be included in the tech spec.\n\n"
        f"FIGMA DICTIONARY to refer to when mapping:\n{json.dumps(figma_dict, indent=2)}\n\n"
        f"AC (Acceptance Criteria):\n{acceptance_text}\n"
        f"RULES (JSON):\n{json.dumps(rules, indent=2)}\n"
        # f"Image (base64 PNG): {img_b64[:100]}... [truncated]"
    )
    full_prompt = f"{system}\n\n{user_prompt}"
    # content = llm.invoke(full_prompt,json_schema).strip()
    content = llm.invoke(full_prompt).strip()
    print(content)
    
    with open("techspec_mapper_output1.txt", "w", encoding="utf-8") as f:
        f.write(str(content))

    content = clean_and_format_json(str(content))
    with open("techspec_mapper_output.txt", "w", encoding="utf-8") as f:
        f.write(str(content))


    try:

        data = json.loads(content)
        assert isinstance(data, list)
    except Exception as e:
        # data = [{
        #     "kpi_requirement":"LLM_PARSE_ERROR",
        #     "datalayer_property": None,
        #     "adobe_variables": rules.get("variable", DEFAULT_VAR),
        #     "adobe_values": content[:2000],
        #     "mandatory_optional": "Optional",
        #     "business_context": "Error parsing LLM response"
        # }]
        data = [
            {
                "eVar": rules.get("variable", DEFAULT_VAR),
                "DataLayer": None,
                "AdobeValues": content[:2000],
                "Definition": "Error parsing LLM response",
                "FieldType": "Optional",
                "AcceptanceCriteria": "LLM_PARSE_ERROR",
                "Values": None,
            }
        ]
    
    # Sanitize defaults and flatten if LLM_PARSE_ERROR contains a JSON array
    flat = []
    with open("tech.json","w",encoding="utf-8") as f:
        json.dump(data,f,indent=2)

    for row in data:
        if row.get("AcceptanceCriteria") == "LLM_PARSE_ERROR":
            # Try to parse the AdobeValues as JSON array
            try:
                possible_json = row.get("AdobeValues", "")
                parsed = json.loads(possible_json)
                if isinstance(parsed, list):
                    for item in parsed:
                        item.setdefault("AdobeValues", rules.get("variable", DEFAULT_VAR))
                        item.setdefault("DataLayer", None)
                        item.setdefault("FieldType", "Optional")
                        item.setdefault("Definition", "")
                        flat.append(item)
                    continue
            except Exception:
                pass
        row.setdefault("AdobeValues", rules.get("variable", DEFAULT_VAR))
        row.setdefault("DataLayer", None)
        row.setdefault("FieldType", "Optional")
        row.setdefault("Definition", "")
        flat.append(row)
    print(flat)

    # Add constant DataLayer values at the beginning
    constant_datalayer = rules.get("constant_datalayer", {})
    if constant_datalayer:
        constant_rows = []
        evar_mappings = rules.get("bpk_evar_mappings", {})
        for datalayer_prop, value in constant_datalayer.items():
            evar = evar_mappings.get(datalayer_prop, rules.get("variable", DEFAULT_VAR))
            constant_rows.append({
                "eVar": evar,
                "DataLayer": datalayer_prop,
                "AdobeValues": "",  # Empty for constant rows
                "Definition": "Constant value for DataLayer initialization",
                "FieldType": "Mandatory",
                "AcceptanceCriteria": f"Constant DataLayer: {datalayer_prop}",
                "Values": value,
            })
        flat = flat + constant_rows

    return flat
