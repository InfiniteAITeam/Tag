import json
import re

# The original, truncated input string. The script assumes the goal is to salvage 
# all complete JSON objects and produce a syntactically correct array.
# NOTE: The input string contains non-standard whitespace characters (like NBSP, \xa0)
# which we handle during the cleanup process.
input_json_string = """
[
  {
    "kpi_requirement": "Verify that the \"TAP TO START\" button is tagged when tapped on the BPK screen saver.",
    "datalayer_property": "vzdl.event.value",
    "adobe_variables": "eVar16",
    "adobe_values": "Tap_TapToStart",
    "mandatory_optional": "Mandatory",
    "business_context": "Captures user engagement with the BPK screen saver, indicating initial interest."
  },
  {
    "kpi_requirement": "Verify that the \"How can we help you today?\" screen is tagged upon display.",
    "datalayer_property": "vzdl.page.name",
    "adobe_variables": "eVar70",
    "adobe_values": "Display_HowCanWeHelpYouTodayScreen",
    "mandatory_optional": "Mandatory",
    "business_context": "Tracks entry point to the main BPK interaction flow."
  },
  {
    "kpi_requirement": "Verify that the \"Español\" button on the \"How can we help you today?\" screen is tagged when tapped.",
    "datalayer_property": "vzdl.event.value",
    "adobe_variables": "eVar16",
    "adobe_values": "Tap_Espanol",
    "mandatory_optional": "Optional",
    "business_context": "Captures language preference; useful for localization analysis."
  },
  {
    "kpi_requirement": "Verify that the \"Rep login\" button on the \"How can we help you today?\" screen is tagged when tapped.",
    "datalayer_property": "vzdl.event.value",
    "adobe_variables": "eVar16",
    "adobe_values": "Tap_RepLogin",
    "mandatory_optional": "Optional",
    "business_context": "Tracks usage of the representative login option."
  },
  {
    "kpi_requirement": "Verify that the \"Pay your bill\" button is tagged when tapped.",
    "datalayer_property": "vzdl.event.value",
    "adobe_variables": "eVar16",
    "adobe_values": "Tap_PayYourBill",
    "mandatory_optional": "Mandatory",
    "business_context": "Crucial for tracking initiation of the payment flow."
  },
  {
    "kpi_requirement": "Verify that the \"What type of bill do you want to pay?\" screen is tagged upon display.",
    "datalayer_property": "vzdl.page.name",
    "adobe_variables": "eVar70",
    "adobe_values": "Display_WhatTypeOfBillDoYouWantToPayScreen",
    "mandatory_optional": "Mandatory",
    "business_context": "Tracks progression into the bill payment flow and selection of bill type."
  },
  {
    "kpi_requirement": "Verify that the \"Mobile\" option is tagged when selected.",
    "datalayer_property": "vzdl.event.value",
    "adobe_variables": "eVar16",
    "adobe_values": "Select_Mobile",
    "mandatory_optional": "Mandatory",
    "business_context": "Identifies the bill type selected by the user."
  },
  {
    "kpi_requirement": "Verify that the Entry Type (Mobile Number or Account Number) is tagged.",
    "datalayer_property": "vzdl.page.formData",
    "adobe_variables": "eVar27",
    "adobe_values": "Entry_MobileNumberOrAccountNumber",
    "mandatory_optional": "Mandatory",
    "business_context": "Capture the method of identifying bill, important for analysis"
  },
  {
    "kpi_requirement": "Verify that the number buttons (0-9) are tagged when tapped.",
    "datalayer_property": "vzdl.event.value",
    "adobe_variables": "eVar16",
    "adobe_values": "Tap_NumberButtons",
    "mandatory_optional": "Mandatory",
    "business_context": "Tracks number pad interactions, important for payment flow"
  },
  {
    "kpi_requirement": "Verify that the \"Clear\" button is tagged when tapped.",
    "datalayer_property": "vzdl.event.value",
    "adobe_variables": "eVar16",
    "adobe_values": "Tap_Clear",
    "mandatory_optional": "Mandatory",
    "business_context": "Important for understanding user corrections or cancellations."
  },
  {
    "kpi_requirement": "Verify that the \"Back\" button is tagged when tapped on the bill payment screens.",
    "datalayer_property": "vzdl.event.value",
    "adobe_variables": "eVar16",
    "adobe_values": "Tap_BackButton",
    "mandatory_optional": "Mandatory",
    "business_context": "Tracks navigation patterns, especially backtracking in the payment flow."
  },
  {
    "kpi_requirement": "Verify that the \"Continue\" button is tagged when tapped on the bill payment screens.",
    "datalayer_property": "vzdl.event.value",
    "adobe_variables": "eVar16",
    "adobe_values": "Tap_ContinueButton",
    "mandatory_optional": "Mandatory",
    "business_context": "Crucial for tracking progression through the payment flow."
  },
  {
    "kpi_requirement": "Verify that the \"Confirm Payment\" button is tagged when tapped.",
    "datalayer_property": "vzdl.event.value",
    "adobe_variables": "eVar16",
    "adobe_values": "Tap_ConfirmPayment",
    "mandatory_optional": "Mandatory",
    "business_context": "Essential for measuring completion of the payment process."
  },
  {
    "kpi_requirement": "Verify that the \"Payment Successful\" message is tagged when displayed.",
    "datalayer_property": "vzdl.page.name",
    "adobe_variables": "eVar70",
    "adobe_values": "Display_PaymentSuccessful",
    "mandatory_optional": "Mandatory",
    "business_context": "Validates successful transaction completion and triggers post-payment analysis."
  },
  {
    "kpi_requirement": "Verify that the user is redirected to the correct screen after payment.",
    "datalayer_property": "vzdl.page.name",
    "adobe_variables": "eVar70",
    "adobe_values": "Display_CorrectPostPaymentScreen",
    "mandatory_optional": "Mandatory",
    "business_context": "Ensures proper flow and screen tagging after payment completion."
  },
  {
    "kpi_requirement": "Verify that the session is ended and a new session is started after payment.",
    "datalayer_property": "vzdl.event.value",
    "adobe_variables": "eVar16",
    "adobe_values": "Event_SessionEndAndStart",
    "mandatory_optional": "Mandatory",
    "business_context": "Important for accurate session tracking and analysis."
  },
  {
    "kpi_requirement": "Verify that the app version is sent in the data layer upon payment completion.",
    "datalayer_property": "vzdl.app.version",
    "adobe_variables": "eVar50",
    "adobe_values": "AppVersion_PaymentCompletion",
    "mandatory_optional": "Mandatory",
    "business_context": "Tracks app version usage and potential impact on payment processing."
  },
  {
    "kpi_requirement": "Verify that the device type is sent in the data layer upon payment completion.",
    "datalayer_property": "vzdl.device.type",
    "adobe_variables": "eVar51",
    "adobe_values": "DeviceType_PaymentCompletion",
    "mandatory_optional": "Mandatory",
    "business_context": "Analyzes device type distribution among users completing payments."
  },
  {
    "kpi_requirement": "Verify that the operating system version is sent in the data layer upon payment completion.",
    "datalayer_property": "vzdl.os.version",
    "adobe_variables": "eVar52",
    "adobe_values": "OSVersion_PaymentCompletion",
    "mandatory_optional": "Mandatory",
    "business_context": "Important for troubleshooting and optimizing payment processing."
  },
  {
    "kpi_requirement": "Verify that the screen resolution is sent in the data layer upon payment completion.",
    "datalayer_property": "vzdl.screen.resolution",
    "adobe_variables": "eVar53",
    "adobe_values": "ScreenResolution_PaymentCompletion",
    "mandatory_optional": "Mandatory",
    "business_context": "Helps in understanding the technical environment of users."
  },
  {
    "kpi_requirement": "Verify that the SDK version is sent in the data layer upon payment completion.",
    "datalayer_property": "vzdl.sdk.version",
    "adobe_variables": "eVar54",
    "adobe_values": "SDKVersion_PaymentCompletion",
    "mandatory_optional": "Mandatory",
    "business_context": "Tracks SDK version usage for compatibility and troubleshooting."
  },
  {
    "kpi_requirement": "Verify that the network type is sent in the data layer upon payment completion.",
    "datalayer_property": "vzdl.network.type",
    "adobe_variables": "eVar55",
    "adobe_values": "NetworkType_PaymentCompletion",
    "mandatory_optional": "Mandatory",
    "business_context": "Analyzes network conditions affecting payment processing."
  },
  {
    "kpi_requirement": "Verify that the payment method is sent in the data layer upon payment completion.",
    "datalayer_property": "vzdl.payment.method",
    "adobe_variables": "eVar56",
    "adobe_values": "PaymentMethod_PaymentCompletion",
    "mandatory_optional": "Mandatory",
    "business_context": "Crucial for understanding payment method distribution and issues."
  },
  {
    "kpi_requirement": "Verify that the transaction ID is sent in the data layer upon payment completion.",
    "datalayer_property": "vzdl.transaction.id",
    "adobe_variables": "eVar57",
    "adobe_values": "TransactionID_PaymentCompletion",
    "mandatory_optional": "Mandatory",
    "business_context": "Essential for tracking and reconciling transactions."
  },
  {
    "kpi_requirement": "Verify that the user ID is sent in the data layer upon payment completion.",
    "datalayer_property": "vzdl.user.id",
    "adobe_variables": "eVar58",
    "adobe_values": "UserID_PaymentCompletion",
    "mandatory_optional": "Mandatory",
    "business_context": "Important for user-specific analysis and troubleshooting."
  },
  {
    "kpi_requirement": "Verify that the account number is sent in the data layer upon payment completion.",
    "datalayer_property": "vzdl.account.number",
    "adobe_variables": "eVar59",
    "adobe_values": "AccountNumber_PaymentCompletion",
    "mandatory_optional": "Mandatory",
    "business_context": "Necessary for account-specific tracking and issues."
  },
  {
    "kpi_requirement": "Verify that the billing address is sent in the data layer upon payment completion.",
    "datalayer_property": "vzdl.billing.address",
    "adobe_variables": "eVar60",
    "adobe_values": "BillingAddress_PaymentCompletion",
    "mandatory_optional": "Mandatory",
    "business_context": "Important for billing verification and fraud analysis."
  },
  {
    "kpi_requirement": "Verify that the payment status is sent in the data layer upon payment completion.",
    "datalayer_property": "vzdl.payment.status",
    "adobe_variables": "eVar61",
    "adobe_values": "PaymentStatus_PaymentCompletion",
    "mandatory_optional": "Mandatory",
    "business_context": "Crucial for understanding payment processing outcomes."
  },
  {
    "kpi_requirement": "Verify that the error code is sent in the data layer upon payment failure.",
    "datalayer_property": "vzdl.error.code",
    "adobe_variables": "eVar62",
    "adobe_values": "ErrorCode_PaymentFailure",
    "mandatory_optional": "Optional",
    "business_context": "Helps in diagnosing and resolving payment issues."
  },
  {
    "kpi_requirement": "Verify that the error message is sent in the data layer upon payment failure.",
    "datalayer_property": "vzdl.error.message",
    "adobe_variables": "eVar63",
    "adobe_values": "ErrorMessage_PaymentFailure",
    "mandatory_optional": "Optional",
    "business_context": "Provides context for payment failure analysis."
  },
  {
    "kpi_requirement": "Verify that the retry attempt is tagged when a payment is retried.",
    "datalayer_property": "vzdl.event.value",
    "adobe_variables": "eVar16",
    "adobe_values": "Event_PaymentRetried",
    "mandatory_optional": "Optional",
    "business_context": "Tracks user retries for failed payments, important for UX analysis."
  },
  {
    "kpi_requirement": "Verify that the payment completion time is sent in the data layer.",
    "datalayer_property": "vzdl.payment.completion.time",
    "adobe_variables": "eVar64",
    "adobe_values": "PaymentCompletionTime",
    "mandatory_optional": "Mandatory",
    "business_context": "Important for analyzing payment processing duration."
  },
  {
    "kpi_requirement": "Verify that the app launch time is sent in the data layer.",
    "datalayer_property": "vzdl.app.launch.time",
    "adobe_variables": "eVar65",
    "adobe_values": "AppLaunchTime",
    "mandatory_optional": "Mandatory",
    "business_context": "Tracks app performance and its impact on payment processing."
  },
  {
    "kpi_requirement": "Verify that the screen load time is sent in the data layer.",
    "datalayer_property": "vzdl.screen.load.time",
    "adobe_variables": "eVar66",
    "adobe_values": "ScreenLoadTime",
    "mandatory_optional": "Mandatory",
    "business_context": "Analyzes frontend performance related to payment screens."
  },
  {
    "kpi_requirement": "Verify that the network latency is sent in the data layer.",
    "datalayer_property": "vzdl.network.latency",
    "adobe_variables": "eVar67",
    "adobe_values": "NetworkLatency",
    "mandatory_optional": "Mandatory",
    "business_context": "Important for diagnosing network-related payment issues."
  },
  {
    "kpi_requirement": "Verify that the data layer is correctly populated with all required fields upon payment.",
    "datalayer_property": "vzdl.all.fields",
    "adobe_variables": "eVar68",
    "adobe_values": "AllFields_Payment",
    "mandatory_optional": "Mandatory",
    "business_context": "Ensures completeness of data for payment transactions."
  },
  {
    "kpi_requirement": "Verify that the data layer remains consistent and accurate throughout the payment process.",
    "datalayer_property": "vzdl.data.consistency",
    "adobe_variables": "eVar69",
    "adobe_values": "DataConsistency_Payment",
    "mandatory_optional": "Mandatory",
    "business_context": "Crucial for reliable data analysis and reporting."
  }
]
"""

def clean_and_format_json(raw_json_string):
    """
    Cleans up a JSON array string (truncated or not), removes markdown code blocks,
    and always returns pretty-printed JSON.
    """
    # Remove markdown code block markers if present
    cleaned_string = raw_json_string.strip()
    if cleaned_string.startswith("```json"):
        cleaned_string = cleaned_string[7:]
    if cleaned_string.startswith("```"):
        cleaned_string = cleaned_string[3:]
    if cleaned_string.endswith("```"):
        cleaned_string = cleaned_string[:-3]
    cleaned_string = cleaned_string.strip().replace('\xa0', ' ')

    # Try to parse as JSON directly
    try:
        data = json.loads(cleaned_string)
        return json.dumps(data, indent=2)
    except Exception:
        pass  # fallback to salvage logic

    # Salvage logic for truncated JSON
    last_complete_object_end_index = cleaned_string.rfind('},')
    if last_complete_object_end_index == -1:
        last_complete_object_end_index = cleaned_string.rfind('}')
        if last_complete_object_end_index == -1:
            print("Error: Could not find any complete JSON objects in the input.")
            return None
        final_valid_json_string = cleaned_string[:last_complete_object_end_index + 1] + "\n]"
    else:
        final_valid_json_string = cleaned_string[:last_complete_object_end_index + 1]
        final_valid_json_string += "\n]"

    try:
        data = json.loads(final_valid_json_string)
        return json.dumps(data, indent=2)
    except Exception as e:
        print(f"Error decoding JSON after cleanup: {e}")
        print("\n--- Cleaned String Attempt ---\n" + final_valid_json_string)
        return None

# # Run the script and print the result
# formatted_output = clean_and_format_json(input_json_string)

# if formatted_output:
#     print("--- Properly Formatted JSON Output ---")
#     print(formatted_output)

#     # # Save the output to a file as requested by the user flow
#     # with open("kpi_requirements_fixed.json", "w") as f:
#     #     f.write(formatted_output)