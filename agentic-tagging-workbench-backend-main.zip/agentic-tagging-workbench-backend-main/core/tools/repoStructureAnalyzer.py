"""
repoStructureAnalyzer.py

Utilities for analyzing React repository structure:
- Finding the 'common' folder
- Copying Tagging folder to common
- Finding page files that need tagging
- Identifying imports and component structure
"""

import shutil
import os
import re
from pathlib import Path
from typing import Optional, Dict, List, Tuple, Any
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("repo_analyzer")


class RepoStructureAnalyzer:
    """Analyzes React repo structure to find key directories and files."""
    
    COMMON_FOLDER_NAMES = [
        "common",
        "src/common",
        "components/common",
        "utils/common",
        "shared/common",
    ]
    
    def __init__(self, repo_path: str):
        self.repo_path = Path(repo_path)
        if not self.repo_path.exists():
            raise ValueError(f"Repo path does not exist: {repo_path}")
        self.common_folder = None
        self._find_common_folder()
    
    def _find_common_folder(self) -> Optional[Path]:
        """Find the common folder in the repo."""
        # First, try direct path combinations
        for common_dir in self.COMMON_FOLDER_NAMES:
            candidate = self.repo_path / common_dir
            if candidate.exists() and candidate.is_dir():
                self.common_folder = candidate
                logger.info(f"Found common folder at: {candidate.relative_to(self.repo_path)}")
                return candidate
        
        # If not found in standard locations, search recursively
        for item in self.repo_path.rglob("common"):
            if item.is_dir() and "node_modules" not in str(item):
                self.common_folder = item
                logger.info(f"Found common folder at: {item.relative_to(self.repo_path)}")
                return item
        
        logger.warning("Could not find 'common' folder in repo")
        return None
    
    def get_common_folder(self) -> Optional[Path]:
        """Get the path to the common folder."""
        return self.common_folder
    
    def find_page_files(self, page_names: List[str]) -> Dict[str, List[Path]]:
        """
        Find page files by name.
        
        Args:
            page_names: List of page names to find
            
        Returns:
            Dict mapping page names to list of file paths
        """
        results = {}
        
        for page_name in page_names:
            matches = []
            
            # Try common page patterns
            patterns = [
                f"{page_name}.js",
                f"{page_name}.jsx",
                f"{page_name}.tsx",
                f"{page_name}.ts",
                f"{page_name.replace(' ', '')}.js",
                f"{page_name.replace(' ', '')}.jsx",
                f"{page_name.replace(' ', '')}.tsx",
            ]
            
            for pattern in patterns:
                for file_path in self.repo_path.rglob(pattern):
                    if "node_modules" not in str(file_path):
                        matches.append(file_path)
            
            results[page_name] = list(set(matches))
        
        return results
    
    def find_page_by_content(self, page_names: List[str]) -> Dict[str, List[Path]]:
        """
        Find pages by searching file content for page names.
        Useful when filename doesn't match exactly.
        """
        results = {}
        
        # Get all JS/TSX files
        all_files = list(self.repo_path.rglob("*.js*")) + list(self.repo_path.rglob("*.tsx"))
        all_files = [f for f in all_files if "node_modules" not in str(f)]
        
        for page_name in page_names:
            matches = []
            search_terms = [
                page_name,
                f'"{page_name}"',
                f"'{page_name}'",
            ]
            
            for file_path in all_files:
                try:
                    content = file_path.read_text(encoding="utf-8", errors="ignore")
                    if any(term in content for term in search_terms):
                        matches.append(file_path)
                except Exception as e:
                    logger.debug(f"Could not read {file_path}: {e}")
            
            results[page_name] = list(set(matches))
        
        return results


class TaggingFolderManager:
    """Manages copying and integration of the Tagging folder."""
    
    TAGGING_FOLDER_NAME = "Tagging"
    
    def __init__(self, repo_path: str, source_tagging_path: str):
        self.repo_path = Path(repo_path)
        self.source_tagging_path = Path(source_tagging_path)
        self.common_folder = None
        
        # Validate source
        if not self.source_tagging_path.exists():
            raise ValueError(f"Source Tagging folder not found: {source_tagging_path}")
    
    def copy_tagging_to_common(self, common_folder: Path, force: bool = False) -> Path:
        """
        Copy the Tagging folder to the common folder.
        
        Args:
            common_folder: Path to the common folder in the repo
            force: If True, overwrite existing Tagging folder
            
        Returns:
            Path to the Tagging folder in the common directory
        """
        if not common_folder.exists():
            raise ValueError(f"Common folder does not exist: {common_folder}")
        
        dest_tagging = common_folder / self.TAGGING_FOLDER_NAME
        
        # Check if already exists
        if dest_tagging.exists():
            if force:
                logger.info(f"Removing existing Tagging folder at: {dest_tagging}")
                shutil.rmtree(dest_tagging)
            else:
                logger.warning(f"Tagging folder already exists at: {dest_tagging}")
                return dest_tagging
        
        # Copy Tagging folder
        logger.info(f"Copying Tagging folder from {self.source_tagging_path} to {dest_tagging}")
        shutil.copytree(self.source_tagging_path, dest_tagging)
        
        logger.info(f"✓ Tagging folder copied to: {dest_tagging}")
        return dest_tagging
    
    def get_tagging_import_path(self, common_folder: Path, from_file: Path) -> str:
        """
        Calculate the relative import path for the Tagging folder.
        
        Args:
            common_folder: Path to common folder
            from_file: Path to the file that will import Tagging
            
        Returns:
            Relative import path (e.g., "../../common/Tagging")
        """
        tagging_path = common_folder / self.TAGGING_FOLDER_NAME
        
        # Calculate relative path
        try:
            rel_path = os.path.relpath(tagging_path, from_file.parent)
            # Convert backslashes to forward slashes for imports
            rel_path = rel_path.replace("\\", "/")
            return rel_path
        except ValueError:
            # If on different drives on Windows, use absolute
            return str(tagging_path)


class CodeInjector:
    """Injects tagging code into React components."""
    
    def __init__(self, tagging_import_path: str):
        """
        Initialize with the import path for the Tagging module.
        
        Args:
            tagging_import_path: Relative or absolute path to Tagging/index.js
        """
        self.tagging_import_path = tagging_import_path
    
    def get_import_statement(self) -> str:
        """Get the import statement for the Tagging hook."""
        return f'import {{ useTagging }} from "{self.tagging_import_path}";'
    
    def inject_hook_into_component(
        self,
        file_path: Path,
        hook_config: Dict[str, Any],
        backup: bool = True
    ) -> bool:
        """
        Inject useTagging hook into a React component.
        
        Args:
            file_path: Path to the React component file
            hook_config: Configuration with page, flow, action info
            backup: Whether to create a backup of the original file
            
        Returns:
            True if injection was successful
        """
        if not file_path.exists():
            logger.error(f"File does not exist: {file_path}")
            return False
        
        try:
            content = file_path.read_text(encoding="utf-8")
            
            # Create backup
            if backup:
                backup_path = file_path.with_suffix(file_path.suffix + ".backup")
                if not backup_path.exists():
                    backup_path.write_text(content, encoding="utf-8")
                    logger.info(f"Created backup: {backup_path}")
            
            # Check if import already exists
            import_stmt = self.get_import_statement()
            if import_stmt in content:
                logger.info(f"Import already exists in {file_path.name}")
                return True
            
            # Add import at the top
            modified_content = self._inject_import(content, import_stmt)
            
            # Add hook initialization in component
            modified_content = self._inject_hook_call(modified_content, hook_config)
            
            # Write back
            file_path.write_text(modified_content, encoding="utf-8")
            logger.info(f"✓ Injected tagging into: {file_path.name}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to inject hook into {file_path}: {e}")
            return False
    
    def _inject_import(self, content: str, import_stmt: str) -> str:
        """Inject import statement at the top of the file, including useEffect from React."""
        # Find existing imports
        import_pattern = r'^import\s+'
        lines = content.split('\n')
        
        insert_pos = 0
        react_import_line = -1
        has_use_effect = False
        
        for i, line in enumerate(lines):
            if re.match(import_pattern, line):
                insert_pos = i + 1
                # Check if this is React import
                if 'from \'react\'' in line or 'from "react"' in line:
                    react_import_line = i
                    # Check if useEffect is already imported
                    if 'useEffect' in line:
                        has_use_effect = True
            else:
                break
        
        # If no useEffect is imported, add it to React import or create new import
        if not has_use_effect:
            if react_import_line >= 0:
                # Add useEffect to existing React import
                react_line = lines[react_import_line]
                if 'from \'react\'' in react_line or 'from "react"' in react_line:
                    # Check if it's a named import
                    if '{' in react_line and '}' in react_line:
                        # Add useEffect to the named imports
                        match = re.search(r'(\{[^}]*\})', react_line)
                        if match:
                            imports_section = match.group(1)
                            if 'useEffect' not in imports_section:
                                new_imports = imports_section[:-1] + ', useEffect }'
                                react_line = react_line.replace(imports_section, new_imports)
                                lines[react_import_line] = react_line
                    else:
                        # Default import, convert to named import with useEffect
                        if 'React' in react_line:
                            react_line = react_line.replace('import React', 'import React, { useEffect }')
                            lines[react_import_line] = react_line
            else:
                # No React import exists, add one
                lines.insert(insert_pos, "import { useEffect } from 'react';")
                insert_pos += 1
        
        # Insert the Tagging import after last import
        if import_stmt and import_stmt not in content:
            lines.insert(insert_pos, import_stmt)
        
        return '\n'.join(lines)
    
    def _inject_hook_call(self, content: str, hook_config: Dict[str, Any]) -> str:
        """Inject useTagging hook with useEffect pattern inside the component function."""
        page_name = hook_config.get('page', 'UnknownPage')
        flow_name = hook_config.get('flow', 'UnknownFlow')
        event = hook_config.get('event', 'unknown_event')
        is_flow_name_update = hook_config.get('isFlowNameUpdate', True)
        
        # Create hook initialization code with useEffect pattern
        hook_init = f"""const {{ trackPageLoad }} = useTagging();

  useEffect(() => {{
    trackPageLoad({{
      pageName: '{page_name}',
      flow: '{flow_name}',
      isFlowNameUpdate: {str(is_flow_name_update).lower()},
      event: '{event}',
    }});
  }}, []);"""
        
        # Try to find the component function and add hook call
        # This is a simplified approach - looks for function body
        
        # Pattern 1: const Component = () => { ... }
        pattern1 = r'(const\s+\w+\s*=\s*(?:\([^)]*\))?\s*=>\s*\{)'
        
        # Pattern 2: function Component() { ... }
        pattern2 = r'(function\s+\w+\s*\([^)]*\)\s*\{)'
        
        # Try pattern 1
        match = re.search(pattern1, content)
        if match:
            insert_pos = match.end()
            lines = content[:insert_pos].split('\n')
            last_line = lines[-1]
            indent = len(last_line) - len(last_line.lstrip())
            hook_indented = '\n'.join(' ' * (indent + 2) + line for line in hook_init.split('\n'))
            content = content[:insert_pos] + '\n' + hook_indented + '\n' + content[insert_pos:]
            return content
        
        # Try pattern 2
        match = re.search(pattern2, content)
        if match:
            insert_pos = match.end()
            lines = content[:insert_pos].split('\n')
            last_line = lines[-1]
            indent = len(last_line) - len(last_line.lstrip())
            hook_indented = '\n'.join(' ' * (indent + 2) + line for line in hook_init.split('\n'))
            content = content[:insert_pos] + '\n' + hook_indented + '\n' + content[insert_pos:]
            return content
        
        # If no match found, just add at the beginning after imports
        logger.warning(f"Could not find component function, adding hook near top of file")
        return content
    
    def remove_hook_from_component(self, file_path: Path) -> bool:
        """Remove injected tagging hooks from a component (for rollback)."""
        if not file_path.exists():
            return False
        
        try:
            content = file_path.read_text(encoding="utf-8")
            
            # Remove import
            import_stmt = self.get_import_statement()
            content = content.replace(import_stmt + '\n', '')
            content = content.replace(import_stmt, '')
            
            # Remove hook call (rough pattern)
            content = re.sub(r'\n\s*useTagging\(\);\s*//\s*Tagging initialized.*\n', '\n', content)
            
            file_path.write_text(content, encoding="utf-8")
            logger.info(f"✓ Removed tagging from: {file_path.name}")
            return True
        except Exception as e:
            logger.error(f"Failed to remove hook from {file_path}: {e}")
            return False


class PageFileUpdater:
    """Updates page files with tagging based on techspec."""
    
    def __init__(self, repo_path: str, tagging_folder_in_common: Path):
        self.repo_path = Path(repo_path)
        self.tagging_folder = tagging_folder_in_common
        self.analyzer = RepoStructureAnalyzer(repo_path)
    
    def update_pages_with_tagging(
        self,
        suggestions_report: Dict[str, Any],
        backup: bool = True
    ) -> Dict[str, Any]:
        """
        Update all identified pages with tagging hooks.
        
        Args:
            suggestions_report: Report from suggestTaggingAgent
            backup: Whether to create backups before modifying
            
        Returns:
            Update report with status for each page
        """
        results = {
            "updated_files": [],
            "failed_files": [],
            "skipped_files": [],
        }
        
        for page_data in suggestions_report.get('suggestions_by_page', []):
            page_name = page_data.get('page')
            flow_name = page_data.get('flow')
            
            # Get file locations
            file_locations = page_data.get('file_locations', [])
            
            for file_loc in file_locations:
                file_path = self.repo_path / file_loc
                
                if not file_path.exists():
                    logger.warning(f"File not found: {file_loc}")
                    results["skipped_files"].append(file_loc)
                    continue
                
                try:
                    # Calculate import path
                    common_folder = self.analyzer.get_common_folder()
                    if not common_folder:
                        logger.error("Common folder not found")
                        results["failed_files"].append(file_loc)
                        continue
                    
                    import_path = self._calculate_import_path(file_path, common_folder)
                    
                    # Create injector
                    injector = CodeInjector(import_path)
                    
                    # Prepare hook config
                    hook_config = {
                        'page': page_name,
                        'flow': flow_name,
                        'action': page_data.get('tagging_items', [{}])[0].get('item', {}).get('action', 'unknown')
                    }
                    
                    # Inject hook
                    if injector.inject_hook_into_component(file_path, hook_config, backup=backup):
                        results["updated_files"].append(file_loc)
                    else:
                        results["failed_files"].append(file_loc)
                
                except Exception as e:
                    logger.error(f"Error updating {file_loc}: {e}")
                    results["failed_files"].append(file_loc)
        
        return results
    
    def _calculate_import_path(self, from_file: Path, common_folder: Path) -> str:
        """Calculate relative import path from a file to Tagging/index."""
        tagging_path = common_folder / "Tagging"
        
        try:
            rel_path = os.path.relpath(tagging_path, from_file.parent)
            rel_path = rel_path.replace("\\", "/")
            return rel_path
        except ValueError:
            return str(tagging_path)


def main():
    """Example usage."""
    import json
    
    # Example paths
    repo_path = "/path/to/cloned/repo"
    tagging_source = "/path/to/Tagging"
    suggestion_report_path = "/path/to/suggestions.json"
    
    try:
        # 1. Analyze repo structure
        analyzer = RepoStructureAnalyzer(repo_path)
        common_folder = analyzer.get_common_folder()
        
        if not common_folder:
            print("ERROR: Could not find common folder")
            return
        
        print(f"✓ Found common folder: {common_folder}")
        
        # 2. Copy Tagging folder
        manager = TaggingFolderManager(repo_path, tagging_source)
        tagging_folder = manager.copy_tagging_to_common(common_folder, force=False)
        
        print(f"✓ Tagging folder ready at: {tagging_folder}")
        
        # 3. Load suggestions report
        with open(suggestion_report_path) as f:
            report = json.load(f)
        
        # 4. Update pages
        updater = PageFileUpdater(repo_path, tagging_folder)
        update_results = updater.update_pages_with_tagging(report, backup=True)
        
        print(f"\nUpdate Results:")
        print(f"  Updated: {len(update_results['updated_files'])}")
        print(f"  Failed: {len(update_results['failed_files'])}")
        print(f"  Skipped: {len(update_results['skipped_files'])}")
    
    except Exception as e:
        print(f"ERROR: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
