"""
suggestTaggingAgent.py

Tagging Suggestion Agent - identifies which pages and flows need tagging
WITHOUT modifying the repository code.

Flow:
1. Clone the repository
2. Read the tech spec
3. Identify pages and flows that need tagging
4. Scan the repo structure to find matching pages
5. Generate a report with suggestions (no code changes)
"""

import os
import sys
import json
import time
from pathlib import Path
from contextlib import contextmanager
from typing import Dict, List, Any, Optional, Tuple
from dotenv import load_dotenv

from cloneRepo import clone_to_fixed_location as clone_repo_url
from tools.excelReader import ExcelReaderTool
from tools.repoMatcher import RepoMatcherTool
from utils.file_handler import FileHandler

CORE_DIR = Path(__file__).resolve().parent
OUTPUTS_DIR = CORE_DIR / "outputs"

# ---------- tiny CLI UI helpers ----------
SPINNER_FRAMES = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"


class Spinner:
    def __init__(self, label: str):
        self.label = label
        self._running = False

    def start(self):
        self._running = True
        self._animate_start = time.perf_counter()
        i = 0
        while self._running:
            frame = SPINNER_FRAMES[i % len(SPINNER_FRAMES)]
            sys.stdout.write(f"\r{frame} {self.label} ")
            sys.stdout.flush()
            i += 1
            time.sleep(0.08)

    def stop(self, ok: bool = True):
        self._running = False
        elapsed = time.perf_counter() - self._animate_start
        icon = "✓" if ok else "✗"
        sys.stdout.write(f"\r{icon} {self.label}  ({elapsed:.1f}s)\n")
        sys.stdout.flush()


@contextmanager
def step(label: str):
    sp = Spinner(label)
    try:
        import threading
        t = threading.Thread(target=sp.start, daemon=True)
        t.start()
        yield sp
        sp.stop(ok=True)
    except Exception:
        sp.stop(ok=False)
        raise


class PageFlowIdentifier:
    """
    Identifies pages and flows from a React repository structure.
    Looks for common patterns in file naming and directory structure.
    """
    
    COMMON_DIRS = ["common", "src/common", "components/common", "pages"]
    PAGE_PATTERNS = [
        "*.page.js",
        "*.page.jsx",
        "*.page.tsx",
        "*.page.ts",
        "*.jsx",
        "*.js",
    ]
    
    def __init__(self, repo_path: str):
        self.repo_path = Path(repo_path)
        self.files_by_name = {}
        self._index_files()
    
    def _index_files(self):
        """Index all JS/JSX/TS/TSX files by name."""
        for ext in ["*.js", "*.jsx", "*.ts", "*.tsx"]:
            for file_path in self.repo_path.rglob(ext):
                if "node_modules" not in str(file_path) and ".next" not in str(file_path):
                    name = file_path.stem
                    self.files_by_name.setdefault(name, []).append(file_path)
    
    def find_pages(self, page_names: List[str]) -> Dict[str, Any]:
        """
        Find matching page files in the repo.
        
        Args:
            page_names: List of page names from techspec
            
        Returns:
            Dict mapping page names to file information
        """
        results = {}
        for page_name in page_names:
            # Normalize page name
            normalized = page_name.lower().replace(" ", "").replace("-", "")
            
            matches = []
            # Look for exact name matches
            if page_name in self.files_by_name:
                matches.extend(self.files_by_name[page_name])
            
            # Look for partial matches
            for file_name, file_paths in self.files_by_name.items():
                if normalized in file_name.lower().replace("-", ""):
                    matches.extend(file_paths)
            
            results[page_name] = {
                "found": len(matches) > 0,
                "matches": list(set([str(m.relative_to(self.repo_path)) for m in matches])),
                "count": len(set(matches))
            }
        
        return results
    
    def find_flows(self, flow_names: List[str]) -> Dict[str, Any]:
        """
        Find flow-related code patterns (usually in routing or context).
        """
        results = {}
        flow_files = list(self.repo_path.rglob("*route*")) + \
                     list(self.repo_path.rglob("*flow*")) + \
                     list(self.repo_path.rglob("*context*"))
        
        flow_files = [f for f in flow_files if f.is_file() and 
                     f.suffix in ['.js', '.jsx', '.ts', '.tsx'] and
                     'node_modules' not in str(f)]
        
        for flow_name in flow_names:
            normalized = flow_name.lower().replace(" ", "").replace("-", "")
            matches = []
            
            for ffile in flow_files:
                if normalized in ffile.stem.lower().replace("-", ""):
                    matches.append(str(ffile.relative_to(self.repo_path)))
            
            results[flow_name] = {
                "found": len(matches) > 0,
                "matches": list(set(matches)),
                "count": len(set(matches))
            }
        
        return results


class TechSpecAnalyzer:
    """Analyzes tech spec to identify pages and flows needing tagging."""
    
    def __init__(self, excel_path: str):
        self.excel_path = excel_path
        self.spec_items = []
        self.pages = set()
        self.flows = set()
    
    def analyze(self, use_llm: bool = False) -> Dict[str, Any]:
        """
        Parse tech spec and extract pages/flows information.
        """
        excel_tool = ExcelReaderTool()
        result = excel_tool._run(self.excel_path, use_llm=use_llm)
        
        if result.get("status") != "success":
            raise RuntimeError(f"ExcelReader failed: {result}")
        
        self.spec_items = result.get("spec_items", [])
        
        # Extract unique pages and flows
        for item in self.spec_items:
            if item.get("page"):
                self.pages.add(item["page"])
            if item.get("flow"):
                self.flows.add(item["flow"])
        
        return {
            "status": "success",
            "total_items": len(self.spec_items),
            "pages": sorted(list(self.pages)),
            "flows": sorted(list(self.flows)),
            "items": self.spec_items
        }


def build_suggestion_report(
    excel_path: str,
    repo_path: str,
    spec_analysis: Dict[str, Any],
    use_llm: bool = False
) -> Dict[str, Any]:
    """
    Build a comprehensive tagging suggestion report.
    
    This identifies what pages and flows need tagging but doesn't modify code.
    """
    
    # Step 1: Identify pages and flows from techspec
    pages = spec_analysis.get("pages", [])
    flows = spec_analysis.get("flows", [])
    spec_items = spec_analysis.get("items", [])
    
    # Step 2: Find pages in repo
    identifier = PageFlowIdentifier(repo_path)
    page_matches = identifier.find_pages(pages)
    flow_matches = identifier.find_flows(flows)
    
    # Step 3: Use RepoMatcher for detailed matching
    repo_tool = RepoMatcherTool()
    repo_matches = repo_tool._run(repo_path, spec_items, use_embeddings=use_llm)
    
    if repo_matches.get("status") != "success":
        raise RuntimeError(f"RepoMatcher failed: {repo_matches}")
    
    # Step 4: Group suggestions by page
    suggestions_by_page = {}
    for item, suggestion in zip(spec_items, repo_matches.get("suggestions", [])):
        page = item.get("page", "unknown")
        if page not in suggestions_by_page:
            suggestions_by_page[page] = {
                "page": page,
                "flow": item.get("flow"),
                "tagging_items": [],
                "file_locations": []
            }
        
        suggestion["item"] = item
        suggestions_by_page[page]["tagging_items"].append(suggestion)
        
        if suggestion.get("matches"):
            top = suggestion["matches"][0]
            file_path = top.get("file")
            if file_path not in suggestions_by_page[page]["file_locations"]:
                suggestions_by_page[page]["file_locations"].append(file_path)
    
    # Step 5: Build final report
    run_id = time.strftime("%Y-%m-%dT%H:%M:%S")
    report = {
        "run_id": run_id,
        "type": "suggestion",
        "excel": str(Path(excel_path).resolve()),
        "repo": str(Path(repo_path).resolve()),
        "summary": {
            "total_pages": len(pages),
            "total_flows": len(flows),
            "total_items": len(spec_items),
            "pages_with_matches": sum(1 for m in page_matches.values() if m["found"]),
            "flows_with_matches": sum(1 for m in flow_matches.values() if m["found"])
        },
        "page_analysis": page_matches,
        "flow_analysis": flow_matches,
        "suggestions_by_page": list(suggestions_by_page.values()),
        "all_matching_files": sorted(list(set([
            item["file_locations"]
            for item in suggestions_by_page.values()
            for item in item["file_locations"]
        ])))
    }
    
    return report


def main():
    load_dotenv()
    
    # Resolve inputs
    excel_candidates = [
        os.getenv("TECHSPEC_PATH")
    ]
    excel = next((p for p in excel_candidates if p and Path(p).exists()), None)
    if not excel:
        print("✗ Could not find a Tech Spec Excel file. Looked for:")
        for c in excel_candidates:
            if c:
                print(f"  - {c}")
        sys.exit(1)
    
    repo_url = os.getenv("REPO_URL")
    repo_branch = os.getenv("REPO_BRANCH") or None
    
    val = os.environ.get("CLONE_BASE")
    if not val:
        raise RuntimeError(
            "CLONE_BASE is not set. Add `CLONE_BASE=${HOME}/ATTagger/Test` (or an absolute path) to your .env"
        )
    clone_base = Path(os.path.expandvars(val)).expanduser().resolve()
    
    use_llm = bool(os.getenv("OPENAI_API_KEY"))
    
    print("==========================================")
    print("   Tagging Suggestion Agent")
    print("==========================================")
    print(f"• Tech Spec : {excel}")
    print(f"• Repo URL  : {repo_url}")
    print(f"• Branch    : {repo_branch or '(default)'}")
    print(f"• CloneBase : {clone_base}")
    print(f"• OpenAI    : {'ON (LLM)' if use_llm else 'OFF'}")
    print("")
    
    # Clone repo
    with step("Cloning repository"):
        repo_path = Path(clone_repo_url(repo_url)).resolve()
    
    if not repo_path.exists() or not repo_path.is_dir():
        print(f"✗ Clone failed or bad path: {repo_path}")
        sys.exit(1)
    
    print(f"→ Using repo_path: {repo_path}")
    
    # Save repo path to outputs
    OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)
    target_path = str(OUTPUTS_DIR / ".last_repo_root")
    p = Path(target_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(str(repo_path), encoding="utf-8")
    tmp.replace(p)
    print(f"CLONED_TO: {repo_path}")
    
    # Analyze tech spec
    with step("Analyzing Tech Spec"):
        analyzer = TechSpecAnalyzer(excel)
        spec_analysis = analyzer.analyze(use_llm=use_llm)
    
    # Build suggestion report
    with step("Scanning Repo and Building Tagging Suggestions"):
        report = build_suggestion_report(excel, str(repo_path), spec_analysis, use_llm=use_llm)
    
    # Write report
    with step("Writing suggestion report"):
        OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)
        
        report_json = OUTPUTS_DIR / "tagging_suggestions.json"
        with open(report_json, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)
        
        report_md = OUTPUTS_DIR / "tagging_suggestions.md"
        _write_suggestion_report_md(report, report_md)
    
    # Summary
    summary = report.get("summary", {})
    print("")
    print("Summary")
    print("-------")
    print(f"• Pages found  : {summary.get('pages_with_matches')}/{summary.get('total_pages')}")
    print(f"• Flows found  : {summary.get('flows_with_matches')}/{summary.get('total_flows')}")
    print(f"• Items to tag : {summary.get('total_items')}")
    print("")
    print("Outputs")
    print("-------")
    print(f"• JSON     : {report_json}")
    print(f"• Markdown : {report_md}")
    print("")
    print("✓ Suggestion report ready for review. Use applyTaggingAgent.py to apply changes.")
    print("")


def _write_suggestion_report_md(report: Dict[str, Any], output_path: Path):
    """Write suggestion report as Markdown."""
    lines = [
        "# Tagging Suggestions Report",
        "",
        f"**Run ID**: {report['run_id']}",
        f"**Repository**: {report['repo']}",
        f"**Tech Spec**: {report['excel']}",
        "",
        "## Summary",
        "",
        f"- **Total Pages**: {report['summary']['total_pages']}",
        f"- **Pages with Matches**: {report['summary']['pages_with_matches']}",
        f"- **Total Flows**: {report['summary']['total_flows']}",
        f"- **Flows with Matches**: {report['summary']['flows_with_matches']}",
        f"- **Total Tagging Items**: {report['summary']['total_items']}",
        "",
        "## Pages Analysis",
        "",
    ]
    
    for page_name, page_info in report['page_analysis'].items():
        status = "✓ FOUND" if page_info['found'] else "✗ NOT FOUND"
        lines.append(f"### {page_name} {status}")
        if page_info['matches']:
            lines.append(f"**Matches ({page_info['count']}):**")
            for match in page_info['matches']:
                lines.append(f"- `{match}`")
        lines.append("")
    
    lines.append("## Flow Analysis")
    lines.append("")
    
    for flow_name, flow_info in report['flow_analysis'].items():
        status = "✓ FOUND" if flow_info['found'] else "✗ NOT FOUND"
        lines.append(f"### {flow_name} {status}")
        if flow_info['matches']:
            lines.append(f"**Matches ({flow_info['count']}):**")
            for match in flow_info['matches']:
                lines.append(f"- `{match}`")
        lines.append("")
    
    lines.append("## Tagging Suggestions by Page")
    lines.append("")
    
    for page_data in report['suggestions_by_page']:
        page = page_data['page']
        flow = page_data.get('flow', 'N/A')
        lines.append(f"### Page: {page} (Flow: {flow})")
        lines.append("")
        
        if page_data['file_locations']:
            lines.append("**File Locations:**")
            for file_loc in page_data['file_locations']:
                lines.append(f"- `{file_loc}`")
            lines.append("")
        
        lines.append(f"**Tagging Items** ({len(page_data['tagging_items'])}):")
        lines.append("")
        
        for idx, item in enumerate(page_data['tagging_items'], 1):
            spec_item = item.get('item', {})
            action = spec_item.get('action', 'N/A')
            description = spec_item.get('description', 'N/A')
            adobe_var = spec_item.get('adobe_var', 'N/A')
            
            lines.append(f"{idx}. **{action}**: {description}")
            lines.append(f"   - Adobe Variable: `{adobe_var}`")
            
            if item.get('matches'):
                top_match = item['matches'][0]
                lines.append(f"   - Match: `{top_match.get('file')}` (Line {top_match.get('line')})")
            
            lines.append("")
        
        lines.append("---")
        lines.append("")
    
    output_path.write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nAborted by user.")
        sys.exit(130)
    except Exception as e:
        print(f"\n✗ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
