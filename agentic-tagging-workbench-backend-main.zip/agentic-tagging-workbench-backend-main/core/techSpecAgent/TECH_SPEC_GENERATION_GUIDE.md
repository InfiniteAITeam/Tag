# BPK AI Tagging - Tech Spec Generation Guide

## Overview

This guide explains how the Tech Spec generation system maps Figma screens and Acceptance Criteria (AC) to proper Adobe Analytics tagging using Verizon's DataLayer properties.

## System Architecture

### Components

1. **Figma Screen Capture** (`figma_capture.py`)
   - Captures the current Figma design

2. **Acceptance Criteria Loader** (`ac_loader.py`)
   - Loads AC from local file or Google Docs

3. **LLM Mapper** (`llm_mapper.py`)
   - Uses GPT-4o to analyze AC + screenshots against tagging rules
   - Returns structured tech spec with DataLayer mappings

4. **Spec Writers** (`spec_writer.py`)
   - `write_csv()`: Generates CSV with DataLayer, eVars, and Mandatory/Optional columns
   - `write_excel_with_datalayer()`: Generates Excel with full tech spec

5. **Tagging Rules** (`config/tagging_rules.json`)
   - Naming patterns, action/object dictionaries
   - DataLayer property mappings
   - eVar assignments for each DataLayer property

## Input Files

### 1. BPK - AI Tagging - Tech Spec (CSV)

Location: `backend/v1/src/input/BPK - AI Tagging - Tech Spec (Tagging Properties).csv`

Key columns used:
- **eVar**: The Adobe eVar number (e.g., eVar1, eVar70)
- **DataLayer**: The Verizon DataLayer property (e.g., `vzdl.page.name`, `vzdl.txn.paymentType`)
- **Definition**: Business definition of what the property captures
- **Values**: Predefined values or dynamic capture instructions
- **Value Type**: Static/Dynamic or Application-specific
- **Mandatory or Optional**: Required vs. optional collection

Example rows:
```
eVar70, vzdl.page.name, Name of the page, , dynamic, Mandatory
eVar48, vzdl.txn.paymentType, Type of payment (Cash, Card, etc), , dynamic, Mandatory
eVar232, vzdl.user.authStatus, Auth status (logged in/anonymous), , dynamic, Mandatory
```

### 2. Acceptance Criteria (Text)

Location: `backend/v1/src/input/acceptance_criteria.txt`

Contains testable user interactions and validation steps. Examples:
```
· Verify that the "TAP TO START" button is tagged when tapped on the BPK screen saver.
· Verify that the "How can we help you today?" screen is tagged upon display.
· Verify that the "Mobile" option is tagged when selected.
· Verify that the "Continue" button is tagged when tapped.
```

### 3. Figma Screenshot

The actual UI design being analyzed for tagging requirements.

## Tagging Rules Configuration

File: `config/tagging_rules.json`

### Structure

```json
{
  "naming": {
    "selection": "Select_{object}",
    "continue": "Continue_{object}",
    "display": "Display_{object}",
    "tap": "Tap_{object}",
    "generic": "{action}_{object}"
  },
  "dictionary": {
    "pay your bill": "PayYourBill",
    "mobile": "Mobile",
    "account number": "AccountNumber",
    ...
  },
  "action_aliases": {
    "select": "selection",
    "tap": "tap",
    "type": "entry",
    ...
  },
  "datalayer_mappings": {
    "page_display": "vzdl.page.name",
    "button_tap": "vzdl.event.value",
    "payment_type": "vzdl.txn.paymentType",
    ...
  },
  "bpk_evar_mappings": {
    "vzdl.page.name": "eVar70",
    "vzdl.txn.paymentType": "eVar48",
    ...
  },
  "variable": "eVar27"
}
```

### Key Sections

- **naming**: Templates for constructing Adobe Values (e.g., "Select_Mobile" from "select" + "mobile")
- **dictionary**: Canonical names for UI elements (converted to PascalCase for Adobe)
- **action_aliases**: Map user actions to naming templates
- **datalayer_mappings**: Business category → Verizon DataLayer property
- **bpk_evar_mappings**: DataLayer property → Adobe eVar number
- **variable**: Default eVar when no specific mapping applies

## System Prompt (mapper_system.md)

The LLM prompt guides GPT-4o to:

1. **Extract KPIs** from Acceptance Criteria
   - Each KPI is one atomic user action or screen validation
   - Maintains auditability by referencing AC line

2. **Map to DataLayer Properties**
   - Uses `datalayer_mappings` to identify business context
   - Prefers specific properties (e.g., `vzdl.txn.paymentType`) over generic ones
   - Considers interaction type: page display, user action, transaction data, errors

3. **Assign Adobe Variables**
   - Uses `bpk_evar_mappings` to map DataLayer → eVar
   - Falls back to default `eVar27` if no mapping exists

4. **Determine Mandatory/Optional Status**
   - **Mandatory**: Core payment flows, critical user interactions, authentication
   - **Optional**: Secondary UX elements, confirmations, non-critical events

5. **Add Business Context**
   - Brief note explaining why this KPI matters for analytics

## Output Format

### CSV Output

File: `TechSpecOutputs/BPK_AI_Tagging_TechSpec_YYYYMMDD_HHMMSS.csv`

Columns:
- **KPI Requirement**: Testable step (from AC)
- **DataLayer Property**: Verizon property (e.g., `vzdl.page.name`)
- **Adobe Variables**: eVar number (e.g., `eVar70`)
- **Adobe Values**: Constructed value (e.g., `Display_HowCanWeHelpYouToday`)
- **Mandatory/Optional**: Required vs. optional
- **Business Context**: Why this matters

Example:
```
KPI Requirement,DataLayer Property,Adobe Variables,Adobe Values,Mandatory/Optional,Business Context
Verify that the "How can we help you today?" screen is tagged upon display.,vzdl.page.name,eVar70,Display_HowCanWeHelpYouToday,Mandatory,Track page view for experience analytics
Verify that the "Pay your bill" button is tagged when tapped.,vzdl.event.value,eVar16,Tap_PayYourBill,Mandatory,Track user engagement with payment initiation
Verify that the "Mobile" option is tagged when selected.,vzdl.event.value,eVar16,Select_Mobile,Mandatory,Identify bill type selection for conversion tracking
```

### Excel Output

File: `TechSpecOutputs/BPK_AI_Tagging_TechSpec_YYYYMMDD_HHMMSS.xlsx`

Same structure as CSV, formatted as Excel with:
- Headers in bold
- Proper column widths
- Sheet name: "Reporting Requirement"

## Execution Flow

```
1. Load acceptance_criteria.txt
2. Capture Figma screenshot
3. Load tagging_rules.json
4. Call LLM with:
   - System prompt (mapper_system.md)
   - AC text
   - Rules JSON
   - Screenshot (base64 encoded)
5. Parse LLM response (JSON array)
6. Generate CSV and Excel outputs
7. Store in TechSpecOutputs/
```

## How to Update Rules

### Adding a New DataLayer Property

1. **Identify the property** from BPK Tech Spec CSV
   - Find the eVar, DataLayer, and definition
   - Example: `eVar48, vzdl.txn.paymentType, Type of payment`

2. **Add to `datalayer_mappings`**
   ```json
   "datalayer_mappings": {
     "payment_type": "vzdl.txn.paymentType",  // Add this
     ...
   }
   ```

3. **Add to `bpk_evar_mappings`**
   ```json
   "bpk_evar_mappings": {
     "vzdl.txn.paymentType": "eVar48",  // Add this
     ...
   }
   ```

4. **Add dictionary entries** for values
   ```json
   "dictionary": {
     "cash": "Cash",
     "credit/debit card": "CreditDebitCard",
     ...
   }
   ```

### Adding New UI Elements

1. **Update `dictionary`** with canonical names
   ```json
   "pay your bill": "PayYourBill",
   "how can we help you today": "HowCanWeHelpYouToday",
   ```

2. **Add corresponding actions** if needed
   ```json
   "action_aliases": {
     "tap": "tap",
     "select": "selection",
   }
   ```

## LLM Response Schema

The GPT-4o model returns:

```json
[
  {
    "kpi_requirement": "Verify that the 'Pay your bill' button is tagged when tapped.",
    "datalayer_property": "vzdl.event.value",
    "adobe_variables": "eVar16",
    "adobe_values": "Tap_PayYourBill",
    "mandatory_optional": "Mandatory",
    "business_context": "Track user engagement with primary payment flow"
  },
  ...
]
```

## Validation Checklist

Before running the generation:

- [ ] Acceptance criteria loaded correctly
- [ ] Figma screenshot captured
- [ ] tagging_rules.json has all DataLayer properties needed
- [ ] All UI elements mentioned in AC are in dictionary
- [ ] eVar assignments match BPK Tech Spec CSV
- [ ] OUTPUT_DIR environment variable points to `TechSpecOutputs/`

## Environment Variables

Required in `.env`:
```
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-4o-mini (or gpt-4o)
AC_LOCAL_FILE=./acceptance_criteria.txt
RULES_FILE=./config/tagging_rules.json
OUTPUT_DIR=./TechSpecOutputs
FIGMA_TOKEN=ftest_...
FIGMA_FILE_KEY=...
```

## Troubleshooting

### Issue: "LLM_PARSE_ERROR" in output
- LLM response wasn't valid JSON
- Check that system prompt is properly formatted
- Check that OPENAI_API_KEY is valid

### Issue: Missing DataLayer Properties
- Add to both `datalayer_mappings` and `bpk_evar_mappings`
- Verify spelling matches BPK Tech Spec CSV exactly

### Issue: Wrong Adobe Values
- Check `dictionary` entries are in the rules
- Verify `action_aliases` map user actions correctly
- Confirm `naming` templates match expected format

### Issue: Files not in TechSpecOutputs
- Verify OUTPUT_DIR is set correctly
- Check that directory has write permissions
- Look for error messages in console output

## References

- BPK Tech Spec: `backend/v1/src/input/BPK - AI Tagging - Tech Spec (Tagging Properties).csv`
- Acceptance Criteria: `backend/v1/src/input/acceptance_criteria.txt`
- System Prompt: `techSpecAgent/prompts/mapper_system.md`
- Rules Configuration: `techSpecAgent/config/tagging_rules.json`
- Output Directory: `techSpecAgent/TechSpecOutputs/`
