import os
import json
import base64
import requests
from dotenv import load_dotenv
from pyvegas.helpers.utils import set_proxy
set_proxy()
load_dotenv()

# Vegas LLM only; no OpenAI keys or endpoints needed

def extract_text_from_image(image_path: str, prompt: str = "Extract all visible text from this image.", save_to: str = None) -> str:
    """
    Sends an image to Vegas LLM and returns the extracted text. Optionally saves the text to a file.
    """
    with open(image_path, "rb") as img_file:
        image_data = img_file.read()
    b64_image = base64.b64encode(image_data).decode("utf-8")

    url = f"{os.getenv('VEGAS_API_URL')}/vegas/apps/prompt/inference/chat/{os.getenv('usecase_name')}/{os.getenv('context_name')}"
    headers = {
        "Content-Type": "application/json",
        "X-apikey": os.getenv('VEGAS_API_KEY')
    }
    payload = {
        "contents": [
            {
                "role": "user",
                "parts": [
                    {"text": prompt},
                    {
                        "inlineData": {
                            "mimeType": "image/png",  # Change to image/jpeg if your image is jpeg
                            "data": b64_image
                        }
                    }
                ]
            }
        ]
    }
    response = requests.post(url, headers=headers, json=payload)
    response.raise_for_status()
    # Extract the text from the LLM response
    result = response.json()
    # Try to extract the main text from the response structure
    try:
        text = result['candidates'][0]['content']['parts'][0]['text']
    except Exception:
        text = str(result)
    if save_to:
        with open(save_to, 'w', encoding='utf-8') as f:
            f.write(text)
    return text

def extract_components_dict(image_path: str) -> dict:
    prompt = (
        "Extract all UI component names and their visible labels from this image. "
        "Return the result as a JSON object where each key is the component's label in lowercase, "
        "and each value is the component's label in PascalCase. Example: {\"bill\": \"Bill\"}"
    )
    text = extract_text_from_image(image_path, prompt=prompt, save_to="extracted_ui_components.txt")
    try:
        start = text.find('{')
        end = text.rfind('}') + 1
        json_str = text[start:end]
        components = json.loads(json_str)
    except Exception as e:
        print("[ERROR] Could not parse JSON from LLM output:", e)
        print("Raw LLM output:\n", text)
        raise
    return components

def update_tagging_rules_dictionary(new_dict: dict, tagging_rules_path: str):
    with open(tagging_rules_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    data['dictionary'] = new_dict
    with open(tagging_rules_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2)
    print(f"Updated 'dictionary' in {tagging_rules_path}")

if __name__ == "__main__":
    image_path = os.path.join("OUTPUT_DIR", "figma_screen.png")
    tagging_rules_path = os.path.join("config", "tagging_rules.json")
    components_dict = extract_components_dict(image_path)
    update_tagging_rules_dictionary(components_dict, tagging_rules_path)