# OpenAI-based LLM utilities are now fully removed in favor of Vegas LLM.
# Use core/tools/vegas_llm_utils.py for all LLM calls.

# This file is intentionally left blank.
