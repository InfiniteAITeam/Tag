# Tagging Suggestion & Apply Agents

This document describes the new two-step tagging workflow implemented in the Agentic Tagging Workbench.

## Overview

The tagging process is now split into two separate, sequential agents:

1. **Tagging Suggestion Agent** (`suggestTaggingAgent.py`) - Analyzes and identifies
2. **Apply Tagging Agent** (`applyTaggingAgent.py`) - Implements the changes

## Architecture

### Step 1: Tagging Suggestion Agent

**Purpose**: Identify which pages and flows need tagging WITHOUT modifying any code.

**Location**: `core/suggestTaggingAgent.py`

**Workflow**:
```
1. Clone the repository (from REPO_URL in .env)
2. Parse Tech Spec to identify pages and flows
3. Scan the repository structure
4. Match pages/flows to actual files in the repo
5. Generate detailed suggestion report (JSON + Markdown)
```

**Output Files**:
- `core/outputs/tagging_suggestions.json` - Structured suggestions data
- `core/outputs/tagging_suggestions.md` - Human-readable report
- `core/outputs/.last_repo_root` - Path to the cloned repository (used by apply agent)

**Key Classes**:
- `PageFlowIdentifier` - Finds pages and flows in repository structure
- `TechSpecAnalyzer` - Parses tech spec to extract tagging requirements
- `Spinner` - CLI progress indicators

**Example Output**:
```json
{
  "run_id": "2025-12-11T10:30:45",
  "type": "suggestion",
  "summary": {
    "total_pages": 5,
    "pages_with_matches": 4,
    "total_items": 23,
    "total_flows": 3
  },
  "suggestions_by_page": [
    {
      "page": "CheckoutPage",
      "flow": "checkout_flow",
      "tagging_items": [...],
      "file_locations": ["src/pages/CheckoutPage.jsx"]
    }
  ]
}
```

### Step 2: Apply Tagging Agent

**Purpose**: Apply tagging hooks to the identified pages in the cloned repository.

**Location**: `core/applyTaggingAgent.py`

**Workflow**:
```
1. Load the suggestions report from Step 1
2. Load the repository path from .last_repo_root
3. Find the 'common' folder in the repository
4. Copy the Tagging folder to common/Tagging
5. For each identified page:
   a. Locate the page file
   b. Inject useTagging hook import
   c. Initialize the hook with configuration
   d. Create backups (.backup files)
6. Generate apply log with results
```

**Output Files**:
- `core/outputs/apply_log.json` - Detailed log of all changes

**Key Classes**:
- `ApplyTaggingEngine` - Orchestrates the tagging application process
- `RepoStructureAnalyzer` - Finds key directories (common folder)
- `TaggingFolderManager` - Handles copying Tagging folder
- `CodeInjector` - Injects hooks into React components

**Example Log**:
```json
{
  "run_id": "2025-12-11T10:35:12",
  "repo_path": "/home/user/ATTagger/Test/repo",
  "common_folder": "/home/user/ATTagger/Test/repo/src/common",
  "tagging_folder": "/home/user/ATTagger/Test/repo/src/common/Tagging",
  "pages_updated": ["CheckoutPage", "PaymentPage"],
  "pages_failed": [],
  "files_updated": [
    "src/pages/CheckoutPage.jsx",
    "src/pages/PaymentPage.jsx"
  ],
  "summary": {
    "total_pages": 2,
    "pages_updated": 2,
    "pages_failed": 0,
    "files_updated": 2
  }
}
```

## Repository Structure Analysis

### Finding the Common Folder

The `RepoStructureAnalyzer` searches for the common folder in this order:

1. Check standard locations:
   - `common/`
   - `src/common/`
   - `components/common/`
   - `utils/common/`
   - `shared/common/`

2. If not found in standard locations, recursively search for any folder named `common`

3. Avoid `node_modules` and build directories

### Tagging Folder Integration

Once common folder is found:

```
cloned-repo/
├── src/
│   ├── common/
│   │   ├── Tagging/          ← Copied from core/Tagging
│   │   │   ├── index.js      ← Main useTagging hook
│   │   │   ├── dlStructure.js
│   │   │   └── ...
│   │   └── ... other common components
│   ├── pages/
│   │   ├── CheckoutPage.jsx  ← Modified with hook
│   │   └── ...
```

## Code Injection Process

### Import Injection

```javascript
// BEFORE
import React, { useState } from 'react';
import { api } from '../services';

// AFTER
import React, { useState } from 'react';
import { api } from '../services';
import { useTagging } from '../../common/Tagging';
```

### Hook Initialization

```javascript
// BEFORE
const CheckoutPage = () => {
  const [items, setItems] = useState([]);
  
  return (
    <div>...</div>
  );
};

// AFTER
const CheckoutPage = () => {
  useTagging();
  // Tagging initialized for: CheckoutPage/checkout_flow/select_payment
  
  const [items, setItems] = useState([]);
  
  return (
    <div>...</div>
  );
};
```

## Running the Agents

### Command Line

```bash
# Step 1: Generate suggestions
cd core
python suggestTaggingAgent.py

# Step 2: Apply tagging
python applyTaggingAgent.py
```

### Environment Variables Required

```bash
# In .env file:
CLONE_BASE=/home/user/ATTagger/Test
REPO_URL=https://github.com/owner/repo
REPO_BRANCH=main                           # optional
TECHSPEC_PATH=/path/to/techspec.xlsx
OPENAI_API_KEY=sk-...                      # optional for LLM features
```

### Via API

```python
# Step 1: Generate TechSpec
POST /generate-techspec
{
  "ac_text": "...",
  "figma_file_url": "..."
}

# Step 2: Suggest Tagging
POST /suggest-tagging
{
  "repo_url": "https://github.com/owner/repo",
  "branch": "main"
}

# Step 3: Apply Tagging
POST /apply-tagging
```

## Tools & Utilities

### repoStructureAnalyzer.py

Located in `core/tools/repoStructureAnalyzer.py`, provides:

**Classes**:
- `RepoStructureAnalyzer` - Analyzes repo structure, finds common folder
- `TaggingFolderManager` - Copies Tagging folder and manages integration
- `CodeInjector` - Injects hooks into React components
- `PageFileUpdater` - Updates page files with tagging (convenience wrapper)

**Key Methods**:
```python
analyzer = RepoStructureAnalyzer(repo_path)
common_folder = analyzer.get_common_folder()
page_files = analyzer.find_page_files(["CheckoutPage"])

injector = CodeInjector(import_path)
injector.inject_hook_into_component(file_path, hook_config)
```

## Backup & Rollback

### Backup Files

Each modified file gets a backup with `.backup` extension:
```
src/pages/CheckoutPage.jsx.backup
```

### Rollback Process

To rollback changes:

1. For each modified file, check if `.backup` exists
2. Restore the backup to the original file
3. Remove the modified version or keep both

## Integration with Existing Workflow

The new agents integrate seamlessly with the existing workflow:

```
TechSpec Generation (techSpecGenerate.py)
    ↓
Tagging Suggestion (suggestTaggingAgent.py)    ← NEW
    ↓
Apply Tagging (applyTaggingAgent.py)          ← NEW
    ↓
Rollback/Changes (rollback_changes.py)
```

## Error Handling

Both agents provide:

1. **Detailed Logging**: Console output with progress indicators
2. **Error Reports**: JSON files with failure reasons
3. **Exit Codes**: Non-zero on failures for CI/CD integration

### Common Issues

| Issue | Solution |
|-------|----------|
| "Common folder not found" | Ensure repo has a `common` directory |
| "Source Tagging folder not found" | Check that `core/Tagging/` exists |
| "Suggestions report not found" | Run suggestTaggingAgent first |
| "Import path calculation failed" | Check file and Tagging folder structure |

## Configuration

### Tech Spec Analysis

The tagging suggestion uses Tech Spec data to identify:
- **Pages**: From the "Page" column
- **Flows**: From the "Flow" column
- **Actions**: From the "Action" column
- **Descriptions**: Tagging requirements

### Tagging Rules

Located in `core/techSpecAgent/config/tagging_rules.json`:
```json
{
  "naming": {...},
  "datalayer_mappings": {
    "page_display": "vzdl.page.name",
    ...
  }
}
```

## Performance

- **Suggestion**: ~30-60 seconds (includes git clone)
- **Apply**: ~10-30 seconds (depends on file count)
- **Total**: ~1-2 minutes for typical mid-size repos

## Future Enhancements

1. **Incremental Updates**: Only modify changed pages
2. **Conflict Detection**: Alert if imports already exist
3. **Custom Hook Patterns**: Support different hook signatures
4. **Flow Analysis**: Deeper flow detection and grouping
5. **Multi-page Batching**: Apply multiple pages in parallel

## Examples

See `core/Tagging/index.js` for the custom hook implementation.

The hook provides:
- Automatic data layer population from Redux store
- Payment type and account type detection
- User authentication tracking
- Transaction tracking
