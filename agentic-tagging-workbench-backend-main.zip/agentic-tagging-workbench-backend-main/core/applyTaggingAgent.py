"""
applyTaggingAgent.py

Apply Tagging Agent - applies tagging to pages identified by the suggestion agent.

Flow:
1. Load the tagging suggestions report
2. Find the common folder in the cloned repo
3. Copy the Tagging folder to common/Tagging
4. For each identified page:
   - Find the page files in the repo
   - Inject the useTagging hook import
   - Initialize the hook with proper configuration
5. Create backups for rollback capability
6. Generate apply log
"""

import os
import sys
import json
import time
from pathlib import Path
from contextlib import contextmanager
from typing import Dict, List, Any, Optional
from dotenv import load_dotenv

from tools.repoStructureAnalyzer import (
    RepoStructureAnalyzer,
    TaggingFolderManager,
    CodeInjector,
)
from utils.file_handler import FileHandler

CORE_DIR = Path(__file__).resolve().parent
OUTPUTS_DIR = CORE_DIR / "outputs"
TAGGING_FOLDER_SOURCE = CORE_DIR / "Tagging"

# ---------- tiny CLI UI helpers ----------
SPINNER_FRAMES = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"


class Spinner:
    def __init__(self, label: str):
        self.label = label
        self._running = False

    def start(self):
        self._running = True
        self._animate_start = time.perf_counter()
        i = 0
        while self._running:
            frame = SPINNER_FRAMES[i % len(SPINNER_FRAMES)]
            sys.stdout.write(f"\r{frame} {self.label} ")
            sys.stdout.flush()
            i += 1
            time.sleep(0.08)

    def stop(self, ok: bool = True):
        self._running = False
        elapsed = time.perf_counter() - self._animate_start
        icon = "✓" if ok else "✗"
        sys.stdout.write(f"\r{icon} {self.label}  ({elapsed:.1f}s)\n")
        sys.stdout.flush()


@contextmanager
def step(label: str):
    sp = Spinner(label)
    try:
        import threading
        t = threading.Thread(target=sp.start, daemon=True)
        t.start()
        yield sp
        sp.stop(ok=True)
    except Exception:
        sp.stop(ok=False)
        raise

# ----------------- LLM JSON extractor -----------------

def _extract_json(text: str) -> Dict[str, Any]:
    if not text:
        return {}
    try:
        return json.loads(text)
    except Exception:
        pass
    # fenced
    start = text.find("```")
    if start != -1:
        end = text.find("```", start + 3)
        if end != -1:
            body = text[start + 3:end]
            if "\n" in body:
                body = body.split("\n", 1)[1]
            try:
                return json.loads(body.strip())
            except Exception:
                pass
    # brace scan
    s = text; n = len(s); i = 0
    while i < n:
        if s[i] == "{":
            depth = 0; j = i
            while j < n:
                ch = s[j]
                if ch == "{": depth += 1
                elif ch == "}":
                    depth -= 1
                    if depth == 0:
                        cand = s[i:j+1]
                        try: return json.loads(cand)
                        except Exception: break
                j += 1
        i += 1
    return {}

# ----------------- Prompt config -----------------

CONFIG = {
    "language": "js",
    "analytics_vendor": "adobe",
    "helper_import": "import { track } from '../analytics/track.js';",
}

DYNAMIC_SYSTEM = (
    "You are a careful code transformation assistant.\n"
    "Input:\n"
    " • Full text of a React **JavaScript** file (no TypeScript).\n"
    " • An anchor **line number** and a code **snippet** from the file near where tagging should be applied.\n"
    " • A tagging instruction for **Adobe Analytics** using a helper `track(eventName, params)`.\n"
    " • A dict of **code sections** provided directly from a JSON spec (arbitrary keys).\n"
    "\n"
    "Rules (must follow):\n"
    " 1) JavaScript only. Preserve imports/eslint/comments/formatting as much as practical.\n"
    " 2) Idempotent: if the same tagging already exists, return the file unchanged with reason.\n"
    " 3) Edit at the JSX/component location that best matches BOTH the anchor number and the provided snippet.\n"
    " 4) Use provided **code sections** exactly where possible:\n"
    "    • Keys containing 'import'  → ensure these import lines exist once (augment existing imports).\n"
    "    • Keys containing 'hook'/'effect' → place inside component body, after declaration (page view).\n"
    "    • Keys containing 'attr'/'jsx' → merge into opening JSX tag at/near the anchor (click/select/back/etc.).\n"
    "    • Keys containing 'wrap'/'handler' → wrap or replace existing handler while preserving original behavior.\n"
    "    • Any **other** keys are treated as **patch snippets**: insert the snippet in a minimal, sensible location near the anchor.\n"
    " 5) If there is an existing handler (e.g., `onClick={handle}`), inject `track(...)` at the start and keep original logic.\n"
    " 6) Ensure a single import exists: {helper_import} (prefer named import).\n"
    " 7) If you add a hook that calls useEffect(...), you MUST also ensure useEffect is imported:\n"
    "       • Prefer augmenting an existing React import:  import React, { ..., useEffect } from 'react';\n"
    "       • Otherwise add:                               import { useEffect } from 'react';\n"
    " 8) Do not invent code if a section is missing; only apply what is provided.\n"
    " 9) Output ONLY strict JSON: "
    "{ \"applied\": true|false, \"reason\": \"...\", \"updated_file\": \"<full text>\" }"
)

# ----------------- Message building -----------------

def _lines_context(file_text: str, line: int, radius: int = 40) -> str:
    lines = file_text.splitlines()
    if line < 1: line = 1
    if line > len(lines): line = len(lines)
    i0 = max(1, line - radius)
    i1 = min(len(lines), line + radius)
    chunk = lines[i0-1:i1]
    return "\n".join(f"{i0+idx:>5}: {ln}" for idx, ln in enumerate(chunk))


def _normalize_import_line(s: str) -> str:
    s = s.strip()
    # convert default import to named import (matches helper export)
    s = re.sub(r"^import\s+track\s+from\s+", "import { track } from ", s)
    return s


def _build_messages(
    file_text: str,
    action: str,
    event: str,
    params: Dict[str, Any],
    anchor_line: int,
    code: Dict[str, str],
    snippet: Optional[str],
) -> List[Dict[str, str]]:
    system = DYNAMIC_SYSTEM.replace("{helper_import}", CONFIG["helper_import"])

    # normalize imports inside code sections (JSON might contain default import style)
    code_sections = {}
    for k, v in (code or {}).items():
        if isinstance(v, str) and v.strip():
            if "import" in k.lower():
                code_sections[k] = _normalize_import_line(v)
            else:
                code_sections[k] = v

    instr = {
        "action": action,
        "event": event,
        "params": params,
        "anchor_line": anchor_line,
        "snippet": _clean_numbered_snippet(snippet or ""),
        "code_sections": code_sections,
        "around_anchor": _lines_context(file_text, anchor_line, radius=40),
        "vendor": CONFIG["analytics_vendor"],
        "language": CONFIG["language"],
        "notes": [
            "Use named import for track.",
            "If both attrs and a handler patch exist, prefer attrs merge and inject track(...) in handler.",
            "Keep JSX valid; do not convert to TypeScript.",
        ],
    }

    user = (
        "FILE:\n<<FILE_START>>\n" + file_text + "\n<<FILE_END>>\n\n" +
        "INSTRUCTION:\n" + json.dumps(instr, ensure_ascii=False)
    )
    return [
        {"role": "system", "content": system},
        {"role": "user", "content": user},
    ]

# ----------------- LLM edit -----------------

def _ai_edit_file(
    client,
    model: str,
    file_text: str,
    action: str,
    event: str,
    params: Dict[str, Any],
    anchor_line: int,
    code: Dict[str, str],
    snippet: Optional[str],
) -> Dict[str, Any]:
    messages = _build_messages(file_text, action, event, params, anchor_line, code, snippet)
    try:
        resp = client.chat.completions.create(
            model=model,
            temperature=0,
            messages=messages,
        )
        txt = resp.choices[0].message.content or ""
        data = _extract_json(txt) or {}
        if not isinstance(data, dict):
            return {"applied": False, "reason": "non-dict LLM response", "updated_file": file_text}
        if "updated_file" not in data:
            data["updated_file"] = file_text
        if "applied" not in data:
            data["applied"] = (data["updated_file"] != file_text)
        if "reason" not in data:
            data["reason"] = "ok" if data["applied"] else "no changes or already applied"
        return data
    except Exception as e:
        return {"applied": False, "reason": f"LLM error: {e}", "updated_file": file_text}

# ----------------- JSON parsing -----------------

def parse_json_plan(json_path: Path) -> Dict[str, Any]:
    if not json_path.exists():
        raise FileNotFoundError(f"JSON not found: {json_path}")
    with open(json_path, "r", encoding="utf-8") as f:
        return json.load(f)

# ----------------- Public API -----------------

def ai_apply_from_json(
    json_path: str | Path,
    repo_root: str | Path,
    model: str = "gpt-4o-mini",
    dry_run: bool = False,
) -> Tuple[int, int]:
    """
    Read the JSON spec (items[*]) and ask the LLM to perform the edits.
    Returns (ok_count, fail_count). Creates .taggingai.bak backups.
    """
    client = VegasLLMWrapper()  # Replace all LLM calls with VegasLLMWrapper().invoke(prompt) as needed in this file.
    js = Path(json_path).resolve()
    repo = Path(to_posix(str(repo_root))).resolve()

    data = parse_json_plan(js)
    items = data.get("items") or data.get("suggestions") or []
    if not items:
        print(f"✗ No actionable items found in {js}")
        return (0, 0)

    # optional helper file creation
    helper = data.get("helper_file") or {}
    try:
        helper_path = helper.get("path")
        helper_contents = helper.get("contents")
        if helper_path and helper_contents is not None:
            hp = (repo / helper_path).resolve()
            hp.parent.mkdir(parents=True, exist_ok=True)
            if not hp.exists() or _read_text(hp) != helper_contents:
                _write_text(hp, helper_contents)
                print(f"🧩 Helper file updated: {hp}")
            else:
                print(f"🧩 Helper file already up-to-date: {hp}")
    except Exception as e:
        print(f"⚠️  Helper file update skipped: {e}")

    logs: List[Dict[str, Any]] = []
    ok = fail = 0

    for it in items:
        # Resolve target file
        file_hint = (
            (it.get("top_match") or {}).get("file")
            or it.get("file")
            or it.get("file_path")
        )
        if not file_hint:
            msg = "Missing file path in item"
            print(f"✗ {msg}")
            logs.append({**it, "result": {"applied": False, "reason": msg}})
            fail += 1
            continue

        target = Path(to_posix(file_hint))
        if not target.is_absolute():
            target = (repo / target).resolve()

        if not target.exists():
            msg = f"File not found: {target}"
            print(f"✗ {msg}")
            logs.append({**it, "result": {"applied": False, "reason": msg}})
            fail += 1
            continue

        try:
            src = _read_text(target)
        except Exception as e:
            msg = f"Read failed: {target} ({e})"
            print(f"✗ {msg}")
            logs.append({**it, "result": {"applied": False, "reason": msg}})
            fail += 1
            continue

        # Gather instruction fields
        action  = (it.get("action") or "").lower().strip()
        event   = (it.get("suggested_event_name") or it.get("event") or "custom_event").strip()
        params  = it.get("suggested_params") or it.get("params") or {}
        code    = it.get("code") or {}
        snippet = it.get("snippet")  # may include numbered lines

        # anchor: use provided top_match.line else fuzzy from snippet
        anchor = int((it.get("top_match") or {}).get("line") or 1)
        better = _best_anchor_from_snippet(src, snippet) if snippet else None
        if better:
            anchor = better

        # 1st attempt
        result1 = _ai_edit_file(client, model, src, action, event, params, anchor, code, snippet)
        new_src = result1.get("updated_file") or src
        applied = bool(result1.get("applied"))
        reason  = (result1.get("reason") or "").strip() or ("ok" if applied else "no changes")

        # Retry once with shifted anchor if unchanged
        if not applied and new_src == src:
            alt_anchor = max(1, min(len(src.splitlines()), anchor + 20))
            result2 = _ai_edit_file(client, model, src, action, event, params, alt_anchor, code, snippet)
            new_src2 = result2.get("updated_file") or src
            applied2 = bool(result2.get("applied"))
            reason2  = (result2.get("reason") or "").strip() or ("ok" if applied2 else "no changes")
            if applied2 and new_src2 != src:
                applied = True
                new_src = new_src2
                reason = f"retry_ok: {reason2}"
            else:
                reason = f"not_applied: {reason}; retry: {reason2}"

        if not applied and new_src == src:
            print(f"• {target}: {reason}")
            logs.append({**it, "result": {"applied": False, "reason": reason}})
            ok += 1  # treat idempotent/no-op as OK
            continue

        if dry_run:
            print(f"[DRY-RUN] Would update: {target} ({reason})")
            logs.append({**it, "result": {"applied": True, "reason": f"dry_run: {reason}"}})
            ok += 1
            continue

        try:
            backup = target.with_suffix(target.suffix + ".taggingai.bak")
            if not backup.exists():
                _write_text(backup, src)
            _write_text(target, new_src)
            print(f"✓ Updated: {target} ({reason})  (backup: {backup.name})")
            logs.append({**it, "result": {"applied": True, "reason": reason, "backup": str(backup)}})
            ok += 1
        except Exception as e:
            msg = f"Write failed: {target} ({e})"
            print(f"✗ {msg}")
            logs.append({**it, "result": {"applied": False, "reason": msg}})
            fail += 1

    # persist logs next to the JSON
    try:
        out_log = js.parent / "apply_log.json"
        _write_text(out_log, json.dumps(logs, indent=2, ensure_ascii=False))
    except Exception:
        pass

    return ok, fail



class ApplyTaggingEngine:
    """
    Engine for applying tagging to a repository based on suggestions.
    """
    
    def __init__(self, repo_path: str):
        self.repo_path = Path(repo_path)
        self.analyzer = RepoStructureAnalyzer(str(self.repo_path))
        self.common_folder = self.analyzer.get_common_folder()
        self.tagging_folder = None
        self.apply_log = {
            "run_id": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "repo_path": str(self.repo_path),
            "common_folder": str(self.common_folder) if self.common_folder else None,
            "tagging_folder": None,
            "pages_processed": [],
            "pages_updated": [],
            "pages_failed": [],
            "files_updated": [],
            "files_failed": [],
            "files_skipped": [],
            "summary": {}
        }
    
    def setup_tagging_folder(self, force: bool = False) -> bool:
        """
        Copy the Tagging folder to common/Tagging.
        
        Args:
            force: If True, overwrite existing Tagging folder
            
        Returns:
            True if successful
        """
        if not self.common_folder:
            raise RuntimeError("Common folder not found in repository")
        
        if not TAGGING_FOLDER_SOURCE.exists():
            raise RuntimeError(f"Source Tagging folder not found at: {TAGGING_FOLDER_SOURCE}")
        
        try:
            manager = TaggingFolderManager(str(self.repo_path), str(TAGGING_FOLDER_SOURCE))
            self.tagging_folder = manager.copy_tagging_to_common(self.common_folder, force=force)
            self.apply_log["tagging_folder"] = str(self.tagging_folder)
            return True
        except Exception as e:
            raise RuntimeError(f"Failed to copy Tagging folder: {e}")
    
    def apply_tagging_to_pages(
        self,
        suggestions_report: Dict[str, Any],
        backup: bool = True
    ) -> Dict[str, Any]:
        """
        Apply tagging to all pages in the suggestions report.
        
        Args:
            suggestions_report: Report from suggestTaggingAgent
            backup: Whether to create backups of original files
            
        Returns:
            Summary of applied changes
        """
        
        pages_by_name = {}
        for page_data in suggestions_report.get('suggestions_by_page', []):
            page_name = page_data['page']
            pages_by_name[page_name] = page_data
            self.apply_log['pages_processed'].append(page_name)
        
        # Process each page
        for page_name, page_data in pages_by_name.items():
            try:
                # Get file locations from suggestions
                file_locations = page_data.get('file_locations', [])
                
                if not file_locations:
                    # Try to find the page files
                    found_files = self.analyzer.find_page_files([page_name])
                    file_locations = [str(f.relative_to(self.repo_path)) for f in found_files.get(page_name, [])]
                
                if not file_locations:
                    print(f"  ⚠ No files found for page: {page_name}")
                    continue
                
                # Process each file
                page_success = True
                for file_loc in file_locations:
                    file_path = self.repo_path / file_loc
                    
                    if not file_path.exists():
                        print(f"    ✗ File not found: {file_loc}")
                        self.apply_log['files_skipped'].append(file_loc)
                        page_success = False
                        continue
                    
                    # Inject tagging
                    try:
                        success = self._inject_tagging_to_file(
                            file_path,
                            page_name,
                            page_data.get('flow', 'unknown'),
                            page_data.get('tagging_items', []),
                            backup=backup
                        )
                        
                        if success:
                            print(f"    ✓ Updated: {file_loc}")
                            self.apply_log['files_updated'].append(file_loc)
                        else:
                            print(f"    ✗ Failed: {file_loc}")
                            self.apply_log['files_failed'].append(file_loc)
                            page_success = False
                    
                    except Exception as e:
                        print(f"    ✗ Error updating {file_loc}: {e}")
                        self.apply_log['files_failed'].append(file_loc)
                        page_success = False
                
                if page_success:
                    self.apply_log['pages_updated'].append(page_name)
                else:
                    self.apply_log['pages_failed'].append(page_name)
            
            except Exception as e:
                print(f"  ✗ Error processing page {page_name}: {e}")
                self.apply_log['pages_failed'].append(page_name)
        
        # Calculate summary
        self.apply_log['summary'] = {
            'total_pages': len(pages_by_name),
            'pages_updated': len(self.apply_log['pages_updated']),
            'pages_failed': len(self.apply_log['pages_failed']),
            'files_updated': len(self.apply_log['files_updated']),
            'files_failed': len(self.apply_log['files_failed']),
            'files_skipped': len(self.apply_log['files_skipped']),
        }
        
        return self.apply_log
    
    def _inject_tagging_to_file(
        self,
        file_path: Path,
        page_name: str,
        flow_name: str,
        tagging_items: List[Dict],
        backup: bool = True
    ) -> bool:
        """
        Inject tagging into a single file.
        
        Args:
            file_path: Path to the file
            page_name: Name of the page
            flow_name: Name of the flow
            tagging_items: List of tagging items for this page
            backup: Whether to backup original
            
        Returns:
            True if successful
        """
        
        # Calculate import path
        rel_import_path = self._calculate_import_path(file_path)
        
        # Create code injector
        injector = CodeInjector(rel_import_path)
        
        # Extract event/adobe_var from the first tagging item
        event = 'unknown_event'
        if tagging_items:
            first_item = tagging_items[0].get('item', {})
            # Try to get adobe_var first, otherwise use action
            adobe_var = first_item.get('adobe_var', '')
            if adobe_var:
                event = adobe_var
            else:
                action = first_item.get('action', 'unknown')
                event = f"event_{action}"
        
        # Prepare hook configuration with event data
        hook_config = {
            'page': page_name,
            'flow': flow_name,
            'event': event,
            'isFlowNameUpdate': True,
            'action': tagging_items[0].get('item', {}).get('action', 'unknown') if tagging_items else 'unknown',
            'tagging_items_count': len(tagging_items)
        }
        
        # Inject the hook
        return injector.inject_hook_into_component(file_path, hook_config, backup=backup)
    
    def _calculate_import_path(self, from_file: Path) -> str:
        """
        Calculate the relative import path from a file to Tagging/index.
        
        Args:
            from_file: Path to the file that will import Tagging
            
        Returns:
            Relative import path
        """
        tagging_path = self.common_folder / "Tagging"
        
        try:
            rel_path = os.path.relpath(tagging_path, from_file.parent)
            rel_path = rel_path.replace("\\", "/")
            # Ensure it starts with ./ or ../
            if not rel_path.startswith('.'):
                rel_path = './' + rel_path
            return rel_path
        except ValueError:
            return str(tagging_path)


def load_suggestions_report(report_path: str) -> Dict[str, Any]:
    """Load the tagging suggestions report."""
    report_file = Path(report_path)
    
    if not report_file.exists():
        raise FileNotFoundError(f"Suggestions report not found: {report_path}")
    
    with open(report_file, "r", encoding="utf-8") as f:
        return json.load(f)


def load_repo_path_from_file() -> str:
    """Load the repository path from the .last_repo_root file."""
    last_repo_file = OUTPUTS_DIR / ".last_repo_root"
    
    if not last_repo_file.exists():
        raise FileNotFoundError(
            f"Last repo root file not found: {last_repo_file}\n"
            "Please run suggestTaggingAgent.py first"
        )
    
    repo_path = last_repo_file.read_text(encoding="utf-8").strip()
    return repo_path


def main():
    load_dotenv()
    
    print("==========================================")
    print("   Apply Tagging Agent")
    print("==========================================")
    print("")
    
    try:
        # Load repo path from suggestions step
        with step("Loading repository path"):
            repo_path = load_repo_path_from_file()
        
        print(f"→ Repository: {repo_path}")
        
        # Check if suggestions report exists
        suggestions_file = OUTPUTS_DIR / "tagging_suggestions.json"
        if not suggestions_file.exists():
            print(f"✗ Suggestions report not found: {suggestions_file}")
            print("  Please run suggestTaggingAgent.py first")
            sys.exit(1)
        
        # Load suggestions
        with step("Loading tagging suggestions"):
            suggestions = load_suggestions_report(str(suggestions_file))
        
        print(f"→ Found suggestions for {len(suggestions.get('suggestions_by_page', []))} pages")
        
        # Initialize apply engine
        engine = ApplyTaggingEngine(repo_path)
        
        # Verify common folder
        if not engine.common_folder:
            print("✗ Could not find 'common' folder in repository")
            print("  Repository structure may not be supported")
            sys.exit(1)
        
        print(f"✓ Found common folder at: {engine.common_folder.relative_to(engine.repo_path)}")
        
        # Setup Tagging folder
        with step("Setting up Tagging folder"):
            engine.setup_tagging_folder(force=False)
        
        print(f"✓ Tagging folder ready at: {engine.tagging_folder}")
        
        # Apply tagging
        with step("Applying tagging to pages"):
            apply_results = engine.apply_tagging_to_pages(suggestions, backup=True)
        
        # Write log
        OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)
        log_file = OUTPUTS_DIR / "apply_log.json"
        with open(log_file, "w", encoding="utf-8") as f:
            json.dump(apply_results, f, indent=2)
        
        # Print summary
        summary = apply_results.get('summary', {})
        print("")
        print("Summary")
        print("-------")
        print(f"• Pages processed  : {summary.get('total_pages', 0)}")
        print(f"• Pages updated    : {summary.get('pages_updated', 0)}")
        print(f"• Pages failed     : {summary.get('pages_failed', 0)}")
        print(f"• Files updated    : {summary.get('files_updated', 0)}")
        print(f"• Files failed     : {summary.get('files_failed', 0)}")
        print(f"• Files skipped    : {summary.get('files_skipped', 0)}")
        print("")
        print("Outputs")
        print("-------")
        print(f"• Log file: {log_file}")
        print("")
        
        if summary.get('pages_failed', 0) > 0:
            print("⚠ Some pages failed to update. Check the log for details.")
            sys.exit(1)
        else:
            print("✓ All tagging applied successfully!")
            print("")
    
    except KeyboardInterrupt:
        print("\nAborted by user.")
        sys.exit(130)
    except Exception as e:
        print(f"\n✗ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()if __name__ == "__main__":
    import argparse
    from dotenv import load_dotenv
    load_dotenv()

    ap = argparse.ArgumentParser(description="AI-applier: modify repo files based on tagging_unified.json")
    ap.add_argument("--json", default="outputs/tagging_unified.json")
    ap.add_argument("--repo", default=os.environ.get("REPO_PATH", "."))
    ap.add_argument("--model", default=os.environ.get("OPENAI_MODEL", "gpt-4o-mini"))
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    ok, fail = ai_apply_from_json(args.json, args.repo, model=args.model, dry_run=args.dry_run)
    print(f"\nResult: {ok} items processed, {fail} failed.")