#!/usr/bin/env python3
"""
Standalone Tech Spec Generator

This script generates a BPK AI Tagging Tech Spec CSV file based on:
1. Acceptance Criteria (AC) text file
2. BPK Tech Spec CSV with DataLayer properties
3. Tagging rules configuration

Usage:
    python standalone_techspec_generator.py [screenshot_path] [output_dir]

If screenshot_path is not provided, it will attempt to use existing screenshot.
If output_dir is not provided, defaults to ./TechSpecOutputs
"""

import os
import sys
import json
import csv
from datetime import datetime
from pathlib import Path
from dotenv import load_dotenv

# Try to import the modules
try:
    from techSpecAgent.ac_loader import load_acceptance_criteria
    from techSpecAgent.llm_mapper import map_to_spec
    from techSpecAgent.rules_loader import load_rules
except ImportError:
    print("Error: Required modules not found. Make sure you're in the correct directory.")
    sys.exit(1)

load_dotenv()

def load_bpk_tech_spec(csv_path: str) -> dict:
    """
    Load the BPK Tech Spec CSV and create a reference mapping.
    
    Returns dict mapping DataLayer properties to their details:
    {
        "vzdl.page.name": {
            "evar": "eVar70",
            "definition": "Name of the page",
            "value_type": "dynamic",
            "mandatory": "Mandatory"
        },
        ...
    }
    """
    mapping = {}
    try:
        with open(csv_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                datalayer = row.get('DataLayer', '').strip()
                if datalayer:
                    mapping[datalayer] = {
                        'evar': row.get('eVar', '').strip(),
                        'definition': row.get('Definition', '').strip(),
                        'values': row.get('Values', '').strip(),
                        'value_type': row.get('Value Type', '').strip(),
                        'mandatory': row.get('Mandatory or Optional', '').strip()
                    }
    except Exception as e:
        print(f"Warning: Could not load BPK Tech Spec CSV: {e}")
    
    return mapping

def generate_tech_spec_csv(
    screenshot_path: str,
    acceptance_text: str,
    output_dir: str = "./TechSpecOutputs",
    bpk_spec_path: str = None
) -> str:
    """
    Generate Tech Spec CSV with DataLayer properties.
    
    Args:
        screenshot_path: Path to Figma screenshot
        acceptance_text: Acceptance criteria text
        output_dir: Output directory for CSV
        bpk_spec_path: Path to BPK Tech Spec CSV for reference
    
    Returns:
        Path to generated CSV file
    """
    
    # Create output directory
    os.makedirs(output_dir, exist_ok=True)
    
    # Load BPK reference if available
    bpk_mapping = {}
    if bpk_spec_path and os.path.exists(bpk_spec_path):
        print(f"Loading BPK Tech Spec reference from: {bpk_spec_path}")
        bpk_mapping = load_bpk_tech_spec(bpk_spec_path)
        print(f"Loaded {len(bpk_mapping)} DataLayer properties from BPK Tech Spec")
    
    # Get tagging rules
    rules = load_rules()
    
    # Call LLM mapper with screenshot and AC
    print("Calling LLM to map AC to Tech Spec...")
    rows = map_to_spec(screenshot_path, acceptance_text, use_csv_output=True)
    print(f"Generated {len(rows)} KPI requirements")
    
    # Enhance rows with BPK reference data if available
    if bpk_mapping:
        for row in rows:
            datalayer = row.get('datalayer_property')
            if datalayer and datalayer in bpk_mapping:
                spec = bpk_mapping[datalayer]
                # Override eVar if different
                if spec['evar'] and spec['evar'] != row.get('adobe_variables'):
                    print(f"  Note: Using eVar {spec['evar']} for {datalayer} (from BPK spec)")
                    row['adobe_variables'] = spec['evar']
    
    # Write CSV
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    csv_path = os.path.join(output_dir, f"BPK_AI_Tagging_TechSpec_{timestamp}.csv")
    
    with open(csv_path, 'w', newline='', encoding='utf-8') as csvfile:
        fieldnames = [
            'KPI Requirement',
            'DataLayer Property',
            'Adobe Variables',
            'Adobe Values',
            'Mandatory/Optional',
            'Business Context'
        ]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        
        for row in rows:
            writer.writerow({
                'KPI Requirement': row.get('kpi_requirement', ''),
                'DataLayer Property': row.get('datalayer_property', '') or '',
                'Adobe Variables': row.get('adobe_variables', ''),
                'Adobe Values': row.get('adobe_values', ''),
                'Mandatory/Optional': row.get('mandatory_optional', 'Optional'),
                'Business Context': row.get('business_context', '')
            })
    
    print(f"\n✓ Tech Spec CSV generated: {csv_path}")
    return csv_path

def main():
    """Main entry point"""
    
    # Get screenshot path from argument or use default
    screenshot_path = sys.argv[1] if len(sys.argv) > 1 else "techSpecAgent/TechSpecOutputs/figma_screen.png"
    
    # Get output directory from argument or use default
    output_dir = sys.argv[2] if len(sys.argv) > 2 else "./TechSpecOutputs"
    
    # Get BPK spec path
    bpk_spec_path = os.getenv(
        "BPK_SPEC_CSV",
        "../input/BPK - AI Tagging - Tech Spec (Tagging Properties).csv"
    )
    
    # Validate screenshot exists
    if not os.path.exists(screenshot_path):
        print(f"Error: Screenshot not found at {screenshot_path}")
        print(f"Please ensure the Figma screenshot is captured at this location.")
        sys.exit(1)
    
    print("=" * 70)
    print("BPK AI Tagging - Tech Spec Generator")
    print("=" * 70)
    print(f"Screenshot:     {screenshot_path}")
    print(f"Output Dir:     {output_dir}")
    if bpk_spec_path:
        print(f"BPK Spec CSV:   {bpk_spec_path}")
    print()
    
    # Load acceptance criteria
    print("Loading acceptance criteria...")
    try:
        acceptance_text = load_acceptance_criteria()
        print(f"✓ Acceptance criteria loaded ({len(acceptance_text)} characters)")
    except Exception as e:
        print(f"Error loading acceptance criteria: {e}")
        sys.exit(1)
    
    # Generate tech spec
    try:
        csv_path = generate_tech_spec_csv(
            screenshot_path,
            acceptance_text,
            output_dir,
            bpk_spec_path
        )
        
        # Print summary
        print("\n" + "=" * 70)
        print("Tech Spec Generation Complete!")
        print("=" * 70)
        print(f"Output file: {csv_path}")
        print("\nNext steps:")
        print("1. Review the generated CSV for accuracy")
        print("2. Validate that all AC steps are covered")
        print("3. Cross-reference with BPK Tech Spec definitions")
        print("4. Adjust tagging rules if needed")
        
    except Exception as e:
        print(f"\nError generating tech spec: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
